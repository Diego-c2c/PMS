package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"pms-backend/handlers"
	"pms-backend/services"
	"time"

	_ "github.com/lib/pq"
)

// Connexion DB globale utilisée par certains handlers simples
var db *sql.DB

// Booking = structure simple exposée côté /api/calendar
type Booking struct {
	CheckIn     string `json:"check_in"`
	CheckOut    string `json:"check_out"`
	GuestName   string `json:"guest"`
	Description string `json:"description"`
	Source      string `json:"source"`
	Status      string `json:"status"`
}

// CalendarEvent = format unifié renvoyé à calendar-view.js
type CalendarEvent struct {
	ID          int    `json:"id"`
	CheckIn     string `json:"check_in"`
	CheckOut    string `json:"check_out"`
	Guest       string `json:"guest"`
	GuestName   string `json:"guest_name"`
	Description string `json:"description"`
	Source      string `json:"source"`
	Status      string `json:"status"`
	RoomCode    string `json:"room_code"`
	Units       int    `json:"units"`
	EventType   string `json:"event_type"`
}

// init initialise la connexion PostgreSQL au démarrage
func init() {
	var err error

	dsn := fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		os.Getenv("DB_HOST"),
		os.Getenv("DB_PORT"),
		os.Getenv("DB_USER"),
		os.Getenv("DB_PASSWORD"),
		os.Getenv("DB_NAME"),
	)

	db, err = sql.Open("postgres", dsn)
	if err != nil {
		log.Fatal("DB connection failed:", err)
	}

	if err := db.Ping(); err != nil {
		log.Fatal("DB ping failed:", err)
	}

	log.Println("✓ Connected to PostgreSQL")
}

// Middleware CORS simple
func corsMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}

		next(w, r)
	}
}

func main() {
	defer db.Close()

	// Scheduler iCal existant
	scheduler := services.NewICalScheduler(db)
	if err := scheduler.Start(); err != nil {
		log.Printf("Warning: could not start scheduler: %v\n", err)
	}
	defer scheduler.Stop()

	// Service métier principal
	bookingSvc := services.NewBookingService(db)

	// ============================================
	// HEALTH CHECK
	// ============================================
	http.HandleFunc("/health", corsMiddleware(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		fmt.Fprintf(w, `{"status":"ok"}`)
	}))

	// ============================================
	// IMPORT ICAL HISTORIQUE
	// ============================================
	http.HandleFunc("/api/ical/import", corsMiddleware(handlers.HandleICalImport(db)))

	// ============================================
	// BOOKINGS CRUD
	// ============================================
	http.HandleFunc("/api/bookings", corsMiddleware(handlers.HandleGetBookings(bookingSvc)))
	http.HandleFunc("/api/bookings/create", corsMiddleware(handlers.HandleCreateBooking(bookingSvc)))
	http.HandleFunc("/api/bookings/update/", corsMiddleware(handlers.HandleUpdateBooking(bookingSvc)))
	http.HandleFunc("/api/bookings/delete/", corsMiddleware(handlers.HandleDeleteBooking(bookingSvc)))
	http.HandleFunc("/api/bookings/", corsMiddleware(handlers.HandleGetBooking(bookingSvc)))

	// ============================================
	// CALENDAR BLOCKS - CREATE MANUEL
	// ============================================
	http.HandleFunc("/api/calendar-blocks", corsMiddleware(handlers.HandleCreateBlock(bookingSvc)))

	// ============================================
	// SYNC FROM ICAL (V1)
	// Reçoit les événements parsés par Node.js
	// et les écrit dans calendar_blocks.
	//
	// POST /api/calendar-blocks/sync-from-ical
	//
	// Body attendu :
	// {
	//   "room_code": "520741601",
	//   "property_id": 1,
	//   "channel": "Booking",
	//   "status_default": "undefine",
	//   "bookings": [
	//     {
	//       "check_in": "2026-04-03",
	//       "check_out": "2026-04-16",
	//       "description": "CLOSED - Not available",
	//       "source": "booking",
	//       "guest_name": "",
	//       "price": 0,
	//       "type": "block"
	//     }
	//   ]
	// }
	// ============================================
	http.HandleFunc("/api/calendar-blocks/sync-from-ical", corsMiddleware(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		type SyncEvent struct {
			CheckIn     string `json:"check_in"`
			CheckOut    string `json:"check_out"`
			Description string `json:"description"`
			Source      string `json:"source"`
			GuestName   string `json:"guest_name"`
			Price       int    `json:"price"`
			Type        string `json:"type"`
		}

		type SyncRequest struct {
			RoomCode      string      `json:"room_code"`
			PropertyID    int         `json:"property_id"`
			Channel       string      `json:"channel"`
			StatusDefault string      `json:"status_default"`
			Bookings      []SyncEvent `json:"bookings"`
		}

		var req SyncRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "Invalid JSON body",
			})
			return
		}

		if req.PropertyID == 0 || len(req.Bookings) == 0 {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "property_id et bookings sont requis",
			})
			return
		}

		insertedCount := 0

		for _, b := range req.Bookings {
			// V1 : on ne traite que les événements de type block
			if b.Type != "block" {
				continue
			}

			checkIn, err := time.Parse("2006-01-02", b.CheckIn)
			if err != nil {
				log.Printf("check_in invalide: %s — %v\n", b.CheckIn, err)
				continue
			}

			checkOut, err := time.Parse("2006-01-02", b.CheckOut)
			if err != nil {
				log.Printf("check_out invalide: %s — %v\n", b.CheckOut, err)
				continue
			}

			if !checkOut.After(checkIn) {
				log.Printf("Période invalide room=%s: %s -> %s\n", req.RoomCode, b.CheckIn, b.CheckOut)
				continue
			}

			blockType := "closed"
			reason := b.Description
			if reason == "" {
				reason = "Import iCal"
			}

			// Évite les doublons exacts sur la même propriété et même période
			var exists int
			err = db.QueryRow(`
					SELECT COUNT(*)
					FROM calendar_blocks
					WHERE property_id = $1
					AND room_code = $2
					AND date_from = $3
					AND date_to = $4
					AND block_type = $5
					AND reason = $6
				`, req.PropertyID, req.RoomCode, checkIn, checkOut, blockType, reason).Scan(&exists)
			if err != nil {
				log.Printf("Erreur vérification doublon block room=%s property=%d: %v\n", req.RoomCode, req.PropertyID, err)
				continue
			}

			if exists > 0 {
				log.Printf("Block déjà existant: room=%s property=%d %s->%s (%s)\n", req.RoomCode, req.PropertyID, b.CheckIn, b.CheckOut, reason)
				continue
			}

			_, err = db.Exec(`
				INSERT INTO calendar_blocks (
					property_id,
					room_code,
					date_from,
					date_to,
					block_type,
					reason
				)
				VALUES ($1, $2, $3, $4, $5, $6)
			`,
				req.PropertyID,
				req.RoomCode,
				checkIn,
				checkOut,
				blockType,
				reason,
			)
			if err != nil {
				log.Printf("Erreur insertion calendar_blocks room=%s property=%d: %v\n", req.RoomCode, req.PropertyID, err)
				continue
			}

			log.Printf("Block inséré: room=%s %s -> %s (%s) property=%d\n", req.RoomCode, b.CheckIn, b.CheckOut, reason, req.PropertyID)
			insertedCount++
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success":        true,
			"inserted_count": insertedCount,
			"property_id":    req.PropertyID,
			"channel":        req.Channel,
			"room_code":      req.RoomCode,
		})
	}))

	// ============================================
	// PRICING
	// ============================================
	http.HandleFunc("/api/pricing/sync", corsMiddleware(handlers.HandleSyncPrices(bookingSvc)))
	http.HandleFunc("/api/pricing/current", corsMiddleware(handlers.HandleGetPrices(bookingSvc)))

	// ============================================
	// CALENDRIER UNIFIÉ
	// Renvoie bookings + calendar_blocks
	// dans un seul tableau JSON compatible avec calendar-view.js
	// ============================================
	http.HandleFunc("/api/calendar", corsMiddleware(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		propertyID := 1
		events := make([]CalendarEvent, 0)

		// 1. Charger les réservations
		bookingRows, err := db.Query(`
			SELECT id, check_in, check_out, guest_name, description, source, status, room_code, units
			FROM bookings
			WHERE property_id = $1
			ORDER BY check_in
		`, propertyID)
		if err != nil {
			http.Error(w, "Query bookings error: "+err.Error(), http.StatusInternalServerError)
			return
		}
		defer bookingRows.Close()

		for bookingRows.Next() {
			var ev CalendarEvent
			var checkIn, checkOut time.Time

			if err := bookingRows.Scan(
				&ev.ID,
				&checkIn,
				&checkOut,
				&ev.Guest,
				&ev.Description,
				&ev.Source,
				&ev.Status,
				&ev.RoomCode,
				&ev.Units,
			); err != nil {
				continue
			}

			ev.CheckIn = checkIn.Format("2006-01-02")
			ev.CheckOut = checkOut.Format("2006-01-02")
			ev.GuestName = ev.Guest
			ev.EventType = "booking"

			events = append(events, ev)
		}

		// 2. Charger les blocs calendrier
		blockRows, err := db.Query(`
			SELECT id, room_code, date_from, date_to, block_type, reason
			FROM calendar_blocks
			WHERE property_id = $1
			ORDER BY date_from
		`, propertyID)
		if err != nil {
			http.Error(w, "Query blocks error: "+err.Error(), http.StatusInternalServerError)
			return
		}
		defer blockRows.Close()

		for blockRows.Next() {
			var ev CalendarEvent
			var dateFrom, dateTo time.Time
			var blockType, reason string
			var roomCode sql.NullString

			if err := blockRows.Scan(
				&ev.ID,
				&roomCode,
				&dateFrom,
				&dateTo,
				&blockType,
				&reason,
			); err != nil {
				continue
			}

			ev.CheckIn = dateFrom.Format("2006-01-02")
			ev.CheckOut = dateTo.Format("2006-01-02")
			ev.Guest = "CLOSED"
			ev.GuestName = "CLOSED"
			ev.Description = reason
			ev.Source = "booking"
			ev.Status = blockType

			// IMPORTANT :
			// calendar_blocks ne contient pas encore room_code dans ton schéma actuel.
			// On met une valeur de secours pour que le front ne casse pas.
			// Si tu veux une couleur/room exacte dans calendar-view.js,
			// il faudra ajouter room_code à calendar_blocks plus tard.
			if roomCode.Valid {
				ev.RoomCode = roomCode.String
			} else {
				ev.RoomCode = ""
			}

			ev.Units = 1
			ev.EventType = "block"

			events = append(events, ev)
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(events)
	}))

	// ============================================
	// PORT
	// ============================================
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("🚀 API running on :%s\n", port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}
