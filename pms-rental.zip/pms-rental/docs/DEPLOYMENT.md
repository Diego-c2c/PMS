# Deployment

## Environnements
- Local : développement sur localhost.
- Staging : validation avant prod.
- Production : usage réel.

## Pré-requis
- Node.js LTS
- PostgreSQL
- Variables d'environnement configurées
- Reverse proxy si exposition publique

## Lancement
### Backend auth
```bash
cd auth-backend
npm install
npm run dev
```

### Frontend statique
```bash
cd frontend
npx serve .
```

## Points d'attention
- Vérifier CORS si frontend et backend sont séparés.
- Vérifier les cookies de session en HTTPS.
- Vérifier les ports exposés.
- Ajouter sauvegardes base avant mise en production.
