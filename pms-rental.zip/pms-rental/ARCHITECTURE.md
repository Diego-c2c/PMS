# Architecture

## Vue d'ensemble

PMS Rental est une application web de gestion locative structurée autour de trois blocs principaux : interface frontend statique, backend d'authentification/API métier, et base de données PostgreSQL.

Une brique de synchronisation externe est prévue pour Booking.com, puis Airbnb, afin de garder le cœur PMS indépendant des connecteurs de canaux.

## Principes d'architecture

- Séparer l'authentification, le métier PMS et les futures synchronisations.
- Garder un frontend simple en HTML/CSS/JS vanilla.
- Centraliser les rôles dans le backend.
- Utiliser PostgreSQL comme source de vérité.
- Ajouter les connecteurs externes progressivement.

## Composants

### 1. Frontend statique

Responsabilités :
- afficher les pages applicatives ;
- appeler les API ;
- gérer le thème ;
- appliquer les restrictions d'interface par rôle ;
- rediriger selon l'état d'authentification.

Fichiers clés :
- `auth.js`
- `index.html`
- `calendar-view.html`
- `calendar-dark.html`
- `booking-form.html`
- `edit-booking.html`
- `pricing.html`
- `admin-users.html`

### 2. Auth / API backend

Responsabilités :
- gérer la session utilisateur ;
- exposer `/api/auth/*` ;
- appliquer les middlewares `requireAuth`, `requireReadOnly`, `requireManager`, `requireAdmin` ;
- servir les routes métier selon les droits.

Fichiers clés :
- `server.js`
- `authMiddleware.js`
- `db.js`
- `seedAdmin.js`

### 3. Base PostgreSQL

Responsabilités :
- stocker utilisateurs, rôles, réservations, canaux, propriétés ;
- garantir l'intégrité des données ;
- servir de base unique pour l'application.

Tables typiques :
- `users`
- `bookings`
- `properties`
- `channels`
- `sync_jobs`
- `sync_logs`

### 4. Connecteur Booking.com

Responsabilités prévues :
- recevoir les demandes de synchronisation tarifaire ;
- traduire les données PMS vers le format Booking ;
- tracer les erreurs et résultats ;
- isoler la logique spécifique au canal.

### 5. Connecteur Airbnb

Responsabilités prévues :
- même principe que Booking.com ;
- logique séparée pour limiter le couplage ;
- activation après stabilisation du premier connecteur.

## Schéma logique

```text
[ Browser / Frontend ]
          |
          | HTTP
          v
[ Node.js / Express API ]
     |            \
     | SQL         \ HTTP/API interne
     v              v
[ PostgreSQL ]   [ Sync Connector Booking ]
                        |
                        v
                 [ Booking.com ]

Puis plus tard :
[ Sync Connector Airbnb ] -> [ Airbnb ]
```

## Gestion des rôles

### user
- accès lecture seule ;
- consultation tableau et calendriers ;
- pas de création ;
- pas d'édition ;
- pas d'administration.

### manager
- lecture ;
- création de réservation ;
- modification de réservation ;
- accès aux opérations PMS courantes.

### admin
- tous les droits manager ;
- gestion utilisateurs ;
- administration globale.

## Flux principaux

### Connexion
1. L'utilisateur envoie ses identifiants.
2. Le backend vérifie l'utilisateur.
3. Une session est créée.
4. Le frontend interroge `/api/auth/me` via `auth.js`.
5. Les pages s'adaptent selon le rôle.

### Création réservation
1. Le manager/admin ouvre `booking-form.html`.
2. Le frontend valide le formulaire.
3. Le backend enregistre la réservation.
4. Les vues tableau et calendrier la reflètent ensuite.

### Modification réservation
1. L'utilisateur autorisé clique sur une réservation.
2. `edit-booking.html?id=...` charge la réservation.
3. Le formulaire est modifié puis soumis.
4. Le backend met à jour la base.

### Synchronisation Booking
1. L'utilisateur autorisé prépare les prix dans `pricing.html`.
2. Le frontend envoie un lot au backend.
3. Le connecteur Booking traduit et pousse les données.
4. Les retours sont stockés dans des logs métiers.

## Choix techniques

### Frontend vanilla
Avantages :
- très simple à maintenir ;
- sans build complexe ;
- rapide à ajuster.

Contraintes :
- plus de duplication si la structure n'est pas disciplinée ;
- besoin de bien centraliser les scripts communs comme `auth.js`.

### Backend Express
Avantages :
- rapide à faire évoluer ;
- middleware simple pour la sécurité ;
- adapté à un projet incrémental.

### PostgreSQL
Avantages :
- solide ;
- relationnel ;
- bon support des contraintes et requêtes métier.

## Dossiers recommandés

```text
auth-backend/
├─ middleware/
├─ routes/
├─ controllers/
├─ services/
├─ repositories/
├─ db/
└─ utils/

frontend/
├─ pages/
├─ js/
├─ css/
└─ assets/

connectors/
├─ booking/
└─ airbnb/
```

## Risques techniques actuels

- URLs localhost potentiellement dispersées entre ports `8080`, `8081` et frontend.
- Mélange possible entre backend auth et backend métier si les responsabilités ne sont pas clarifiées.
- Faible couverture de tests à ce stade.
- Synchronisation externe encore non finalisée.
- Logs et gestion des erreurs à standardiser.

## Dette technique prioritaire

1. Centraliser la configuration (`.env`, URLs API, ports).
2. Ajouter une vraie structure routes/controllers/services.
3. Séparer clairement PMS core et connecteurs.
4. Ajouter journalisation et traçabilité de sync.
5. Préparer tests API minimaux.

## Fichiers de documentation à maintenir

- `README.md` : vue produit + installation.
- `ARCHITECTURE.md` : vue technique.
- `docs/ROADMAP.md` : phases et priorités.
- `docs/SECURITY.md` : secrets, sessions, rôles, publication Git.
- `docs/DEPLOYMENT.md` : variables, ports, lancement.
- `CHANGELOG.md` : historique des livrables.

## Prochaine étape recommandée

Stabiliser d'abord la synchronisation Booking.com, puis factoriser un modèle de connecteur réutilisable avant d'attaquer Airbnb.
