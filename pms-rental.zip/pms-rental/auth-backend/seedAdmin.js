require('dotenv').config({ path: '../.env' });
const bcrypt = require('bcrypt');
const pool = require('./db');
const initAuthTables = require('./initAuthTables');

async function seedAdmin() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  const rounds = Number(process.env.BCRYPT_ROUNDS || 12);

  if (!email || !password) {
    throw new Error('ADMIN_EMAIL ou ADMIN_PASSWORD manquant dans .env');
  }

  await initAuthTables();

  const existing = await pool.query(
    'SELECT id FROM users WHERE email = $1',
    [email]
  );

  if (existing.rows.length > 0) {
    console.log('Admin existe déjà.');
    process.exit(0);
  }

  const passwordHash = await bcrypt.hash(password, rounds);

  await pool.query(
    'INSERT INTO users (email, password_hash, role) VALUES ($1, $2, $3)',
    [email, passwordHash, 'admin']
  );

  console.log('Admin créé avec succès.');
  process.exit(0);
}

seedAdmin().catch((err) => {
  console.error(err);
  process.exit(1);
});