# PMS Rental

Application PMS légère pour la gestion de réservations locatives, avec interface web, backend API Node.js/Express et base PostgreSQL. Le projet couvre aujourd'hui l'authentification, la gestion des rôles, les vues calendrier/tableau, la création et la modification de réservations, ainsi qu'une première brique d'automatisation tarifaire orientée Booking.com.

## État du projet

Le socle applicatif est en place.

Fonctionnel aujourd'hui :
- Authentification par session.
- Gestion des rôles `user`, `manager`, `admin`.
- Vue tableau des réservations.
- Vue calendrier mensuelle / hebdomadaire / annuelle.
- Création de réservation.
- Modification de réservation.
- Page d'administration utilisateurs.
- Préparation de la page d'automatisation tarifaire Booking.com.
- Thèmes UI partagés.

Reste à finaliser :
- Synchronisation Booking.com côté backend.
- Puis synchronisation Airbnb.
- Ensuite, éventuelles synchronisations supplémentaires et industrialisation.

## Objectifs

Ce projet vise à fournir un PMS simple, lisible et évolutif pour une activité locative multi-hébergements, sans dépendre d'une plateforme monolithique externe.

Objectifs principaux :
- Centraliser les réservations.
- Contrôler les accès par rôle.
- Simplifier les opérations quotidiennes.
- Préparer les synchronisations de canaux étape par étape.

## Stack technique

- Frontend : HTML, CSS, JavaScript vanilla.
- Backend principal : Node.js + Express.
- Auth backend : sessions HTTP.
- Base de données : PostgreSQL.
- Versioning : Git + GitHub.

## Fonctionnalités

### Authentification et rôles
- `user` : lecture seule.
- `manager` : lecture + création + modification de réservations.
- `admin` : accès complet, y compris administration des utilisateurs.

### Réservations
- Création d'une réservation.
- Modification d'une réservation existante.
- Affichage tableau.
- Affichage calendrier.
- Gestion des champs métier : client, description, dates, source, prix, statut, hébergement, unités.

### Interfaces
- `index.html` : vue tableau principale.
- `calendar-view.html` : vue calendrier claire.
- `calendar-dark.html` : vue alternative sombre.
- `booking-form.html` : création de réservation.
- `edit-booking.html` : édition de réservation.
- `pricing.html` : pré-interface de synchronisation tarifaire Booking.com.
- `admin-users.html` : gestion utilisateurs.

## Structure recommandée

```text
pms-rental/
├─ frontend/
│  ├─ index.html
│  ├─ calendar-view.html
│  ├─ calendar-dark.html
│  ├─ booking-form.html
│  ├─ edit-booking.html
│  ├─ pricing.html
│  ├─ admin-users.html
│  ├─ style.css
│  ├─ auth.js
│  ├─ booking-form.js
│  ├─ edit-booking.js
│  ├─ calendar-view.js
│  ├─ pricing.js
│  └─ ...
├─ auth-backend/
│  ├─ server.js
│  ├─ authMiddleware.js
│  ├─ db.js
│  ├─ seedAdmin.js
│  ├─ package.json
│  └─ .env
├─ booking-sync/
│  ├─ server.js
│  ├─ routes/
│  ├─ services/
│  ├─ package.json
│  └─ .env
├─ sql/
│  ├─ schema.sql
│  └─ seeds.sql
├─ docs/
│  ├─ ARCHITECTURE.md
│  ├─ ROADMAP.md
│  ├─ SECURITY.md
│  ├─ DEPLOYMENT.md
│  └─ CHANGELOG.md
├─ .env.example
├─ .gitignore
├─ README.md
└─ LICENSE
```

## Installation

### 1. Cloner le dépôt

```bash
git clone https://github.com/Diego-c2c/pms-rental.git
cd pms-rental
```

### 2. Installer les dépendances

Backend auth :

```bash
cd auth-backend
npm install
```

Si un second backend de synchronisation existe déjà :

```bash
cd ../booking-sync
npm install
```

### 3. Configurer l'environnement

Créer les fichiers `.env` à partir de `.env.example`.

Variables typiques :

```env
PORT=8081
SESSION_SECRET=change-me
DB_HOST=localhost
DB_PORT=5432
DB_NAME=pms
DB_USER=postgres
DB_PASSWORD=postgres
FRONTEND_URL=http://localhost:3000
```

### 4. Préparer la base PostgreSQL

- Créer la base.
- Exécuter le schéma SQL.
- Lancer le seed admin / manager si nécessaire.

Exemple :

```bash
node seedAdmin.js
```

### 5. Démarrer les services

Backend auth :

```bash
npm run dev
```

Frontend statique, par exemple :

```bash
npx serve ../frontend
```

## Comptes de test

Exemples de comptes à adapter à votre base :
- `admin@example.com` / `adminpass`
- `manager@example.com` / `managerpass`
- `user@example.com` / `userpass`

## Sécurité Git

Avant tout push public, vérifier que le dépôt ne contient pas :
- `.env`
- secrets de session
- identifiants Booking/Airbnb
- exports base de données sensibles
- cookies, logs ou captures avec données personnelles

## Fichiers à ajouter pour un dépôt propre

À prévoir à la racine :
- `README.md`
- `ARCHITECTURE.md`
- `.gitignore`
- `.env.example`
- `LICENSE`
- `docs/ROADMAP.md`
- `docs/SECURITY.md`
- `docs/DEPLOYMENT.md`
- `CHANGELOG.md`

## Roadmap

### Phase actuelle
- Finaliser la synchronisation Booking.com.

### Phase suivante
- Ajouter la synchronisation Airbnb.

### Après
- Durcir la sécurité.
- Mieux journaliser les synchronisations.
- Ajouter tests et observabilité.
- Préparer déploiement stable.

## Workflow Git recommandé

### Branches
- `main` : stable.
- `develop` : intégration continue.
- `feature/*` : nouvelles fonctionnalités.
- `fix/*` : corrections.

### Exemples

```bash
git checkout -b feature/booking-sync
```

```bash
git checkout -b feature/airbnb-sync
```

## Checklist avant commit

- Vérifier les `.env` ignorés.
- Vérifier l'absence de mots de passe en dur.
- Vérifier les URLs localhost cohérentes.
- Vérifier les rôles sur les pages frontend.
- Vérifier que `user` ne peut pas créer/modifier.
- Vérifier que `manager/admin` peuvent modifier.
- Vérifier la cohérence API frontend/backend.
- Vérifier que les seeds ne dupliquent pas les comptes.

## Licence

Choisir une licence adaptée avant publication publique, par exemple MIT si vous voulez un dépôt ouvert et simple à réutiliser.
