-- Tables pour le PMS

-- 1. Propriétés
CREATE TABLE properties (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    address TEXT,
    airbnb_property_id VARCHAR(100),
    booking_property_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Canaux OTA
CREATE TABLE channels (
    id SERIAL PRIMARY KEY,
    property_id INT NOT NULL REFERENCES properties(id),
    channel_type VARCHAR(50),
    external_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Réservations
CREATE TABLE bookings (
    id SERIAL PRIMARY KEY,
    property_id INT NOT NULL REFERENCES properties(id),
    channel_id INT REFERENCES channels(id),
    external_booking_id VARCHAR(100),
    guest_name VARCHAR(255),
    description VARCHAR(300), 
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    price DECIMAL(10, 2),
    status VARCHAR(50),
    source VARCHAR(50),
    last_synced TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Blocs de calendrier
CREATE TABLE calendar_blocks (
    id SERIAL PRIMARY KEY,
    property_id INT NOT NULL REFERENCES properties(id),
    date_from DATE NOT NULL,
    date_to DATE NOT NULL,
    block_type VARCHAR(50),
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Imports iCal
CREATE TABLE ical_imports (
    id SERIAL PRIMARY KEY,
    property_id INT NOT NULL REFERENCES properties(id),
    channel_id INT REFERENCES channels(id),
    ical_url VARCHAR(500),
    last_fetched TIMESTAMP,
    last_modified TIMESTAMP,
    etag VARCHAR(256),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. Pricing
CREATE TABLE pricing (
    id SERIAL PRIMARY KEY,
    property_id INT NOT NULL REFERENCES properties(id),
    date DATE NOT NULL,
    price DECIMAL(10, 2),
    rule_applied VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(property_id, date)
);

-- Indexes
CREATE INDEX idx_bookings_property ON bookings(property_id);
CREATE INDEX idx_bookings_dates ON bookings(check_in, check_out);
CREATE INDEX idx_calendar_blocks_property ON calendar_blocks(property_id);
CREATE INDEX idx_ical_imports_property ON ical_imports(property_id);
CREATE INDEX idx_pricing_property_date ON pricing(property_id, date);

-- Insertion de test
INSERT INTO properties (name, address, airbnb_property_id, booking_property_id)
VALUES ('Mon AL Portugal', 'Caldas da Rainha, Leiria', 'airbnb_123', 'booking_456');
