-- Schéma PMS Rental - init (structure uniquement)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';
SET default_table_access_method = heap;

--
-- FUNCTION set_updated_at
--
CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;

ALTER FUNCTION public.set_updated_at() OWNER TO pms_user;

--
-- TABLE booking_links
--
CREATE TABLE public.booking_links (
    id integer NOT NULL,
    property_id integer NOT NULL,
    room_id integer,
    booking_hotel_id character varying(100) NOT NULL,
    booking_room_id character varying(100) NOT NULL,
    booking_room_name character varying(255),
    booking_unit_type character varying(50),
    display_order integer DEFAULT 0,
    booking_ical_url text NOT NULL,
    booking_ical_export_url text,
    is_active boolean DEFAULT true NOT NULL,
    last_ical_sync_at timestamp without time zone,
    last_ical_sync_status character varying(50),
    last_ical_sync_error text,
    booking_rate_plan_id character varying(100),
    last_api_sync_at timestamp without time zone,
    last_api_sync_status character varying(50),
    last_api_sync_error text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE public.booking_links OWNER TO pms_user;

CREATE SEQUENCE public.booking_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.booking_links_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.booking_links_id_seq OWNED BY public.booking_links.id;

--
-- TABLE bookings
--
CREATE TABLE public.bookings (
    id integer NOT NULL,
    property_id integer NOT NULL,
    channel_id integer,
    external_booking_id character varying(100),
    guest_name character varying(255),
    check_in date NOT NULL,
    check_out date NOT NULL,
    price numeric(10,2),
    status character varying(50),
    source character varying(50),
    last_synced timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    room_code character varying(50),
    units integer DEFAULT 1 NOT NULL,
    description character varying(300)
);

ALTER TABLE public.bookings OWNER TO pms_user;

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.bookings_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;

--
-- TABLE calendar_blocks
--
CREATE TABLE public.calendar_blocks (
    id integer NOT NULL,
    property_id integer NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    block_type character varying(50),
    reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    room_code character varying(50),
    guest_name text,
    description text,
    price numeric(10,2) DEFAULT 0,
    source text DEFAULT 'booking'::text,
    status text DEFAULT 'confirmed'::text,
    units integer DEFAULT 1
);

ALTER TABLE public.calendar_blocks OWNER TO pms_user;

CREATE SEQUENCE public.calendar_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.calendar_blocks_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.calendar_blocks_id_seq OWNED BY public.calendar_blocks.id;

--
-- TABLE channels
--
CREATE TABLE public.channels (
    id integer NOT NULL,
    property_id integer NOT NULL,
    channel_type character varying(50),
    external_id character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE public.channels OWNER TO pms_user;

CREATE SEQUENCE public.channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.channels_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.channels_id_seq OWNED BY public.channels.id;

--
-- TABLE ical_imports
--
CREATE TABLE public.ical_imports (
    id integer NOT NULL,
    property_id integer NOT NULL,
    channel_id integer,
    ical_url character varying(500),
    last_fetched timestamp without time zone,
    last_modified timestamp without time zone,
    etag character varying(256),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE public.ical_imports OWNER TO pms_user;

CREATE SEQUENCE public.ical_imports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.ical_imports_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.ical_imports_id_seq OWNED BY public.ical_imports.id;

--
-- TABLE pricing
--
CREATE TABLE public.pricing (
    id integer NOT NULL,
    property_id integer NOT NULL,
    date date NOT NULL,
    price numeric(10,2),
    rule_applied character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE public.pricing OWNER TO pms_user;

CREATE SEQUENCE public.pricing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.pricing_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.pricing_id_seq OWNED BY public.pricing.id;

--
-- TABLE properties
--
CREATE TABLE public.properties (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    address text,
    airbnb_property_id character varying(100),
    booking_property_id character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE public.properties OWNER TO pms_user;

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.properties_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;

--
-- TABLE rooms
--
CREATE TABLE public.rooms (
    id integer NOT NULL,
    external_id bigint NOT NULL,
    code character varying(50) NOT NULL,
    label character varying(255) NOT NULL,
    color character varying(7) NOT NULL,
    capacity integer NOT NULL
);

ALTER TABLE public.rooms OWNER TO pms_user;

CREATE SEQUENCE public.rooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.rooms_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.rooms_id_seq OWNED BY public.rooms.id;

--
-- TABLE user_sessions
--
CREATE TABLE public.user_sessions (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);

ALTER TABLE public.user_sessions OWNER TO pms_user;

--
-- TABLE users
--
CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash text NOT NULL,
    role character varying(50) DEFAULT 'admin'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);

ALTER TABLE public.users OWNER TO pms_user;

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.users_id_seq OWNER TO pms_user;

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;

--
-- DEFAULTS on id columns
--
ALTER TABLE ONLY public.booking_links
    ALTER COLUMN id SET DEFAULT nextval('public.booking_links_id_seq'::regclass);

ALTER TABLE ONLY public.bookings
    ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);

ALTER TABLE ONLY public.calendar_blocks
    ALTER COLUMN id SET DEFAULT nextval('public.calendar_blocks_id_seq'::regclass);

ALTER TABLE ONLY public.channels
    ALTER COLUMN id SET DEFAULT nextval('public.channels_id_seq'::regclass);

ALTER TABLE ONLY public.ical_imports
    ALTER COLUMN id SET DEFAULT nextval('public.ical_imports_id_seq'::regclass);

ALTER TABLE ONLY public.pricing
    ALTER COLUMN id SET DEFAULT nextval('public.pricing_id_seq'::regclass);

ALTER TABLE ONLY public.properties
    ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);

ALTER TABLE ONLY public.rooms
    ALTER COLUMN id SET DEFAULT nextval('public.rooms_id_seq'::regclass);

ALTER TABLE ONLY public.users
    ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);

--
-- PRIMARY KEYS & UNIQUE CONSTRAINTS
--
ALTER TABLE ONLY public.booking_links
    ADD CONSTRAINT booking_links_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.calendar_blocks
    ADD CONSTRAINT calendar_blocks_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.ical_imports
    ADD CONSTRAINT ical_imports_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pricing
    ADD CONSTRAINT pricing_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.pricing
    ADD CONSTRAINT pricing_property_id_date_key UNIQUE (property_id, date);

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.booking_links
    ADD CONSTRAINT uq_booking_links_hotel_room UNIQUE (booking_hotel_id, booking_room_id);

ALTER TABLE ONLY public.booking_links
    ADD CONSTRAINT uq_booking_links_room UNIQUE (booking_room_id);

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (sid);

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);

--
-- INDEXES
--
CREATE INDEX idx_booking_links_active ON public.booking_links USING btree (is_active);

CREATE INDEX idx_booking_links_booking_hotel_id ON public.booking_links USING btree (booking_hotel_id);

CREATE INDEX idx_booking_links_property_active ON public.booking_links USING btree (property_id, is_active);

CREATE INDEX idx_booking_links_property_id ON public.booking_links USING btree (property_id);

CREATE INDEX idx_booking_links_room_id ON public.booking_links USING btree (room_id);

CREATE INDEX idx_bookings_dates ON public.bookings USING btree (check_in, check_out);

CREATE INDEX idx_bookings_property ON public.bookings USING btree (property_id);

CREATE INDEX idx_calendar_blocks_property ON public.calendar_blocks USING btree (property_id);

CREATE INDEX idx_calendar_blocks_property_date ON public.calendar_blocks USING btree (property_id, date_from, date_to);

CREATE INDEX idx_calendar_blocks_property_room_date ON public.calendar_blocks USING btree (property_id, room_code, date_from, date_to);

CREATE INDEX idx_ical_imports_property ON public.ical_imports USING btree (property_id);

CREATE INDEX idx_pricing_property_date ON public.pricing USING btree (property_id, date);

CREATE UNIQUE INDEX idx_rooms_code ON public.rooms USING btree (code);

CREATE UNIQUE INDEX idx_rooms_external_id ON public.rooms USING btree (external_id);

CREATE INDEX idx_user_sessions_expire ON public.user_sessions USING btree (expire);

--
-- TRIGGERS
--
CREATE TRIGGER trg_booking_links_updated_at
BEFORE UPDATE ON public.booking_links
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

--
-- FOREIGN KEYS
--
ALTER TABLE ONLY public.booking_links
    ADD CONSTRAINT booking_links_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id);

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);

ALTER TABLE ONLY public.calendar_blocks
    ADD CONSTRAINT calendar_blocks_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);

ALTER TABLE ONLY public.ical_imports
    ADD CONSTRAINT ical_imports_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id);

ALTER TABLE ONLY public.ical_imports
    ADD CONSTRAINT ical_imports_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);

ALTER TABLE ONLY public.pricing
    ADD CONSTRAINT pricing_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id);