BEGIN;

-- 1) Propriété principale
INSERT INTO public.properties (name, address, airbnb_property_id, booking_property_id)
SELECT
  'Cloud to Chill',
  'Caldas da Rainha, Portugal',
  NULL,
  NULL
WHERE NOT EXISTS (
  SELECT 1
  FROM public.properties
  WHERE name = 'Cloud to Chill'
);

-- 2) Rooms (chambres)
INSERT INTO public.rooms (external_id, code, label, color, capacity)
VALUES
  (1001, 'raspberry',   'Raspberry Room',               '#DE7F74', 2),
  (1002, 'blueberry',   'Blueberry Room',               '#64ABDA', 2),
  (1003, 'maracuja',    'Maracuja Room',                '#E9AD6E', 2),
  (1004, 'surfhouse',   'Cloud to Chill Surf House',    '#7FC7B7', 6),
  (1005, 'female_dorm', 'Bed in Shared Female Room',    '#E9BC8C', 1)
ON CONFLICT (code) DO NOTHING;

-- 3) Channel direct
INSERT INTO public.channels (property_id, channel_type, external_id, created_at)
SELECT p.id, 'direct', 'direct-main', COALESCE(
  (SELECT created_at FROM public.channels c
   WHERE c.property_id = p.id
     AND c.channel_type = 'direct'
     AND c.external_id = 'direct-main'
   LIMIT 1),
  CURRENT_TIMESTAMP
)
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1
    FROM public.channels c
    WHERE c.property_id = p.id
      AND c.channel_type = 'direct'
      AND c.external_id = 'direct-main'
  );

-- 4) Liaisons Booking.com (booking_links)
INSERT INTO public.booking_links (
  property_id,
  room_id,
  booking_hotel_id,
  booking_room_id,
  booking_room_name,
  booking_unit_type,
  display_order,
  booking_ical_url,
  booking_ical_export_url,
  is_active,
  last_ical_sync_at,
  last_ical_sync_status,
  last_ical_sync_error,
  booking_rate_plan_id,
  last_api_sync_at,
  last_api_sync_status,
  last_api_sync_error,
  metadata,
  created_at,
  updated_at
)
SELECT
  p.id,
  r.id,
  '5207416',
  '520741601',
  'Raspberry Room',
  'room',
  0,
  'https://ical.booking.com/v1/export?t=d5ff92f2-52dc-4701-91ab-73c95bacde32',
  NULL,
  TRUE,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM public.properties p
JOIN public.rooms r ON r.code = 'raspberry'
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.booking_links bl
    WHERE bl.booking_hotel_id = '5207416'
      AND bl.booking_room_id   = '520741601'
  );

INSERT INTO public.booking_links (
  property_id,
  room_id,
  booking_hotel_id,
  booking_room_id,
  booking_room_name,
  booking_unit_type,
  display_order,
  booking_ical_url,
  booking_ical_export_url,
  is_active,
  last_ical_sync_at,
  last_ical_sync_status,
  last_ical_sync_error,
  booking_rate_plan_id,
  last_api_sync_at,
  last_api_sync_status,
  last_api_sync_error,
  metadata,
  created_at,
  updated_at
)
SELECT
  p.id,
  r.id,
  '5207416',
  '520741602',
  'Blueberry Room',
  'room',
  0,
  'https://ical.booking.com/v1/export?t=70820f8b-5c91-4d3d-bd27-2c3aacd3ae9c',
  NULL,
  TRUE,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM public.properties p
JOIN public.rooms r ON r.code = 'blueberry'
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.booking_links bl
    WHERE bl.booking_hotel_id = '5207416'
      AND bl.booking_room_id   = '520741602'
  );

INSERT INTO public.booking_links (
  property_id,
  room_id,
  booking_hotel_id,
  booking_room_id,
  booking_room_name,
  booking_unit_type,
  display_order,
  booking_ical_url,
  booking_ical_export_url,
  is_active,
  last_ical_sync_at,
  last_ical_sync_status,
  last_ical_sync_error,
  booking_rate_plan_id,
  last_api_sync_at,
  last_api_sync_status,
  last_api_sync_error,
  metadata,
  created_at,
  updated_at
)
SELECT
  p.id,
  r.id,
  '5207416',
  '520741603',
  'Maracuja Room',
  'room',
  0,
  'https://ical.booking.com/v1/export?t=6c68751d-5b47-4c36-ac5e-0c34060e30bb',
  NULL,
  TRUE,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM public.properties p
JOIN public.rooms r ON r.code = 'maracuja'
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.booking_links bl
    WHERE bl.booking_hotel_id = '5207416'
      AND bl.booking_room_id   = '520741603'
  );

INSERT INTO public.booking_links (
  property_id,
  room_id,
  booking_hotel_id,
  booking_room_id,
  booking_room_name,
  booking_unit_type,
  display_order,
  booking_ical_url,
  booking_ical_export_url,
  is_active,
  last_ical_sync_at,
  last_ical_sync_status,
  last_ical_sync_error,
  booking_rate_plan_id,
  last_api_sync_at,
  last_api_sync_status,
  last_api_sync_error,
  metadata,
  created_at,
  updated_at
)
SELECT
  p.id,
  r.id,
  '5207416',
  '520741604',
  'Cloud to Chill Surf House',
  'room',
  0,
  'https://ical.booking.com/v1/export?t=b4ed470a-0a04-407b-8a0e-633b82c60552',
  NULL,
  TRUE,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM public.properties p
JOIN public.rooms r ON r.code = 'surfhouse'
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.booking_links bl
    WHERE bl.booking_hotel_id = '5207416'
      AND bl.booking_room_id   = '520741604'
  );

INSERT INTO public.booking_links (
  property_id,
  room_id,
  booking_hotel_id,
  booking_room_id,
  booking_room_name,
  booking_unit_type,
  display_order,
  booking_ical_url,
  booking_ical_export_url,
  is_active,
  last_ical_sync_at,
  last_ical_sync_status,
  last_ical_sync_error,
  booking_rate_plan_id,
  last_api_sync_at,
  last_api_sync_status,
  last_api_sync_error,
  metadata,
  created_at,
  updated_at
)
SELECT
  p.id,
  r.id,
  '5207416',
  '520741605',
  'Bed in Shared Female Room',
  'room',
  0,
  'https://ical.booking.com/v1/export?t=707ab182-ea56-481a-bcb6-f7bd270db07a',
  NULL,
  TRUE,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
FROM public.properties p
JOIN public.rooms r ON r.code = 'female_dorm'
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.booking_links bl
    WHERE bl.booking_hotel_id = '5207416'
      AND bl.booking_room_id   = '520741605'
  );

-- 5) Bookings de test
INSERT INTO public.bookings (
  property_id,
  channel_id,
  external_booking_id,
  guest_name,
  check_in,
  check_out,
  price,
  status,
  source,
  last_synced,
  created_at,
  room_code,
  units,
  description
)
SELECT
  p.id,
  c.id,
  NULL,
  'Ambre +2 Pax',
  DATE '2026-03-26',
  DATE '2026-04-12',
  590.00,
  'confirmed',
  'direct',
  TIMESTAMP '2026-04-08 09:26:06.420135',
  TIMESTAMP '2026-04-07 23:37:17.420782',
  'raspberry',
  1,
  'Ambre 200\nLeo reste 260-25=>235\nMarco 340-25=>315 reste 550'
FROM public.properties p
JOIN public.channels c ON c.property_id = p.id AND c.channel_type = 'direct' AND c.external_id = 'direct-main'
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.bookings b
    WHERE b.property_id = p.id
      AND b.guest_name  = 'Ambre +2 Pax'
      AND b.check_in    = DATE '2026-03-26'
      AND b.check_out   = DATE '2026-04-12'
      AND b.room_code   = 'raspberry'
  );

INSERT INTO public.bookings (
  property_id,
  channel_id,
  external_booking_id,
  guest_name,
  check_in,
  check_out,
  price,
  status,
  source,
  last_synced,
  created_at,
  room_code,
  units,
  description
)
SELECT
  p.id,
  c.id,
  NULL,
  'Sophie mum Louise',
  DATE '2026-04-05',
  DATE '2026-04-13',
  160.00,
  'confirmed',
  'direct',
  TIMESTAMP '2026-04-08 09:26:59.441401',
  TIMESTAMP '2026-04-08 09:26:59.441852',
  'female_dorm',
  1,
  ''
FROM public.properties p
JOIN public.channels c ON c.property_id = p.id AND c.channel_type = 'direct' AND c.external_id = 'direct-main'
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.bookings b
    WHERE b.property_id = p.id
      AND b.guest_name  = 'Sophie mum Louise'
      AND b.check_in    = DATE '2026-04-05'
      AND b.check_out   = DATE '2026-04-13'
      AND b.room_code   = 'female_dorm'
  );

INSERT INTO public.bookings (
  property_id,
  channel_id,
  external_booking_id,
  guest_name,
  check_in,
  check_out,
  price,
  status,
  source,
  last_synced,
  created_at,
  room_code,
  units,
  description
)
SELECT
  p.id,
  c.id,
  NULL,
  'Doude 1 Pax',
  DATE '2026-04-16',
  DATE '2026-04-25',
  180.00,
  'confirmed',
  'direct',
  TIMESTAMP '2026-04-08 09:28:55.63547',
  TIMESTAMP '2026-04-08 09:28:55.63586',
  'blueberry',
  1,
  'blue si Raps pas prete'
FROM public.properties p
JOIN public.channels c ON c.property_id = p.id AND c.channel_type = 'direct' AND c.external_id = 'direct-main'
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.bookings b
    WHERE b.property_id = p.id
      AND b.guest_name  = 'Doude 1 Pax'
      AND b.check_in    = DATE '2026-04-16'
      AND b.check_out   = DATE '2026-04-25'
      AND b.room_code   = 'blueberry'
  );

-- 6) Calendar blocks de test
INSERT INTO public.calendar_blocks (
  property_id,
  date_from,
  date_to,
  block_type,
  reason,
  created_at,
  room_code,
  guest_name,
  description,
  price,
  source,
  status,
  units
)
SELECT
  p.id,
  DATE '2026-04-08',
  DATE '2026-04-16',
  'closed',
  'CLOSED - Not available',
  TIMESTAMP '2026-04-08 00:20:15.36459',
  'raspberry',
  NULL,
  NULL,
  0.00,
  'booking',
  'confirmed',
  1
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.calendar_blocks cb
    WHERE cb.property_id = p.id
      AND cb.room_code   = 'raspberry'
      AND cb.date_from   = DATE '2026-04-08'
      AND cb.date_to     = DATE '2026-04-16'
  );

INSERT INTO public.calendar_blocks (
  property_id,
  date_from,
  date_to,
  block_type,
  reason,
  created_at,
  room_code,
  guest_name,
  description,
  price,
  source,
  status,
  units
)
SELECT
  p.id,
  DATE '2026-05-08',
  DATE '2026-05-10',
  'closed',
  'CLOSED - Not available',
  TIMESTAMP '2026-04-08 00:20:15.367813',
  'raspberry',
  NULL,
  NULL,
  0.00,
  'booking',
  'confirmed',
  1
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.calendar_blocks cb
    WHERE cb.property_id = p.id
      AND cb.room_code   = 'raspberry'
      AND cb.date_from   = DATE '2026-05-08'
      AND cb.date_to     = DATE '2026-05-10'
  );

INSERT INTO public.calendar_blocks (
  property_id,
  date_from,
  date_to,
  block_type,
  reason,
  created_at,
  room_code,
  guest_name,
  description,
  price,
  source,
  status,
  units
)
SELECT
  p.id,
  DATE '2026-08-22',
  DATE '2026-08-24',
  'closed',
  'CLOSED - Not available',
  TIMESTAMP '2026-04-08 00:20:15.369669',
  'raspberry',
  NULL,
  NULL,
  0.00,
  'booking',
  'confirmed',
  1
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.calendar_blocks cb
    WHERE cb.property_id = p.id
      AND cb.room_code   = 'raspberry'
      AND cb.date_from   = DATE '2026-08-22'
      AND cb.date_to     = DATE '2026-08-24'
  );

INSERT INTO public.calendar_blocks (
  property_id,
  date_from,
  date_to,
  block_type,
  reason,
  created_at,
  room_code,
  guest_name,
  description,
  price,
  source,
  status,
  units
)
SELECT
  p.id,
  DATE '2026-11-30',
  DATE '2027-10-08',
  'closed',
  'CLOSED - Not available',
  TIMESTAMP '2026-04-08 00:20:15.373719',
  'raspberry',
  NULL,
  NULL,
  0.00,
  'booking',
  'confirmed',
  1
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.calendar_blocks cb
    WHERE cb.property_id = p.id
      AND cb.room_code   = 'raspberry'
      AND cb.date_from   = DATE '2026-11-30'
      AND cb.date_to     = DATE '2027-10-08'
  );

INSERT INTO public.calendar_blocks (
  property_id,
  date_from,
  date_to,
  block_type,
  reason,
  created_at,
  room_code,
  guest_name,
  description,
  price,
  source,
  status,
  units
)
SELECT
  p.id,
  DATE '2026-04-08',
  DATE '2026-04-20',
  'closed',
  'CLOSED - Not available',
  TIMESTAMP '2026-04-08 00:20:15.61349',
  'blueberry',
  NULL,
  NULL,
  0.00,
  'booking',
  'confirmed',
  1
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.calendar_blocks cb
    WHERE cb.property_id = p.id
      AND cb.room_code   = 'blueberry'
      AND cb.date_from   = DATE '2026-04-08'
      AND cb.date_to     = DATE '2026-04-20'
  );

INSERT INTO public.calendar_blocks (
  property_id,
  date_from,
  date_to,
  block_type,
  reason,
  created_at,
  room_code,
  guest_name,
  description,
  price,
  source,
  status,
  units
)
SELECT
  p.id,
  DATE '2026-11-30',
  DATE '2027-10-08',
  'closed',
  'CLOSED - Not available',
  TIMESTAMP '2026-04-08 00:20:15.615575',
  'blueberry',
  NULL,
  NULL,
  0.00,
  'booking',
  'confirmed',
  1
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.calendar_blocks cb
    WHERE cb.property_id = p.id
      AND cb.room_code   = 'blueberry'
      AND cb.date_from   = DATE '2026-11-30'
      AND cb.date_to     = DATE '2027-10-08'
  );

INSERT INTO public.calendar_blocks (
  property_id,
  date_from,
  date_to,
  block_type,
  reason,
  created_at,
  room_code,
  guest_name,
  description,
  price,
  source,
  status,
  units
)
SELECT
  p.id,
  DATE '2026-04-08',
  DATE '2027-10-08',
  'closed',
  'CLOSED - Not available',
  TIMESTAMP '2026-04-08 00:20:15.950852',
  'maracuja',
  NULL,
  NULL,
  0.00,
  'booking',
  'confirmed',
  1
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
  AND NOT EXISTS (
    SELECT 1 FROM public.calendar_blocks cb
    WHERE cb.property_id = p.id
      AND cb.room_code   = 'maracuja'
      AND cb.date_from   = DATE '2026-04-08'
      AND cb.date_to     = DATE '2027-10-08'
  );

COMMIT;