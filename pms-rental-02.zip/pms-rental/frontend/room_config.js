/* ============================================================
   CONFIG UNIQUE DES CHAMBRES
   ------------------------------------------------------------
   Ce fichier devient la source unique pour :
   - les room_code PMS
   - les bookingRoomId Booking/iCal
   - les noms affichés
   - les couleurs du calendrier
   ============================================================ */

window.ROOM_CONFIG = {
  raspberry: {
    roomCode: 'raspberry',
    bookingRoomId: '520741601',
    name: 'Raspberry Room',
    short: 'Room2',
    bg: '#DE7F74',
    text: '#000000',
    optionTextColor: '#b30059'
  },
  blueberry: {
    roomCode: 'blueberry',
    bookingRoomId: '520741602',
    name: 'Blueberry Room',
    short: 'Room1',
    bg: '#64ABDA',
    text: '#000000',
    optionTextColor: '#006699'
  },
  maracuja: {
    roomCode: 'maracuja',
    bookingRoomId: '520741603',
    name: 'Maracuja Room',
    short: 'Room3',
    bg: '#E9AD6E',
    text: '#000000',
    optionTextColor: '#856404'
  },
  surfhouse: {
    roomCode: 'surfhouse',
    bookingRoomId: '520741604',
    name: 'Cloud to Chill Surf House',
    short: 'House',
    bg: '#7FC7B7',
    text: '#000000',
    optionTextColor: '#495057'
  },
  female_dorm: {
    roomCode: 'female_dorm',
    bookingRoomId: '520741605',
    name: 'Bed in Shared Female Room',
    short: 'Bed',
    bg: '#e9bc8c',
    text: '#000000',
    optionTextColor: '#8a6d3b'
  }
};

/* ------------------------------------------------------------
   Compatibilité avec le code existant du calendrier
   Si calendar-view.js utilise déjà ROOM_DISPLAY,
   on le reconstruit automatiquement ici.
   ------------------------------------------------------------ */
window.ROOM_DISPLAY = Object.fromEntries(
  Object.values(window.ROOM_CONFIG).map(room => [
    room.roomCode,
    {
      short: room.short,
      bg: room.bg,
      text: room.text
    }
  ])
);

/* ------------------------------------------------------------
   Fonction utilitaire :
   retrouver une room à partir du bookingRoomId
   Exemple : 520741601 -> raspberry
   ------------------------------------------------------------ */
window.getRoomByBookingRoomId = function (bookingRoomId) {
  return Object.values(window.ROOM_CONFIG).find(
    room => room.bookingRoomId === String(bookingRoomId)
  ) || null;
};