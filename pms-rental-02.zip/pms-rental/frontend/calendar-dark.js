/**
 * CALENDAR-VIEW.JS - VUE CALENDRIER (1W / 1M / 3M)
 *
 * - Vue 1w : semaine (7 jours)
 * - Vue 1m : mois (grille classique)
 * - Vue 3m : année (12 mois dans une seule grille)
 */

// =======================
// VARIABLES GLOBALES
// =======================

let currentDate = new Date();   // base pour le rendu
let bookings = [];              // réservations chargées
let viewMode = '1m';            // '1w' | '1m' | '3m'
let currentUser = null;         // alimenté via auth.js

// =======================
// CONFIG ROOMS / COULEURS
// =======================

const ROOM_COLORS = {
  raspberry:   { bg: '#DE7F74', text: '#b30059', label: 'Raspberry Room 2' },
  blueberry:   { bg: '#64ABDA', text: '#006699', label: 'Blueberry Room 1' },
  maracuja:    { bg: '#E9AD6E', text: '#856404', label: 'Maracuja Room 3' },
  surfhouse:   { bg: '#7FC7B7', text: '#495057', label: 'House' },
  female_dorm: { bg: '#e9bc8c', text: '#8a6d3b', label: 'Bed in a Dorm' }
};

const ROOM_DISPLAY = {
  raspberry:   { short: 'Room2', bg: '#DE7F74', text: '#000000' },
  blueberry:   { short: 'Room1', bg: '#64ABDA', text: '#000000' },
  maracuja:    { short: 'Room3', bg: '#E9AD6E', text: '#000000' },
  surfhouse:   { short: 'House', bg: '#7FC7B7', text: '#000000' },
  female_dorm: { short: 'Bed',   bg: '#e9bc8c', text: '#000000' }
};

const MAX_LINES_PER_DAY = 6;

// =======================
// UTILITAIRES
// =======================

function getSourceIcon(source) {
  if (!source) return '';
  const s = source.toLowerCase();
  if (s === 'booking') return '🏨';
  if (s === 'airbnb')  return '🏠';
  return '📞';
}

function normalizeCurrentDateToFirstOfMonth() {
  currentDate.setDate(1);
}

function getISOWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return weekNo;
}

// Récupère l'utilisateur courant via auth.js
async function loadCurrentUser() {
  if (typeof getCurrentUser === 'function') {
    currentUser = await getCurrentUser();
  }
}

function isReadOnlyUser() {
  return currentUser && currentUser.role === 'user';
}

// =======================
// CHARGEMENT DES RESERVATIONS
// =======================

async function loadBookings() {
  try {
    const response = await fetch('http://localhost:8080/api/bookings');
    bookings = await response.json();
    console.log('✅ Réservations:', bookings);
  } catch (error) {
    console.error('❌ Erreur lors du chargement:', error);
  }
}

// =======================
// NAVIGATION
// =======================

function previousMonth() {
  if (viewMode === '1m') {
    currentDate.setMonth(currentDate.getMonth() - 1);
    normalizeCurrentDateToFirstOfMonth();
  } else if (viewMode === '3m') {
    currentDate.setFullYear(currentDate.getFullYear() - 1);
    normalizeCurrentDateToFirstOfMonth();
  } else if (viewMode === '1w') {
    currentDate.setDate(currentDate.getDate() - 7);
  }
  renderCalendar();
}

function nextMonth() {
  if (viewMode === '1m') {
    currentDate.setMonth(currentDate.getMonth() + 1);
    normalizeCurrentDateToFirstOfMonth();
  } else if (viewMode === '3m') {
    currentDate.setFullYear(currentDate.getFullYear() + 1);
    normalizeCurrentDateToFirstOfMonth();
  } else if (viewMode === '1w') {
    currentDate.setDate(currentDate.getDate() + 7);
  }
  renderCalendar();
}

function goToToday() {
  currentDate = new Date();
  if (viewMode !== '1w') {
    normalizeCurrentDateToFirstOfMonth();
  }
  renderCalendar();
}

function setViewMode(mode) {
  viewMode = mode;

  const btn1w  = document.getElementById('view-1w');
  const btn1m  = document.getElementById('view-1m');
  const btn3m  = document.getElementById('view-3m');
  const btnPrev = document.getElementById('btn-prev');
  const btnNext = document.getElementById('btn-next');

  if (btn1w && btn1m && btn3m) {
    btn1w.classList.toggle('active', viewMode === '1w');
    btn1m.classList.toggle('active', viewMode === '1m');
    btn3m.classList.toggle('active', viewMode === '3m');
  }

  if (btnPrev && btnNext) {
    if (viewMode === '1m') {
      btnPrev.textContent = '← Mois précédent';
      btnNext.textContent = 'Mois suivant →';
    } else if (viewMode === '3m') {
      btnPrev.textContent = '← Année précédente';
      btnNext.textContent = 'Année suivante →';
    } else if (viewMode === '1w') {
      btnPrev.textContent = '← Semaine précédente';
      btnNext.textContent = 'Semaine suivante →';
    }
  }

  if (viewMode === '1w') {
    currentDate = new Date();
  } else {
    normalizeCurrentDateToFirstOfMonth();
  }

  renderCalendar();
}

// =======================
// RENDU CALENDRIER
// =======================

function renderCalendar() {
  console.log('renderCalendar called', viewMode);

  if (viewMode === '1w') {
    renderWeekView();
    return;
  }

  const year  = currentDate.getFullYear();
  const today = new Date();
  let periodStart, periodEnd, headerText;

  if (viewMode === '1m') {
    periodStart = new Date(year, currentDate.getMonth(), 1);
    periodEnd   = new Date(year, currentDate.getMonth() + 1, 0);

    const monthNames = [
      'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ];
    headerText = monthNames[periodStart.getMonth()] + ' ' + year;
  } else {
    periodStart = new Date(year, 0, 1);
    periodEnd   = new Date(year, 11, 31);
    headerText  = String(year);
  }

  const monthYearEl = document.getElementById('monthYear');
  if (monthYearEl) {
    monthYearEl.textContent = headerText;
  }

  let html = '';

  const dayNames = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
  dayNames.forEach(day => {
    html += '<div class="calendar-day-header">' + day + '</div>';
  });

  const monthShort = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin',
    'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];

  const gridStart = new Date(periodStart);
  const startDayOfWeek = gridStart.getDay();
  gridStart.setDate(gridStart.getDate() - startDayOfWeek);

  const gridEnd = new Date(periodEnd);
  const endDayOfWeek = gridEnd.getDay();
  gridEnd.setDate(gridEnd.getDate() + (6 - endDayOfWeek));

  const cursor = new Date(gridStart);

  while (cursor <= gridEnd) {
    const inPeriod = cursor >= periodStart && cursor <= periodEnd;

    const isToday =
      cursor.getFullYear() === today.getFullYear() &&
      cursor.getMonth() === today.getMonth() &&
      cursor.getDate() === today.getDate();

    let dayClasses = 'calendar-day';
    if (!inPeriod) dayClasses += ' other-month';
    if (isToday)   dayClasses += ' today';

    const dayLabel = (viewMode === '1m')
      ? String(cursor.getDate())
      : cursor.getDate() + ' ' + monthShort[cursor.getMonth()];

    let bookingsHtml = '';

    if (inPeriod) {
      const bookingsForDay = bookings.filter(b => {
        const checkIn  = new Date(b.check_in);
        const checkOut = new Date(b.check_out);
        return cursor >= checkIn && cursor < checkOut;
      });

      bookingsForDay.slice(0, MAX_LINES_PER_DAY).forEach(b => {
        const room       = ROOM_DISPLAY[b.room_code] || null;
        const roomLetter = room ? room.short : '?';
        const bg         = room ? room.bg   : '#e7f3ff';
        const textColor  = room ? room.text : '#333';
        const sourceIcon = getSourceIcon(b.source);
        const guest      = b.guest || b.guest_name || 'Unknown';
        const description = b.description || '';

        const checkIn = new Date(b.check_in);
        const isCheckInDay =
          cursor.getFullYear() === checkIn.getFullYear() &&
          cursor.getMonth() === checkIn.getMonth() &&
          cursor.getDate() === checkIn.getDate();

        let tooltipText = `${roomLetter} ${guest} ${sourceIcon}`;
        if (description) {
          tooltipText += ` — ${description}`;
        }
        const safeTooltip = tooltipText.replace(/"/g, '&quot;');
        const visibleText = `${roomLetter} ${guest} ${sourceIcon}`;

        if (isCheckInDay) {
          bookingsHtml +=
            '<div class="calendar-booking calendar-booking-start" ' +
            'style="background-color:' + bg + '; color:' + textColor + '; border-left-color:' + textColor + ';" ' +
            'draggable="false" data-booking-id="' + b.id + '" ' +
            'onclick="editBooking(' + b.id + ')" ' +
            'title="' + safeTooltip + '">' +
              visibleText +
            '</div>';
        } else {
          bookingsHtml +=
            '<div class="calendar-booking calendar-booking-continue" ' +
            'style="background-color:' + bg + '; border-left-color:' + bg + ';" ' +
            'data-booking-id="' + b.id + '" ' +
            'onclick="editBooking(' + b.id + ')" ' +
            'title="' + safeTooltip + '">' +
            '</div>';
        }
      });

      const emptyLinesCount = Math.max(0, MAX_LINES_PER_DAY - bookingsForDay.length);
      for (let i = 0; i < emptyLinesCount; i++) {
        bookingsHtml += '<div class="calendar-booking calendar-booking-empty"></div>';
      }
    }

    html +=
      '<div class="' + dayClasses + '" ' +
      'data-date="' + cursor.toISOString().slice(0, 10) + '">' +
        '<div class="calendar-day-number">' + dayLabel + '</div>' +
        '<div class="calendar-bookings">' + bookingsHtml + '</div>' +
      '</div>';

    cursor.setDate(cursor.getDate() + 1);
  }

  const calendarEl = document.getElementById('calendar');
  if (calendarEl) {
    calendarEl.classList.remove('view-week');
    calendarEl.innerHTML = html;
  }
}

// =======================
// RENDU SEMAINE
// =======================

function renderWeekView() {
  const ref = new Date(currentDate);
  const year = ref.getFullYear();

  const weekStart = new Date(ref);
  const jsDay = weekStart.getDay();
  const diffToMonday = (jsDay === 0 ? -6 : 1 - jsDay);
  weekStart.setDate(weekStart.getDate() + diffToMonday);

  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);

  const weekNumber = getISOWeekNumber(weekStart);

  const monthYearEl = document.getElementById('monthYear');
  if (monthYearEl) {
    monthYearEl.textContent = `Semaine ${weekNumber} - ${year}`;
  }

  const dayNames   = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  const monthShort = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin',
    'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];

  let html = '';

  dayNames.forEach(day => {
    html += '<div class="calendar-day-header">' + day + '</div>';
  });

  const cursor    = new Date(weekStart);
  const todayReal = new Date();

  for (let i = 0; i < 7; i++) {
    const isToday =
      cursor.getFullYear() === todayReal.getFullYear() &&
      cursor.getMonth() === todayReal.getMonth() &&
      cursor.getDate() === todayReal.getDate();

    let dayClasses = 'calendar-day';
    if (isToday) dayClasses += ' today';

    const dayLabel = cursor.getDate() + ' ' + monthShort[cursor.getMonth()];

    const bookingsForDay = bookings.filter(b => {
      const checkIn  = new Date(b.check_in);
      const checkOut = new Date(b.check_out);
      return cursor >= checkIn && cursor < checkOut;
    });

    let bookingsHtml = '';

    bookingsForDay.slice(0, MAX_LINES_PER_DAY).forEach(b => {
      const room       = ROOM_DISPLAY[b.room_code] || null;
      const roomLetter = room ? room.short : '?';
      const bg         = room ? room.bg   : '#e7f3ff';
      const textColor  = room ? room.text : '#333';
      const sourceIcon = getSourceIcon(b.source);
      const guest      = b.guest || b.guest_name || 'Unknown';
      const description = b.description || '';

      const checkIn = new Date(b.check_in);
      const isCheckInDay =
        cursor.getFullYear() === checkIn.getFullYear() &&
        cursor.getMonth() === checkIn.getMonth() &&
        cursor.getDate() === checkIn.getDate();

      let tooltipText = `${roomLetter} ${guest} ${sourceIcon}`;
      if (description) {
        tooltipText += ` — ${description}`;
      }
      const safeTooltip = tooltipText.replace(/"/g, '&quot;');
      const visibleText = `${roomLetter} ${guest} ${sourceIcon}`;

      if (isCheckInDay) {
        bookingsHtml +=
          '<div class="calendar-booking calendar-booking-start" ' +
          'style="background-color:' + bg + '; color:' + textColor + '; border-left-color:' + textColor + ';" ' +
          'draggable="false" data-booking-id="' + b.id + '" ' +
          'onclick="editBooking(' + b.id + ')" ' +
          'title="' + safeTooltip + '">' +
            visibleText +
          '</div>';
      } else {
        bookingsHtml +=
          '<div class="calendar-booking calendar-booking-continue" ' +
          'style="background-color:' + bg + '; border-left-color:' + bg + ';" ' +
          'data-booking-id="' + b.id + '" ' +
          'onclick="editBooking(' + b.id + ')" ' +
          'title="' + safeTooltip + '">' +
          '</div>';
      }
    });

    const emptyLinesCount = Math.max(0, MAX_LINES_PER_DAY - bookingsForDay.length);
    for (let j = 0; j < emptyLinesCount; j++) {
      bookingsHtml += '<div class="calendar-booking calendar-booking-empty"></div>';
    }

    html +=
      '<div class="' + dayClasses + '" data-date="' + cursor.toISOString().slice(0, 10) + '">' +
        '<div class="calendar-day-number">' + dayLabel + '</div>' +
        '<div class="calendar-bookings">' + bookingsHtml + '</div>' +
      '</div>';

    cursor.setDate(cursor.getDate() + 1);
  }

  const calendarEl = document.getElementById('calendar');
  if (calendarEl) {
    calendarEl.classList.add('view-week');
    calendarEl.innerHTML = html;
  }
}

// =======================
// EDITION DE RESERVATION
// =======================

function editBooking(id) {
  if (isReadOnlyUser()) {
    return;
  }
  window.location.href = 'edit-booking.html?id=' + id;
}

// =======================
// GESTION THEME (gardée pour compat)
// =======================

function applyTheme(theme) {
  document.body.classList.remove('theme-dark', 'theme-ocean');
  if (theme === 'dark')  document.body.classList.add('theme-dark');
  if (theme === 'ocean') document.body.classList.add('theme-ocean');
  localStorage.setItem('pms-theme', theme);
}

// =======================
// INITIALISATION
// =======================

document.addEventListener('DOMContentLoaded', async () => {
  // auth.js remplit déjà l'UI, ici on complète côté JS pur
  await loadCurrentUser();

  const savedTheme = localStorage.getItem('pms-theme') || 'light';
  applyTheme(savedTheme);

  const themeSelect = document.getElementById('theme-select');
  if (themeSelect) {
    themeSelect.value = savedTheme;
    themeSelect.addEventListener('change', () => {
      applyTheme(themeSelect.value);
    });
  }

  currentDate = new Date();
  normalizeCurrentDateToFirstOfMonth();

  await loadBookings();
  renderCalendar();

  const addBtn = document.getElementById('addBookingBtn');
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      if (isReadOnlyUser()) return;
      window.location.href = 'booking-form.html';
    });
  }
});