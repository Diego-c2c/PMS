const API_BASE = 'http://localhost:8081';
const LOGIN_PAGE = 'http://localhost:3000/login.html';
const HOME_PAGE = 'http://localhost:3000/index.html';

async function getCurrentUser() {
  try {
    const res = await fetch(`${API_BASE}/api/auth/me`, {
      credentials: 'include'
    });

    if (!res.ok) {
      return null;
    }

    const data = await res.json();

    if (!data.authenticated || !data.user) {
      return null;
    }

    return data.user; // { id, email, role }
  } catch (err) {
    console.error('Erreur getCurrentUser:', err);
    return null;
  }
}

async function requireAuth() {
  const user = await getCurrentUser();

  if (!user) {
    window.location.href = LOGIN_PAGE;
    return null;
  }

  return user;
}

async function requireRole(allowedRoles = []) {
  const user = await requireAuth();

  if (!user) {
    return null;
  }

  if (!Array.isArray(allowedRoles) || allowedRoles.length === 0) {
    return user;
  }

  if (!allowedRoles.includes(user.role)) {
    window.location.href = HOME_PAGE;
    return null;
  }

  return user;
}

function applyRoleToUI(user) {
  if (!user) return;

  const roleSpan = document.getElementById('user-role');
  const emailSpan = document.getElementById('user-email');
  const adminMenu = document.getElementById('admin-menu');
  const managerMenu = document.getElementById('manager-menu');

  if (roleSpan) roleSpan.textContent = user.role;
  if (emailSpan) emailSpan.textContent = user.email;

  if (user.role === 'admin') {
    if (adminMenu) adminMenu.style.display = 'flex';
    if (managerMenu) managerMenu.style.display = 'flex';
  } else if (user.role === 'manager') {
    if (managerMenu) managerMenu.style.display = 'flex';
    if (adminMenu) adminMenu.style.display = 'none';
  } else {
    if (managerMenu) managerMenu.style.display = 'none';
    if (adminMenu) adminMenu.style.display = 'none';
  }
}

async function initPage(options = {}) {
  const {
    allowedRoles = [],
    applyUi = true
  } = options;

  const user = allowedRoles.length
    ? await requireRole(allowedRoles)
    : await requireAuth();

  if (!user) return null;

  if (applyUi) {
    applyRoleToUI(user);
  }

  return user;
}

async function logout() {
  try {
    await fetch(`${API_BASE}/api/auth/logout`, {
      method: 'POST',
      credentials: 'include'
    });
  } catch (err) {
    console.error('Erreur logout:', err);
  }

  window.location.href = LOGIN_PAGE;
}