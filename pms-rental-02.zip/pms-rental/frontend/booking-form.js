/**
 * =========================================
 * BOOKING-FORM.JS - CREATION DE RESERVATION
 * =========================================
 *
 * Ce fichier gère :
 * - la validation du formulaire
 * - l'envoi de la création au backend
 * - l'affichage des messages succès / erreur
 * - la couleur dynamique du select hébergement
 */

/* =========================
   REFERENCES DOM
   ========================= */
const bookingForm = document.getElementById('bookingForm');
const roomSelect = document.getElementById('roomCode');

/* =========================
   CALENDRIER FULLSCREEN AU CLIC
   ========================= */
const checkInInput = document.getElementById('checkIn');
const checkOutInput = document.getElementById('checkOut');

if (checkInInput) {
  checkInInput.addEventListener('click', function() {
    this.showPicker();
  });
}

if (checkOutInput) {
  checkOutInput.addEventListener('click', function() {
    this.showPicker();
  });
}

/* =========================
   FIX INPUT PRICE - TEXT
   ========================= */
const priceInput = document.getElementById('price');
if (priceInput) {
  priceInput.addEventListener('input', function() {
    // Accepte chiffres, virgule ET point
    let value = this.value.replace(/[^0-9.,]/g, '');
    
    // Convertir virgule en point
    value = value.replace(',', '.');
    
    // Garder max 2 décimales
    if (value.includes('.')) {
      const parts = value.split('.');
      value = parts[0] + '.' + parts[1].substring(0, 2);
    }
    
    this.value = value;
  });
}

/* =========================
   AFFICHAGE ROOM_CODE ET COULEURS
   ========================= */
function populateRoomSelect() {
  const select = document.getElementById('roomCode');
  if (!select || !window.ROOM_CONFIG) return;

  select.innerHTML = '<option value="">-- Choisir --</option>';

  Object.values(window.ROOM_CONFIG).forEach(room => {
    const option = document.createElement('option');
    option.value = room.roomCode;
    option.textContent = room.name;
    option.style.backgroundColor = room.bg;
    option.style.color = room.optionTextColor;
    select.appendChild(option);
  });
}

/* Appel au chargement de la page */
document.addEventListener('DOMContentLoaded', () => {
  populateRoomSelect();
});

/* =========================
   AFFICHAGE MESSAGE
   ========================= */
function showMessage(msg, type) {
  const messageDiv = document.getElementById('message');
  if (!messageDiv) return;

  messageDiv.textContent = msg;
  messageDiv.className = `message ${type}`;
  messageDiv.style.display = 'block';
}

/* =========================
   COULEUR SELECT HEBERGEMENT
   ========================= */
function updateRoomSelectColor() {
  if (!roomSelect) return;

  roomSelect.classList.remove(
    'room-raspberry',
    'room-blueberry',
    'room-maracuja',
    'room-surfhouse',
    'room-female_dorm'
  );

  if (roomSelect.value) {
    roomSelect.classList.add('room-' + roomSelect.value);
  }
}

/* =========================
   VALIDATION DES DATES
   ========================= */
function isValidDateRange(checkIn, checkOut) {
  if (!checkIn || !checkOut) return false;
  return new Date(checkIn) < new Date(checkOut);
}

/* =========================
   SOUMISSION FORMULAIRE
   ========================= */
async function handleBookingSubmit(event) {
  event.preventDefault();

  const guestName = document.getElementById('guestName').value.trim();
  const description = document.getElementById('description').value.trim();
  const checkIn = document.getElementById('checkIn').value;
  const checkOut = document.getElementById('checkOut').value;
  const price = parseFloat(document.getElementById('price').value);
  const source = document.getElementById('source').value;
  const roomCode = document.getElementById('roomCode').value;
  const units = parseInt(document.getElementById('units').value, 10);

  if (!guestName) {
    showMessage('Veuillez renseigner le nom du client.', 'error');
    return;
  }

  if (!roomCode) {
    showMessage('Veuillez choisir un hébergement.', 'error');
    return;
  }

  if (!units || units < 1) {
    showMessage('Occupation minimale : 1 unité.', 'error');
    return;
  }

  if (!price || price < 0) {
    showMessage('Veuillez saisir un prix valide.', 'error');
    return;
  }

  if (!source) {
    showMessage('Veuillez choisir une source.', 'error');
    return;
  }

  if (!isValidDateRange(checkIn, checkOut)) {
    showMessage('La date de départ doit être après la date d’arrivée.', 'error');
    return;
  }

  const payload = {
    property_id: 1,
    channel_id: 1,
    guest_name: guestName,
    description: description,
    check_in: checkIn,
    check_out: checkOut,
    price: price,
    source: source,
    room_code: roomCode,
    units: units
  };

  console.log('Payload création =', payload);

  try {
    const response = await fetch('http://localhost:8080/api/bookings/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (response.ok && result.success) {
      showMessage(`✅ Réservation créée (ID: ${result.id}) !`, 'success');
      bookingForm.reset();
      updateRoomSelectColor();

      setTimeout(() => {
        window.location.href = 'index.html';
      }, 2000);
    } else {
      showMessage(`❌ Erreur : ${result.message || 'Impossible de créer la réservation'}`, 'error');
    }
  } catch (error) {
    console.error('Erreur création réservation:', error);
    showMessage(`❌ Erreur réseau : ${error.message}`, 'error');
  }
}

/* =========================
   INITIALISATION
   ========================= */
if (bookingForm) {
  bookingForm.addEventListener('submit', handleBookingSubmit);
}

if (roomSelect) {
  updateRoomSelectColor();
  roomSelect.addEventListener('change', updateRoomSelectColor);
}