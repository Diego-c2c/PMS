/**
 * =========================================
 * PRICING.JS - AUTOMATION DES PRIX
 * =========================================
 *
 * DESCRIPTION :
 * Gère l'interface de synchronisation des tarifs avec Booking.com
 *
 * FONCTIONNALITÉS :
 * - Ajouter des tarifs à une liste
 * - Supprimer des tarifs
 * - Envoyer les tarifs vers le backend
 * - Afficher le résultat (succès ou erreur)
 *
 * PHASE : 3.2 (Automation des prix)
 */

/* =========================
   VARIABLES GLOBALES
   ========================= */

/**
 * priceUpdates - Tableau contenant tous les tarifs à synchroniser
 * Format :
 * [
 *   { date_from: "2026-03-21", date_to: "2026-03-28", price: 650 },
 *   { date_from: "2026-03-28", date_to: "2026-04-04", price: 700 }
 * ]
 */
let priceUpdates = [];

/* =========================
   FONCTIONS UTILITAIRES
   ========================= */

/**
 * Échappe une valeur avant affichage HTML
 */
function escapeHTML(value) {
  if (value === null || value === undefined) return '';
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}

/**
 * Affiche un message de retour
 */
function showSyncMessage(message, type = 'success') {
  const box = document.getElementById('syncMessage');
  if (!box) return;

  box.className = `sync-message ${type}`;
  box.textContent = message;
  box.style.display = 'block';
}

/**
 * Cache le message de retour
 */
function clearSyncMessage() {
  const box = document.getElementById('syncMessage');
  if (!box) return;

  box.className = 'sync-message';
  box.textContent = '';
  box.style.display = 'none';
}

/**
 * Active ou désactive le bouton de synchronisation
 */
function setSyncButtonLoading(isLoading) {
  const syncBtn = document.getElementById('syncBtn');
  if (!syncBtn) return;

  syncBtn.disabled = isLoading;
  syncBtn.textContent = isLoading
    ? '⏳ Synchronisation en cours...'
    : '🚀 Synchroniser avec Booking';
}

/**
 * Formate une date en français
 */
function formatDateFR(dateString) {
  const date = new Date(dateString);

  if (Number.isNaN(date.getTime())) {
    return dateString;
  }

  return date.toLocaleDateString('fr-FR');
}

/* =========================
   AJOUTER UN TARIF
   ========================= */

/**
 * Ajoute un tarif à la liste locale
 *
 * FLUX :
 * 1. Récupérer les valeurs des champs
 * 2. Valider les données (dates, prix)
 * 3. Ajouter à l'array priceUpdates
 * 4. Vider les champs
 * 5. Afficher la liste mise à jour
 */
function addPriceUpdate() {
  clearSyncMessage();

  const dateFrom = document.getElementById('dateFrom').value;
  const dateTo = document.getElementById('dateTo').value;
  const price = parseFloat(document.getElementById('price').value);

  // Tous les champs doivent être remplis
  if (!dateFrom || !dateTo || Number.isNaN(price)) {
    showSyncMessage('⚠️ Remplissez tous les champs.', 'error');
    return;
  }

  // La date de fin doit être après la date de début
  if (new Date(dateFrom) >= new Date(dateTo)) {
    showSyncMessage('⚠️ La date de fin doit être après la date de début.', 'error');
    return;
  }

  // Le prix doit être positif
  if (price <= 0) {
    showSyncMessage('⚠️ Le prix doit être positif.', 'error');
    return;
  }

  priceUpdates.push({
    date_from: dateFrom,
    date_to: dateTo,
    price: price
  });

  console.log('✅ Tarif ajouté :', { dateFrom, dateTo, price });

  document.getElementById('dateFrom').value = '';
  document.getElementById('dateTo').value = '';
  document.getElementById('price').value = '';

  updatePricesList();
}

/* =========================
   AFFICHER LA LISTE DES TARIFS
   ========================= */

/**
 * Affiche tous les tarifs de l'array priceUpdates
 * Génère le HTML et l'injecte dans #pricesList
 */
function updatePricesList() {
  const list = document.getElementById('pricesList');
  if (!list) return;

  if (priceUpdates.length === 0) {
    list.innerHTML = '<p style="color: #999; text-align: center;">Aucun tarif ajouté</p>';
    return;
  }

  let html = '';

  priceUpdates.forEach((update, index) => {
    const fromDate = formatDateFR(update.date_from);
    const toDate = formatDateFR(update.date_to);

    html += `
      <div class="pricing-item">
        <div class="pricing-item-date">${escapeHTML(fromDate)}</div>
        <div class="pricing-item-date">→ ${escapeHTML(toDate)}</div>
        <div class="pricing-item-price">${escapeHTML(update.price)}€</div>
        <button
          type="button"
          class="btn-remove"
          onclick="removePriceUpdate(${index})"
          title="Supprimer ce tarif">
          🗑️
        </button>
      </div>
    `;
  });

  list.innerHTML = html;

  console.log('📊 Liste mise à jour, tarifs :', priceUpdates);
}

/* =========================
   SUPPRIMER UN TARIF
   ========================= */

/**
 * Supprime un tarif de la liste par son index
 */
function removePriceUpdate(index) {
  if (index < 0 || index >= priceUpdates.length) return;

  priceUpdates.splice(index, 1);

  console.log('🗑️ Tarif supprimé à l’index :', index);

  updatePricesList();
}

/* =========================
   SYNCHRONISER LES TARIFS
   ========================= */

/**
 * Envoie tous les tarifs au backend pour synchronisation
 *
 * FLUX :
 * 1. Récupérer email, password, propertyId
 * 2. Vérifier qu'il y a des tarifs à envoyer
 * 3. Envoyer le payload au backend
 * 4. Afficher le résultat
 */
async function syncPrices() {
  clearSyncMessage();

  const bookingEmail = document.getElementById('bookingEmail').value.trim();
  const bookingPassword = document.getElementById('bookingPassword').value;
  const propertyId = document.getElementById('propertyId').value.trim();

  if (!bookingEmail || !bookingPassword || !propertyId) {
    showSyncMessage('⚠️ Remplissez les identifiants Booking et l’ID propriété.', 'error');
    return;
  }

  if (priceUpdates.length === 0) {
    showSyncMessage('⚠️ Ajoutez au moins un tarif à synchroniser.', 'error');
    return;
  }

  const payload = {
    email: bookingEmail,
    password: bookingPassword,
    property_id: propertyId,
    updates: priceUpdates
  };

  console.log('🚀 Payload synchronisation =', payload);

  try {
    setSyncButtonLoading(true);

    const response = await fetch('http://localhost:8080/api/pricing/sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (response.ok && result.success) {
      showSyncMessage(
        `✅ Synchronisation réussie : ${result.updated_count || priceUpdates.length} tarif(s) envoyé(s).`,
        'success'
      );

      priceUpdates = [];
      updatePricesList();
    } else {
      showSyncMessage(
        `❌ Erreur : ${result.message || 'Impossible de synchroniser les tarifs.'}`,
        'error'
      );
    }
  } catch (error) {
    console.error('Erreur syncPrices :', error);
    showSyncMessage(`❌ Erreur réseau : ${error.message}`, 'error');
  } finally {
    setSyncButtonLoading(false);
  }
}

/* =========================
   INITIALISATION
   ========================= */

document.addEventListener('DOMContentLoaded', () => {
  updatePricesList();
});