/**
 * CALENDAR-VIEW.JS - VUE CALENDRIER (1W / 1M / 3M)
 *
 * - Vue 1w : semaine (7 jours)
 * - Vue 1m : mois (grille classique)
 * - Vue 3m : année (12 mois dans une seule grille)
 *
 * ATTENTION :
 *  - Nécessite que room_config.js soit chargé AVANT ce fichier
 *    afin que window.ROOM_CONFIG et window.ROOM_DISPLAY existent.
 *  - Les couleurs / labels de chambres viennent désormais UNIQUEMENT
 *    de room_config.js (source de vérité unique).
 */

// =======================
// VARIABLES GLOBALES
// =======================

let currentDate = new Date();   // base pour le rendu
let bookings = [];              // réservations chargées depuis l’API
let viewMode = '1w';            // '1w' | '1m' | '3m'
let currentUser = null;         // alimenté via auth.js

const MAX_LINES_PER_DAY = 6;    // nombre maxi de lignes affichées par jour

// =======================
// UTILITAIRES CHAMBRES
// =======================

/**
 * Normalise le code de chambre provenant de l’API.
 * - backend peut renvoyer room_code (snake_case)
 * - frontend préférer roomCode (camelCase)
 * Cette fonction centralise la logique pour éviter les erreurs.
 */
function getBookingRoomCode(booking) {
  return booking.roomCode || booking.room_code || null;
}

/**
 * Récupère la config d’affichage d’une chambre à partir de ROOM_DISPLAY.
 * ROOM_DISPLAY est généré automatiquement par room_config.js
 * à partir de ROOM_CONFIG.
 */
function getRoomDisplay(roomCode) {
  if (!roomCode || !window.ROOM_DISPLAY) return null;
  return window.ROOM_DISPLAY[roomCode] || null;
}

// =======================
// UTILITAIRES GENERAUX
// =======================

function getSourceIcon(source) {
  if (!source) return '';
  const s = source.toLowerCase();
  if (s === 'booking') return '🏨';
  if (s === 'airbnb')  return '🏠';
  return '📞';
}

/**
 * Place currentDate sur le 1er jour du mois
 * (utile pour les vues mensuelle / annuelle).
 */
function normalizeCurrentDateToFirstOfMonth() {
  currentDate.setDate(1);
}

/**
 * Retourne le numéro de semaine ISO d’une date.
 */
function getISOWeekNumber(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return weekNo;
}

// Récupère l'utilisateur courant via auth.js
async function loadCurrentUser() {
  if (typeof getCurrentUser === 'function') {
    currentUser = await getCurrentUser();
  }
}

function isReadOnlyUser() {
  return currentUser && currentUser.role === 'user';
}

// =======================
// CHARGEMENT DES RESERVATIONS
// =======================

/**
 * Charge les réservations depuis le backend.
 * ATTENTION : l’API doit renvoyer check_in, check_out,
 *             room_code (ou roomCode), guest / guest_name, etc.
 */
async function loadBookings() {
  try {
    const response = await fetch('http://localhost:8080/api/calendar', { cache: 'no-store' });
    const data = await response.json();

    console.log('✅ DATA API /api/calendar:', data);

    bookings = data.map(item => {
      let entityType = 'booking';

      if (item.entityType) {
        entityType = item.entityType;
      } else if (item.event_type === 'block') {
        entityType = 'calendar_block';
      } else if (item.type === 'calendar_block') {
        entityType = 'calendar_block';
      } else if (item.source_table === 'calendar_blocks') {
        entityType = 'calendar_block';
      } else if (item.source === 'ical') {
        entityType = 'calendar_block';
      }

      return {
        ...item,
        entityType,
        check_in: item.check_in || item.date_from || null,
        check_out: item.check_out || item.date_to || null,
        guest_name: item.guest_name ?? item.guest ?? item.reason ?? 'Imported iCal',
        description: item.description ?? item.reason ?? '',
        source: item.source ?? (entityType === 'calendar_block' ? 'booking' : ''),
        units: item.units ?? 1
      };
    });

    console.log('✅ Réservations enrichies:', bookings);
  } catch (error) {
    console.error('❌ Erreur lors du chargement:', error);
  }
}
// =======================
// NAVIGATION
// =======================

function previousMonth() {
  if (viewMode === '1m') {
    currentDate.setMonth(currentDate.getMonth() - 1);
    normalizeCurrentDateToFirstOfMonth();
  } else if (viewMode === '3m') {
    currentDate.setFullYear(currentDate.getFullYear() - 1);
    normalizeCurrentDateToFirstOfMonth();
  } else if (viewMode === '1w') {
    currentDate.setDate(currentDate.getDate() - 7);
  }
  renderCalendar();
}

function nextMonth() {
  if (viewMode === '1m') {
    currentDate.setMonth(currentDate.getMonth() + 1);
    normalizeCurrentDateToFirstOfMonth();
  } else if (viewMode === '3m') {
    currentDate.setFullYear(currentDate.getFullYear() + 1);
    normalizeCurrentDateToFirstOfMonth();
  } else if (viewMode === '1w') {
    currentDate.setDate(currentDate.getDate() + 7);
  }
  renderCalendar();
}

function goToToday() {
  currentDate = new Date();
  if (viewMode !== '1w') {
    normalizeCurrentDateToFirstOfMonth();
  }
  renderCalendar();
}

/**
 * Change le mode de vue (1w / 1m / 3m) et met à jour les boutons.
 */
function setViewMode(mode) {
  viewMode = mode;

  const btn1w  = document.getElementById('view-1w');
  const btn1m  = document.getElementById('view-1m');
  const btn3m  = document.getElementById('view-3m');
  const btnPrev = document.getElementById('btn-prev');
  const btnNext = document.getElementById('btn-next');

  if (btn1w && btn1m && btn3m) {
    btn1w.classList.toggle('active', viewMode === '1w');
    btn1m.classList.toggle('active', viewMode === '1m');
    btn3m.classList.toggle('active', viewMode === '3m');
  }

  if (btnPrev && btnNext) {
    if (viewMode === '1m') {
      btnPrev.textContent = '← Mois précédent';
      btnNext.textContent = 'Mois suivant →';
    } else if (viewMode === '3m') {
      btnPrev.textContent = '← Année précédente';
      btnNext.textContent = 'Année suivante →';
    } else if (viewMode === '1w') {
      btnPrev.textContent = '← Semaine précédente';
      btnNext.textContent = 'Semaine suivante →';
    }
  }

  if (viewMode === '1w') {
    // Vue semaine = centré sur la semaine de la date courante
    currentDate = new Date();
  } else {
    // Vues 1m / 3m = toujours à partir du 1er du mois
    normalizeCurrentDateToFirstOfMonth();
  }

  renderCalendar();
}

// =======================
// RENDU CALENDRIER (1M / 3M)
// =======================

function renderCalendar() {
  console.log('renderCalendar called', viewMode);

  // Délègue à la vue semaine si besoin
  if (viewMode === '1w') {
    renderWeekView();
    return;
  }

  const year  = currentDate.getFullYear();
  const today = new Date();
  let periodStart, periodEnd, headerText;

  if (viewMode === '1m') {
    // Vue mois : du 1er au dernier jour du mois courant
    periodStart = new Date(year, currentDate.getMonth(), 1);
    periodEnd   = new Date(year, currentDate.getMonth() + 1, 0);

    const monthNames = [
      'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ];
    headerText = monthNames[periodStart.getMonth()] + ' ' + year;
  } else {
    // Vue 3m (année) : du 1er janvier au 31 décembre
    periodStart = new Date(year, 0, 1);
    periodEnd   = new Date(year, 11, 31);
    headerText  = String(year);
  }

  const monthYearEl = document.getElementById('monthYear');
  if (monthYearEl) {
    monthYearEl.textContent = headerText;
  }

  let html = '';

  // En-têtes des jours (Dim -> Sam)
  const dayNames = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
  dayNames.forEach(day => {
    html += '<div class="calendar-day-header">' + day + '</div>';
  });

  const monthShort = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin',
    'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];

  // On calcule la grille complète à afficher (début/fin de semaine inclus)
  const gridStart = new Date(periodStart);
  const startDayOfWeek = gridStart.getDay(); // 0 = dimanche
  gridStart.setDate(gridStart.getDate() - startDayOfWeek);

  const gridEnd = new Date(periodEnd);
  const endDayOfWeek = gridEnd.getDay();
  gridEnd.setDate(gridEnd.getDate() + (6 - endDayOfWeek));

  const cursor = new Date(gridStart);

  while (cursor <= gridEnd) {
    const inPeriod = cursor >= periodStart && cursor <= periodEnd;

    const isToday =
      cursor.getFullYear() === today.getFullYear() &&
      cursor.getMonth() === today.getMonth() &&
      cursor.getDate() === today.getDate();

    let dayClasses = 'calendar-day';
    if (!inPeriod) dayClasses += ' other-month';
    if (isToday)   dayClasses += ' today';

    const dayLabel = (viewMode === '1m')
      ? String(cursor.getDate())
      : cursor.getDate() + ' ' + monthShort[cursor.getMonth()];

    let bookingsHtml = '';

    if (inPeriod) {
      // Réservations couvrant ce jour
      const bookingsForDay = bookings.filter(b => {
        const checkIn  = new Date(b.check_in);
        const checkOut = new Date(b.check_out);
        return cursor >= checkIn && cursor < checkOut;
      });

      bookingsForDay.slice(0, MAX_LINES_PER_DAY).forEach(b => {
        const roomCode   = getBookingRoomCode(b);
        const room       = getRoomDisplay(roomCode);
        const roomLetter = room ? room.short : '?';
        const bg         = room ? room.bg   : '#e7f3ff';
        const textColor  = room ? room.text : '#333';
        const sourceIcon = getSourceIcon(b.source);
        const guest      = b.guest_name || 'Unknown';
        const description = b.description || '';

        const checkIn = new Date(b.check_in);
        const isCheckInDay =
          cursor.getFullYear() === checkIn.getFullYear() &&
          cursor.getMonth() === checkIn.getMonth() &&
          cursor.getDate() === checkIn.getDate();

        let tooltipText = `${roomLetter} ${guest} ${sourceIcon}`;
        if (description) {
          tooltipText += ` — ${description}`;
        }
        const safeTooltip = tooltipText.replace(/"/g, '&quot;');
        const visibleText = `${roomLetter} ${guest} ${sourceIcon}`;

        if (isCheckInDay) {
          bookingsHtml +=
            '<div class="calendar-booking calendar-booking-start" ' +
            'style="background-color:' + bg + '; color:' + textColor + '; border-left-color:' + textColor + ';" ' +
            'draggable="false" data-booking-id="' + b.id + '" ' +
            'onclick="editBooking(' + b.id + ', \'' + (b.entityType || 'booking') + '\')" ' +
            'title="' + safeTooltip + '">' +
              visibleText +
            '</div>';
        } else {
          bookingsHtml +=
            '<div class="calendar-booking calendar-booking-continue" ' +
            'style="background-color:' + bg + '; border-left-color:' + bg + ';" ' +
            'data-booking-id="' + b.id + '" ' +
            'onclick="editBooking(' + b.id + ', \'' + (b.entityType || 'booking') + '\')" ' +
            'title="' + safeTooltip + '">' +
              visibleText +
            '</div>';
        }
      });

      // Complète avec des lignes vides pour garder une hauteur constante
      const emptyLinesCount = Math.max(0, MAX_LINES_PER_DAY - bookingsForDay.length);
      for (let i = 0; i < emptyLinesCount; i++) {
        bookingsHtml += '<div class="calendar-booking calendar-booking-empty"></div>';
      }
    }

    html +=
      '<div class="' + dayClasses + '" ' +
      'data-date="' + cursor.toISOString().slice(0, 10) + '">' +
        '<div class="calendar-day-number">' + dayLabel + '</div>' +
        '<div class="calendar-bookings">' + bookingsHtml + '</div>' +
      '</div>';

    cursor.setDate(cursor.getDate() + 1);
  }

  const calendarEl = document.getElementById('calendar');
  if (calendarEl) {
    calendarEl.classList.remove('view-week');
    calendarEl.innerHTML = html;
  }
}

// =======================
// RENDU SEMAINE (1W)
// =======================

function renderWeekView() {
  const ref = new Date(currentDate);
  const year = ref.getFullYear();

  // Calcule le lundi de la semaine courante
  const weekStart = new Date(ref);
  const jsDay = weekStart.getDay(); // 0 = dimanche, 1 = lundi
  const diffToMonday = (jsDay === 0 ? -6 : 1 - jsDay);
  weekStart.setDate(weekStart.getDate() + diffToMonday);

  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);

  const weekNumber = getISOWeekNumber(weekStart);

  const monthYearEl = document.getElementById('monthYear');
  if (monthYearEl) {
    monthYearEl.textContent = `Semaine ${weekNumber} - ${year}`;
  }

  const dayNames   = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  const monthShort = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin',
    'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];

  let html = '';

  // En-têtes des jours
  dayNames.forEach(day => {
    html += '<div class="calendar-day-header">' + day + '</div>';
  });

  const cursor    = new Date(weekStart);
  const todayReal = new Date();

  for (let i = 0; i < 7; i++) {
    const isToday =
      cursor.getFullYear() === todayReal.getFullYear() &&
      cursor.getMonth() === todayReal.getMonth() &&
      cursor.getDate() === todayReal.getDate();

    let dayClasses = 'calendar-day';
    if (isToday) dayClasses += ' today';

    const dayLabel = cursor.getDate() + ' ' + monthShort[cursor.getMonth()];

    const bookingsForDay = bookings.filter(b => {
      const checkIn  = new Date(b.check_in);
      const checkOut = new Date(b.check_out);
      return cursor >= checkIn && cursor < checkOut;
    });

    let bookingsHtml = '';

    bookingsForDay.slice(0, MAX_LINES_PER_DAY).forEach(b => {
      const roomCode   = getBookingRoomCode(b);
      const room       = getRoomDisplay(roomCode);
      const roomLetter = room ? room.short : '?';
      const bg         = room ? room.bg   : '#e7f3ff';
      const textColor  = room ? room.text : '#333';
      const sourceIcon = getSourceIcon(b.source);
      const guest      = b.guest_name || 'Unknown';
      const description = b.description || '';

      const checkIn = new Date(b.check_in);
      const isCheckInDay =
        cursor.getFullYear() === checkIn.getFullYear() &&
        cursor.getMonth() === checkIn.getMonth() &&
        cursor.getDate() === checkIn.getDate();

      let tooltipText = `${roomLetter} ${guest} ${sourceIcon}`;
      if (description) {
        tooltipText += ` — ${description}`;
      }
      const safeTooltip = tooltipText.replace(/"/g, '&quot;');
      const visibleText = `${roomLetter} ${guest} ${sourceIcon}`;

      if (isCheckInDay) {
        bookingsHtml +=
          '<div class="calendar-booking calendar-booking-start" ' +
          'style="background-color:' + bg + '; color:' + textColor + '; border-left-color:' + textColor + ';" ' +
          'draggable="false" data-booking-id="' + b.id + '" ' +
          'onclick="editBooking(' + b.id + ', \'' + (b.entityType || 'booking') + '\')" ' +
          'title="' + safeTooltip + '">' +
            visibleText +
          '</div>';
      } else {
        bookingsHtml +=
          '<div class="calendar-booking calendar-booking-continue" ' +
          'style="background-color:' + bg + '; border-left-color:' + bg + ';" ' +
          'data-booking-id="' + b.id + '" ' +
          'onclick="editBooking(' + b.id + ', \'' + (b.entityType || 'booking') + '\')" ' +
          'title="' + safeTooltip + '">' +
            visibleText +
          '</div>';
      }
    });

    const emptyLinesCount = Math.max(0, MAX_LINES_PER_DAY - bookingsForDay.length);
    for (let j = 0; j < emptyLinesCount; j++) {
      bookingsHtml += '<div class="calendar-booking calendar-booking-empty"></div>';
    }

    html +=
      '<div class="' + dayClasses + '" data-date="' + cursor.toISOString().slice(0, 10) + '">' +
        '<div class="calendar-day-number">' + dayLabel + '</div>' +
        '<div class="calendar-bookings">' + bookingsHtml + '</div>' +
      '</div>';

    cursor.setDate(cursor.getDate() + 1);
  }

  const calendarEl = document.getElementById('calendar');
  if (calendarEl) {
    calendarEl.classList.add('view-week');
    calendarEl.innerHTML = html;
  }
}

// =======================
// EDITION DE RESERVATION
// =======================

/**
 * Redirige vers la page d’édition de réservation,
 * sauf pour les utilisateurs en lecture seule.
 */
function editBooking(id, entityType = 'booking') {
  if (isReadOnlyUser()) {
    return;
  }

  window.location.href = 'edit-booking.html?id=' + id + '&type=' + encodeURIComponent(entityType);
}
// =======================
// GESTION THEME (compat)
// =======================

function applyTheme(theme) {
  document.body.classList.remove('theme-dark', 'theme-ocean');
  if (theme === 'dark')  document.body.classList.add('theme-dark');
  if (theme === 'ocean') document.body.classList.add('theme-ocean');
  localStorage.setItem('pms-theme', theme);
}

// =======================
// INITIALISATION
// =======================

document.addEventListener('DOMContentLoaded', async () => {
  // Récupère l’utilisateur (auth.js met aussi à jour l’UI header)
  await loadCurrentUser();

  // Thème
  const savedTheme = localStorage.getItem('pms-theme') || 'light';
  applyTheme(savedTheme);

  const themeSelect = document.getElementById('theme-select');
  if (themeSelect) {
    themeSelect.value = savedTheme;
    themeSelect.addEventListener('change', () => {
      applyTheme(themeSelect.value);
    });
  }

  // Point de départ calendrier
  currentDate = new Date();
  //normalizeCurrentDateToFirstOfMonth();

  // Synchroniser les boutons toggle avec le viewMode initial
  const btn1w  = document.getElementById('view-1w');
  const btn1m  = document.getElementById('view-1m');
  const btn3m  = document.getElementById('view-3m');
  
  if (btn1w && btn1m && btn3m) {
    btn1w.classList.toggle('active', viewMode === '1w');
    btn1m.classList.toggle('active', viewMode === '1m');
    btn3m.classList.toggle('active', viewMode === '3m');
  }

  // Charge les réservations puis rend le calendrier
  await loadBookings();
  renderCalendar();

  // Bouton "Ajouter une réservation"
  const addBtn = document.getElementById('addBookingBtn');
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      if (isReadOnlyUser()) return;
      window.location.href = 'booking-form.html';
    });
  }
});