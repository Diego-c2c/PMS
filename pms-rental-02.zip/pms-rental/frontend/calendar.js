/**
 * =========================================
 * CALENDAR.JS - GESTION DU CALENDRIER PMS
 * =========================================
 *
 * Ce fichier gère :
 * - le chargement des réservations depuis l'API
 * - l'affichage du tableau du calendrier
 * - la suppression d'une réservation
 * - l'application du thème (clair / sombre / océan)
 * - le mode lecture seule pour les utilisateurs "user"
 */

/* =========================
   DONNÉES ROOMS DYNAMIQUES
   =========================
   - PMS_ROOMS     : liste brute renvoyée par /api/rooms
   - PMS_ROOM_MAP  : map code (en minuscule) → room (code, label, color)
*/
let PMS_ROOMS = [];
let PMS_ROOM_MAP = {};

/**
 * Charge les rooms PMS depuis le backend et met à jour la map.
 * Appelé avant d'afficher le calendrier pour toujours avoir
 * les dernières couleurs / labels.
 */
async function loadRooms() {
  try {
    const response = await fetch('http://localhost:8081/api/rooms', {
      method: 'GET',
      credentials: 'include'
    });

    const result = await response.json().catch(() => ({}));

    if (!response.ok || result.success === false) {
      throw new Error(result.message || 'Impossible de charger les rooms PMS.');
    }

    const rooms = result.rooms || [];
    PMS_ROOMS = rooms;
    PMS_ROOM_MAP = {};

    rooms.forEach(room => {
      const key = String(room.code || '').trim().toLowerCase();
      if (!key) return;
      PMS_ROOM_MAP[key] = room;
    });

    console.log('✅ Rooms PMS chargées pour calendar.js :', PMS_ROOMS);
  } catch (err) {
    console.error('Erreur loadRooms() dans calendar.js :', err);
    // On ne bloque pas l'affichage du calendrier si les rooms ne sont pas chargées,
    // mais on affichera alors le room_code brut sans couleur.
  }
}

/**
 * Retourne la room PMS depuis la map, à partir du room_code.
 */
function getRoomInfo(roomCode) {
  if (!roomCode) return null;
  const key = String(roomCode).trim().toLowerCase();
  return PMS_ROOM_MAP[key] || null;
}

/* =========================
   VARIABLES GLOBALES
   ========================= */
let currentUser = null;
let calendarRefreshInterval = null;

/* =========================
   FILTRES DATES GLOBAUX
   =========================
   - filterFromDate : date From choisie par l'utilisateur
   - filterToDate   : date To choisie par l'utilisateur
*/
let filterFromDate = '';
let filterToDate = '';


/* =========================
   FONCTIONS UTILITAIRES
   ========================= */


/**
 * Échappe une chaîne pour éviter l'injection HTML
 */
function escapeHTML(value) {
  if (value === null || value === undefined) return '';
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}


/**
 * Formate une date en français
 */
function formatDateFR(dateValue) {
  if (!dateValue) return '';
  const date = new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return date.toLocaleDateString('fr-FR');
}

/* =========================
   FILTRE PAR INTERVALLE DE DATES
   ========================= */

/**
 * Convertit une date en objet Date à minuit local
 * pour éviter les problèmes d'heures.
 */
function toLocalDateOnly(dateStr) {
  if (!dateStr) return null;

  const parts = String(dateStr).split('T')[0].split('-');
  if (parts.length !== 3) return null;

  const year = Number(parts[0]);
  const month = Number(parts[1]) - 1;
  const day = Number(parts[2]);

  return new Date(year, month, day);
}


/**
 * Vérifie si une réservation chevauche
 * l'intervalle [From, To] choisi par l'utilisateur.
 *
 * Règle utilisée :
 * - bookingStart < filterEndExclusive
 * - bookingEnd > filterStart
 *
 * Cela permet d'inclure :
 * - les séjours entièrement dans la plage
 * - les séjours qui commencent avant mais finissent dedans
 * - les séjours qui commencent dedans mais finissent après
 */
function bookingOverlapsFilter(booking) {
  if (!filterFromDate && !filterToDate) {
    return true;
  }

  const bookingStart = toLocalDateOnly(booking.check_in);
  const bookingEnd = toLocalDateOnly(booking.check_out);

  if (!bookingStart || !bookingEnd) {
    return false;
  }

  const filterStart = filterFromDate ? toLocalDateOnly(filterFromDate) : null;
  const filterEnd = filterToDate ? toLocalDateOnly(filterToDate) : null;

  // Si seulement From est renseigné :
  // on garde tout ce qui se termine après ou le jour de From
  if (filterStart && !filterEnd) {
    return bookingEnd > filterStart;
  }

  // Si seulement To est renseigné :
  // on garde tout ce qui commence avant le lendemain de To
  if (!filterStart && filterEnd) {
    const filterEndExclusive = new Date(filterEnd);
    filterEndExclusive.setDate(filterEndExclusive.getDate() + 1);

    return bookingStart < filterEndExclusive;
  }

  // Si From et To sont renseignés :
  // on teste le chevauchement entre les deux intervalles
  const filterEndExclusive = new Date(filterEnd);
  filterEndExclusive.setDate(filterEndExclusive.getDate() + 1);

  return bookingStart < filterEndExclusive && bookingEnd > filterStart;
}


/**
 * Retourne le libellé de la source avec icône
 * - normalise la casse
 * - gère Icalbook
 */
function formatSourceLabel(source) {
  const raw = source == null ? '' : String(source);
  const normalized = raw.trim().toLowerCase();

  if (normalized === 'booking') return '🏨 Booking';
  if (normalized === 'airbnb') return '🏠 Airbnb';
  if (normalized === 'icalbook') return '📥 Icalbook';
  return `📞 ${raw || 'Direct'}`;
}

/**
 * Construit le style de cellule selon la chambre
 * Utilise désormais la couleur stockée en base (rooms.color).
 */
function buildRoomStyle(roomCode) {
  const room = getRoomInfo(roomCode);

  if (!room || !room.color) {
    // Pas de couleur en base : pas de style particulier
    return '';
  }

  // Texte blanc par défaut sur couleur PMS
  return `style="background-color:${room.color};color:#ffffff;border-radius:4px;padding:2px 4px;"`;
}

/**
 * Construit le libellé de l'hébergement
 * Utilise désormais label depuis la table rooms.
 */
function buildRoomLabel(roomCode, units) {
  const room = getRoomInfo(roomCode);
  const baseLabel = room?.label || roomCode || '';

  const unitsNum = Number(units);
  const unitsSuffix = unitsNum > 1 ? ` x${unitsNum}` : '';

  return `${baseLabel}${unitsSuffix}`;
}


/**
 * Vérifie si l'utilisateur courant est en lecture seule
 */
function isReadOnlyUser() {
  return currentUser && currentUser.role === 'user';
}


/* =========================
   CHARGEMENT DU CALENDRIER
   ========================= */


/**
 * Charge les réservations depuis l'API
 * et construit le tableau HTML
 */
async function loadCalendar() {
  try {
    // 1) Charger les rooms PMS pour récupérer labels + couleurs dynamiques
    await loadRooms();

    // 2) Charger les réservations
    const apiUrl = 'http://localhost:8080/api/bookings'; // ou 8081 si ton backend bookings est là
    console.log('📡 Récupération des réservations :', apiUrl);

    const response = await fetch(apiUrl);

    if (!response.ok) {
      throw new Error(`Erreur API (${response.status})`);
    }

const bookings = await response.json();

/* =========================
  APPLICATION DU FILTRE DATES
  =========================
  On filtre côté front les réservations
  selon les champs From / To.
*/
const filteredBookings = Array.isArray(bookings)
    ? bookings.filter(bookingOverlapsFilter)
    : [];

    let html = `
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Client</th>
            <th>Hébergement</th>
            <th>Arrivée</th>
            <th>Départ</th>
            <th>Prix</th>
            <th>Statut</th>
            <th>Source</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
    `;

    if (filteredBookings && filteredBookings.length > 0) {
      filteredBookings.forEach((b) => {
        const bookingId = b.id || b.booking_id;
        const roomCode = b.room_code || '';
        const roomStyle = buildRoomStyle(roomCode);
        const roomLabel = buildRoomLabel(roomCode, b.units);

        const checkInDate = formatDateFR(b.check_in);
        const checkOutDate = formatDateFR(b.check_out);

        const guest = escapeHTML(b.guest_name || b.guest || '');
        const price = escapeHTML(b.price ?? '');
        const status = escapeHTML(b.status || '');
        const source = escapeHTML(b.source || '');
        const sourceLabel = formatSourceLabel(b.source);

        const readOnly = isReadOnlyUser();

        const editButton = readOnly
          ? `
            <button
              class="btn-edit"
              type="button"
              disabled
              title="Modification non autorisée pour ce rôle">
              ✏️ Modifier
            </button>
          `
          : `
            <a
              href="edit-booking.html?id=${encodeURIComponent(bookingId)}"
              class="btn-edit"
              title="Modifier cette réservation">
              ✏️ Modifier
            </a>
          `;

        const deleteButton = readOnly
          ? `
            <button
              class="btn-delete"
              type="button"
              disabled
              title="Suppression non autorisée pour ce rôle">
              🗑️ Supprimer
            </button>
          `
          : `
            <button
              class="btn-delete"
              type="button"
              onclick="deleteBooking(${Number(bookingId)})"
              title="Supprimer cette réservation">
              🗑️ Supprimer
            </button>
          `;

        html += `
          <tr>
            <td ${roomStyle}>${escapeHTML(bookingId)}</td>
            <td ${roomStyle}><strong>${guest}</strong></td>
            <td ${roomStyle}>${escapeHTML(roomLabel)}</td>
            <td ${roomStyle}>${escapeHTML(checkInDate)}</td>
            <td ${roomStyle}>${escapeHTML(checkOutDate)}</td>
            <td ${roomStyle}>${price}€</td>
            <td ${roomStyle}>
              <span class="status-badge status-${status.toLowerCase()}">
                ${status}
              </span>
            </td>
            <td ${roomStyle}>
              <span class="badge badge-${source.toLowerCase()}">
                ${escapeHTML(sourceLabel)}
              </span>
            </td>
            <td class="actions" ${roomStyle}>
              <div class="actions-inner">
                ${editButton}
                ${deleteButton}
              </div>
            </td>
          </tr>
        `;
      });
    } else {
      html += `
        <tr>
          <td colspan="9" style="text-align:center;padding:40px;">
            📭 Aucune réservation trouvée pour cette période
          </td>
        </tr>
      `;
    }

    html += `
        </tbody>
      </table>
    `;

    const calendarEl = document.getElementById('calendar');
    if (calendarEl) {
      calendarEl.innerHTML = html;
    }
  } catch (error) {
    console.error('❌ Erreur lors du chargement :', error);

    const calendarEl = document.getElementById('calendar');
    if (calendarEl) {
      calendarEl.innerHTML = `
        <div style="
          background-color: #f8d7da;
          color: #721c24;
          padding: 20px;
          border-radius: 8px;
          border-left: 4px solid #dc3545;
          margin-top: 20px;
        ">
          <strong>⚠️ Erreur :</strong> ${escapeHTML(error.message)}
        </div>
      `;
    }
  }
}


/* =========================
   SUPPRESSION D'UNE RESERVATION
   ========================= */


/**
 * Supprime une réservation après confirmation
 * Interdit l'action si l'utilisateur est en lecture seule
 */
async function deleteBooking(bookingId) {
  if (isReadOnlyUser()) {
    alert('⛔ Vous êtes en lecture seule. Suppression non autorisée.');
    return;
  }

  const confirmed = confirm(
    '⚠️ Êtes-vous sûr de vouloir supprimer cette réservation ?\nCette action est irréversible.'
  );

  if (!confirmed) {
    console.log('Suppression annulée');
    return;
  }

  try {
    console.log('🗑️ Suppression de la réservation :', bookingId);

    const response = await fetch(`http://localhost:8080/api/bookings/delete/${bookingId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' }
    });

    const result = await response.json();

    if (response.ok && result.success) {
      alert('✅ Réservation supprimée avec succès !');
      await loadCalendar();
    } else {
      alert(`❌ Erreur : ${result.message || 'Impossible de supprimer la réservation'}`);
    }
  } catch (error) {
    alert(`❌ Erreur réseau : ${error.message}`);
    console.error('Erreur lors de la suppression :', error);
  }
}


/* =========================
   GESTION DES THEMES
   ========================= */


/**
 * Applique un thème à la page
 */
function applyTheme(theme) {
  document.body.classList.remove('theme-dark', 'theme-ocean');

  if (theme === 'dark') {
    document.body.classList.add('theme-dark');
  }

  if (theme === 'ocean') {
    document.body.classList.add('theme-ocean');
  }

  localStorage.setItem('pms-theme', theme);
}


/* =========================
   INITIALISATION
   ========================= */


document.addEventListener('DOMContentLoaded', async () => {
  // Chargement du thème sauvegardé
  const savedTheme = localStorage.getItem('pms-theme') || 'light';
  applyTheme(savedTheme);

  const themeSelect = document.getElementById('theme-select');
  if (themeSelect) {
    themeSelect.value = savedTheme;
    themeSelect.addEventListener('change', () => {
      applyTheme(themeSelect.value);
    });
  }

  // Récupération du user connecté depuis index.html si déjà défini
  if (window.currentUser) {
    currentUser = window.currentUser;
  } else if (typeof getCurrentUser === 'function') {
    // fallback si jamais index.html n'a pas encore mis à jour currentUser
    currentUser = await getCurrentUser();
  }

  /* =========================
    INITIALISATION FILTRES DATES
    ========================= */
  const filterFromInput = document.getElementById('filter-from');
  const filterToInput = document.getElementById('filter-to');
  const applyDateFilterBtn = document.getElementById('apply-date-filter');
  const resetDateFilterBtn = document.getElementById('reset-date-filter');

  if (applyDateFilterBtn) {
    applyDateFilterBtn.addEventListener('click', async () => {
      const fromValue = filterFromInput?.value || '';
      const toValue = filterToInput?.value || '';

      if (fromValue && toValue && fromValue > toValue) {
        alert('⚠️ La date "From" doit être antérieure ou égale à la date "To".');
        return;
      }

      filterFromDate = fromValue;
      filterToDate = toValue;

      await loadCalendar();
    });
  }

  if (resetDateFilterBtn) {
    resetDateFilterBtn.addEventListener('click', async () => {
      filterFromDate = '';
      filterToDate = '';

      if (filterFromInput) filterFromInput.value = '';
      if (filterToInput) filterToInput.value = '';

      await loadCalendar();
    });
  }

  // Chargement initial du calendrier
  await loadCalendar();

  // Rafraîchissement automatique toutes les 30 secondes
  if (calendarRefreshInterval) {
    clearInterval(calendarRefreshInterval);
  }

  calendarRefreshInterval = setInterval(loadCalendar, 30000);
});