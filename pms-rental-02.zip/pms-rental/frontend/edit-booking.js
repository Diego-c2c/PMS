/**
 * =========================================
 * EDIT-BOOKING.JS - MODIFICATION DE RÉSERVATION
 * =========================================
 *
 * Rôle :
 * - récupérer une réservation (booking OU calendar_block) par son ID
 * - remplir automatiquement le formulaire
 * - permettre la modification
 * - envoyer la mise à jour à l'API backend
 *
 * IMPORTANT :
 * - auth.js doit être chargé avant si tu utilises initPage/logout ailleurs
 * - room_config.js doit être chargé AVANT ce fichier
 *
 * Flux :
 * - edit-booking.html lit ?id=...&type=...
 * - si type=booking       → loadBookingData(id)
 * - si type=calendar_block → loadCalendarBlockData(id)
 * - au chargement, chaque loader remplit le formulaire et pose :
 *     form.dataset.bookingId
 *     form.dataset.entityType
 * - au submit, on lit ces dataset pour choisir la bonne route PUT
 */


// =========================
// UTILITAIRES UI
// =========================

function showMessage(msg, type = 'info') {
  const messageDiv = document.getElementById('message');
  if (!messageDiv) return;

  messageDiv.textContent = msg;
  messageDiv.className = `message ${type}`;
  messageDiv.style.display = 'block';

  if (type === 'success') {
    setTimeout(() => {
      messageDiv.style.display = 'none';
    }, 5000);
  }
}


// =========================
// UTILITAIRES ROOM CONFIG
// =========================

function getBookingRoomCode(booking) {
  return booking?.roomCode || booking?.room_code || '';
}

function getRoomConfig(roomCode) {
  if (!roomCode || !window.ROOM_CONFIG) return null;
  return window.ROOM_CONFIG[roomCode] || null;
}

function populateRoomSelect() {
  const roomSelect = document.getElementById('roomCode');
  if (!roomSelect || !window.ROOM_CONFIG) return;

  roomSelect.innerHTML = '<option value="">-- Choisir --</option>';

  Object.values(window.ROOM_CONFIG).forEach(room => {
    const option = document.createElement('option');
    option.value = room.roomCode;
    option.textContent = room.name;
    option.style.backgroundColor = room.bg;
    option.style.color = room.optionTextColor || room.text || '#000000';
    roomSelect.appendChild(option);
  });
}

function updateRoomSelectColor() {
  const roomSelect = document.getElementById('roomCode');
  if (!roomSelect) return;

  const room = getRoomConfig(roomSelect.value);

  if (!room) {
    roomSelect.style.backgroundColor = '';
    roomSelect.style.color = '';
    roomSelect.style.borderColor = '';
    return;
  }

  roomSelect.style.backgroundColor = room.bg;
  roomSelect.style.color = room.optionTextColor || room.text || '#000000';
  roomSelect.style.borderColor = room.bg;
}


// =========================
// VALIDATION / FORMAT
// =========================

function sanitizePriceInput(value) {
  let clean = String(value || '').replace(/[^0-9.,]/g, '');
  clean = clean.replace(',', '.');

  if (clean.includes('.')) {
    const parts = clean.split('.');
    clean = parts[0] + '.' + (parts[1] || '').substring(0, 2);
  }

  return clean;
}

function validateDates(checkIn, checkOut) {
  if (!checkIn || !checkOut) {
    throw new Error("Les dates d'arrivée et de départ sont obligatoires.");
  }

  if (checkOut <= checkIn) {
    throw new Error("La date de départ doit être après la date d'arrivée.");
  }
}

/**
 * Construit le payload à envoyer au backend
 * depuis les champs du formulaire.
 *
 * - booking        -> check_in / check_out
 * - calendar_block -> date_from / date_to
 */
function buildPayloadFromForm(entityType = 'booking') {
  const guestName = document.getElementById('guestName')?.value.trim() || '';
  const description = document.getElementById('description')?.value.trim() || '';
  const checkIn = document.getElementById('checkIn')?.value || '';
  const checkOut = document.getElementById('checkOut')?.value || '';
  const roomCode = document.getElementById('roomCode')?.value || '';
  const source = document.getElementById('source')?.value || 'direct';
  const status = document.getElementById('status')?.value || 'confirmed';

  const unitsRaw = document.getElementById('units')?.value;
  const units = parseInt(unitsRaw, 10) || 1;

  const priceRaw = document.getElementById('price')?.value || '';
  const priceClean = sanitizePriceInput(priceRaw);
  const price = priceClean === '' ? 0 : parseFloat(priceClean);

  if (!guestName) {
    throw new Error('Le nom du client est obligatoire.');
  }

  if (!roomCode) {
    throw new Error("L'hébergement est obligatoire.");
  }

  validateDates(checkIn, checkOut);

  // Payload commun
  const basePayload = {
    guest_name: guestName,
    description,
    price,
    source,
    status,
    room_code: roomCode,
    units
  };

// Cas spécifique calendar_block
// On garde le backend Go inchangé : il attend check_in / check_out
if (entityType === 'calendar_block') {
  return {
    ...basePayload,
    check_in: checkIn,
    check_out: checkOut
  };
}


// Cas booking classique
return {
  ...basePayload,
  check_in: checkIn,
  check_out: checkOut
};
}

// =========================
// CHARGEMENT : BOOKING
// =========================

/**
 * Charge une réservation classique (table bookings)
 * puis remplit le formulaire d’édition.
 */
async function loadBookingData(bookingId) {
  try {
    const apiUrl = `http://localhost:8080/api/bookings/${bookingId}`;
    console.log('📡 Récupération booking :', apiUrl);

    const response = await fetch(apiUrl);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status} - Réservation non trouvée`);
    }

    const booking = await response.json();
    console.log('✅ Réservation chargée :', booking);

    document.getElementById('guestName').value =
      booking.guest_name || booking.guest || '';

    document.getElementById('description').value =
      booking.description || '';

    document.getElementById('checkIn').value =
      booking.check_in ? String(booking.check_in).split('T')[0] : '';

    document.getElementById('checkOut').value =
      booking.check_out ? String(booking.check_out).split('T')[0] : '';

    document.getElementById('price').value =
      booking.price != null ? booking.price : '';

    document.getElementById('source').value =
      booking.source || 'direct';

    document.getElementById('status').value =
      booking.status || 'confirmed';

    document.getElementById('units').value =
      booking.units || 1;

    const roomCode = getBookingRoomCode(booking);
    document.getElementById('roomCode').value = roomCode;
    updateRoomSelectColor();

    const form = document.getElementById('editBookingForm');
    form.dataset.bookingId = bookingId;
    form.dataset.entityType = 'booking';
  } catch (error) {
    console.error('❌ Erreur chargement réservation :', error);
    showMessage(`❌ Erreur : ${error.message}`, 'error');
  }
}


// =========================
// CHARGEMENT : CALENDAR_BLOCK
// =========================

/**
 * Charge un bloc calendrier iCal (table calendar_blocks)
 * puis remplit le même formulaire pour édition.
 *
 * Nécessite une route backend du type :
 *   GET /api/calendar-blocks/:id
 */
async function loadCalendarBlockData(blockId) {
  try {
    const apiUrl = `http://localhost:8080/api/calendar-blocks/${blockId}`;
    console.log('📡 Récupération calendar_block :', apiUrl);

    const response = await fetch(apiUrl, {
      credentials: 'include'
    });

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('Non authentifié ou accès refusé sur le backend PMS.');
      }
      if (response.status === 403) {
        throw new Error('Accès refusé à ce bloc calendrier.');
      }
      if (response.status === 404) {
        throw new Error('Bloc calendrier non trouvé.');
      }

      throw new Error(`HTTP ${response.status} - Erreur lors du chargement du bloc calendrier`);
    }

    const block = await response.json();
    console.log('✅ calendar_block chargé :', block);

    // =========================
    // REMPLISSAGE DES CHAMPS
    // =========================
    // Structure réelle reçue :
    // {
    //   id,
    //   property_id,
    //   date_from,
    //   date_to,
    //   block_type,
    //   reason,
    //   created_at,
    //   room_code,
    //   guest_name,
    //   description,
    //   price,
    //   source,
    //   status,
    //   units
    // }

    document.getElementById('guestName').value =
      block.guest_name || 'Imported iCal';

    document.getElementById('description').value =
      block.description || block.reason || '';

    document.getElementById('checkIn').value =
      block.date_from ? String(block.date_from).split('T')[0] : '';

    document.getElementById('checkOut').value =
      block.date_to ? String(block.date_to).split('T')[0] : '';

    document.getElementById('price').value =
      block.price != null ? block.price : '0';

    document.getElementById('units').value =
      block.units || 1;

    document.getElementById('source').value =
      block.source || 'booking';

    document.getElementById('status').value =
      block.status || 'confirmed';

    document.getElementById('roomCode').value =
      block.room_code || '';

    updateRoomSelectColor();

    // =========================
    // MÉMORISER ID + TYPE
    // =========================
    const form = document.getElementById('editBookingForm');
    form.dataset.bookingId = blockId;
    form.dataset.entityType = 'calendar_block';

    // =========================
    // CHAMPS MODIFIABLES
    // =========================
    // Tu veux pouvoir modifier :
    // - guestName
    // - description
    // - price
    document.getElementById('guestName').readOnly = false;
    document.getElementById('description').readOnly = false;
    document.getElementById('price').readOnly = false;

    // =========================
    // CHAMPS VERROUILLÉS
    // =========================
    // On verrouille les données structurelles de l’import iCal
    document.getElementById('checkIn').readOnly = true;
    document.getElementById('checkOut').readOnly = true;
    document.getElementById('units').readOnly = true;

    // source / status / roomCode sont des <select>
    // disabled = non modifiables
    document.getElementById('source').disabled = true;
    document.getElementById('status').disabled = true;
    document.getElementById('roomCode').disabled = true;

    // =========================
    // STYLE VISUEL
    // =========================
    // Champs verrouillés = gris
    ['checkIn', 'checkOut', 'units', 'source', 'status', 'roomCode'].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.style.backgroundColor = '#f3f4f6';
        el.style.cursor = 'not-allowed';
      }
    });

    // Champs modifiables = style normal
    ['guestName', 'description', 'price'].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.style.backgroundColor = '';
        el.style.cursor = '';
      }
    });

    // =========================
    // REQUIRED
    // =========================
    // Les dates sont remplies, donc pas de blocage de validation
    // On garde les champs modifiables utilisables normalement
    document.getElementById('guestName').required = true;
    document.getElementById('checkIn').required = true;
    document.getElementById('checkOut').required = true;
    document.getElementById('price').required = false;

  } catch (error) {
    console.error('❌ Erreur chargement calendar_block :', error);
    showMessage(`❌ Erreur : ${error.message}`, 'error');
  }
}


// =========================
// SOUMISSION DU FORMULAIRE
// =========================

/**
 * Envoie la réservation modifiée à l'API backend.
 *
 * IMPORTANT :
 * - on lit l'ID ET le type depuis les dataset du formulaire
 * - si entityType = booking       → PUT /api/bookings/update/:id
 * - si entityType = calendar_block → PUT /api/calendar-blocks/update/:id
 */
async function submitBookingUpdate(event) {
  event.preventDefault();

  try {
    const form = event.currentTarget;
    const bookingId = form?.dataset?.bookingId;
    const entityType = form?.dataset?.entityType || 'booking';

    if (!bookingId) {
      throw new Error("ID de réservation introuvable dans le formulaire.");
    }

    const payload = buildPayloadFromForm(entityType);

    let apiUrl;
    if (entityType === 'calendar_block') {
      apiUrl = `http://localhost:8080/api/calendar-blocks/update/${bookingId}`;
    } else {
      apiUrl = `http://localhost:8080/api/bookings/update/${bookingId}`;
    }

    console.log('📤 Mise à jour', entityType, ':', apiUrl, payload);

    const response = await fetch(apiUrl, {
      method: 'PUT',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    let result = null;
    const rawText = await response.text();

    try {
      result = rawText ? JSON.parse(rawText) : null;
    } catch {
      result = null;
    }

    if (!response.ok) {
      const backendMessage =
        result?.message ||
        result?.error ||
        `HTTP ${response.status} - Erreur lors de la mise à jour`;

      throw new Error(backendMessage);
    }

    console.log('✅ Mise à jour réussie :', result);
    showMessage('✅ Modification enregistrée avec succès', 'success');

    setTimeout(() => {
      window.location.href = 'calendar-view.html';
    }, 800);

      // Optionnel : retour automatique
      // setTimeout(() => {
      //   window.location.href = 'calendar-view.html';
      // }, 1200);

    } catch (error) {
      console.error('❌ Erreur mise à jour :', error);
      showMessage(`❌ ${error.message}`, 'error');
    }
}


// =========================
// INITIALISATION DE LA PAGE
// =========================

document.addEventListener('DOMContentLoaded', () => {
  populateRoomSelect();

  const roomSelect = document.getElementById('roomCode');
  if (roomSelect) {
    roomSelect.addEventListener('change', updateRoomSelectColor);
  }

  const priceInput = document.getElementById('price');
  if (priceInput) {
    priceInput.addEventListener('input', (e) => {
      e.target.value = sanitizePriceInput(e.target.value);
    });
  }

  // Ouvrir le calendrier en cliquant n'importe où dans le champ date
  const checkInInput = document.getElementById('checkIn');
  const checkOutInput = document.getElementById('checkOut');

  if (checkInInput && typeof checkInInput.showPicker === 'function') {
    checkInInput.addEventListener('click', function () {
      this.showPicker();
    });
  }

  if (checkOutInput && typeof checkOutInput.showPicker === 'function') {
    checkOutInput.addEventListener('click', function () {
      this.showPicker();
    });
  }

  const form = document.getElementById('editBookingForm');
  if (form) {
    form.addEventListener('submit', submitBookingUpdate);
  }
});