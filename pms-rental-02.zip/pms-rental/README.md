# PMS Rental

PMS léger pour locations courte durée avec calendrier unifié, imports iCal, édition des réservations et rôles utilisateurs.

## Services

- frontend : `http://localhost:3000`
- backend PMS : `http://localhost:8080`
- backend auth : `http://localhost:8081`
- PostgreSQL : `localhost:5432`

## Règles d’architecture

- `8080` = API métier PMS (Go) : bookings, calendar_blocks, calendrier unifié, pricing, intégrations iCal / Booking.com
- `8081` = API auth (Node.js) : utilisateurs, rôles, sessions, login/logout

Le frontend utilise :
- `8081` pour l’authentification et la session,
- `8080` pour toutes les données PMS (bookings, calendar, blocks, pricing).

## Démarrage (développement)

```bash
docker compose up --build
# ou en détaché
docker compose up -d --build
```

À la première initialisation d’une base neuve (volume Postgres vide), Postgres exécute automatiquement :

- `db/01-init.sql` : schéma complet (tables, séquences, index, triggers, FKs)
- `db/02-seed.sql` : données de test (propriété, chambres, channel direct, booking_links, bookings, calendar_blocks)

Ensuite, lancer la création/mise à jour de l’admin :

```bash
docker exec -it pms-auth-backend node seedAdmin.js
```

## Compte admin de développement

- utilisateur : `admin@admin`
- mot de passe : `admin`

Les identifiants sont injectés via `.env` et gérés uniquement par `auth-backend/seedAdmin.js` (bcrypt). À changer avant toute mise en production.

## Schéma principal

Les tables métier PMS côté `pms_db` :

- `properties` : propriétés (ici `Cloud to Chill`)
- `rooms` : unités / types de chambre (codes `raspberry`, `blueberry`, `maracuja`, `surfhouse`, `female_dorm`)
- `channels` : canaux (direct, Booking.com, etc.)
- `booking_links` : liaison chambres PMS ↔ Booking.com (`booking_hotel_id`, `booking_room_id`, `booking_ical_url`…)
- `bookings` : réservations (source `direct` ou OTA, `guest_name`, `check_in`, `check_out`, `price`, `room_code`, `units`, `description`)
- `calendar_blocks` : blocs de calendrier (fermetures, blocs OTA, etc. avec `room_code`, `guest_name`, `description`, `price`, `source`, `status`, `units`)
- `pricing` : prix calculés par date
- `ical_imports` : configuration d’import iCal
- `users`, `user_sessions` : gérés par le backend auth

Les colonnes `guest_name` et `description` existent à la fois dans `bookings` et `calendar_blocks` pour permettre un calendrier unifié homogène.

## API principales

Côté PMS (`8080`) :

- `GET /api/calendar`  
  Retourne un tableau homogène de lignes de calendrier avec au minimum :  
  `id`, `entityType` (`booking` ou `block`), `check_in`, `check_out`, `guest_name`, `description`, `source`, `status`, `room_code`, `units`, `price`.

- `GET /api/bookings` / `GET /api/bookings/:id`  
  Liste et détail des réservations.

- `POST /api/bookings/create`  
  Création d’une réservation.

- `PUT /api/bookings/update/:id`  
  Mise à jour d’une réservation existante (utilisée par `edit-booking`).

- `DELETE /api/bookings/delete/:id`  
  Suppression d’une réservation.

- `POST /api/calendar-blocks`  
  Création d’un bloc de calendrier.

- `GET /api/calendar-blocks/:id`  
  Détail d’un bloc.

- `PUT /api/calendar-blocks/update/:id`  
  Mise à jour d’un bloc.

- `POST /api/calendar-blocks/sync-from-ical`  
  Import iCal dans les blocks.

- `POST /api/pricing/sync` / `GET /api/pricing/current`  
  Synchronisation et lecture des prix.

Côté intégration Booking (via auth-backend `8081`) :

- `POST /api/integrations/booking/sync-calendar-v1`  
  Utilise les entrées `booking_links` (`booking_hotel_id`, `booking_room_id`, `booking_ical_url`) pour importer les disponibilités Booking.com dans `calendar_blocks`.

## Module `edit-booking`

Le module d’édition de réservation (`frontend/edit-booking.html` + `frontend/edit-booking.js`) :

- lit l’`id` de réservation dans l’URL (`edit-booking.html?id=1&type=booking`),
- charge la réservation via `GET /api/bookings/:id`,
- préremplit le formulaire (dates, prix, status, source, units, room_code, guest_name, description),
- stocke l’identifiant dans `data-booking-id` sur le formulaire,
- envoie la mise à jour via `PUT /api/bookings/update/:id` en utilisant l’ID stocké (et non plus l’URL) au submit,
- conserve le menu `roomCode` avec options colorées définies en HTML, en s’appuyant sur `room_config.js` pour retrouver la couleur associée à chaque chambre et éventuellement colorer le `<select>` lui‑même.

## CORS / Frontend

- Le backend PMS (`8080`) expose CORS avec `Access-Control-Allow-Origin: http://localhost:3000` et `Access-Control-Allow-Credentials: true`, et gère les requêtes `OPTIONS` pour les méthodes comme `PUT /api/bookings/update/:id`.
- Le frontend consomme les APIs en `credentials: 'include'` pour conserver la session auth.

## Déploiement VPS (résumé)

1. Copier le projet sur le serveur.
2. Installer Docker + Docker Compose.
3. Créer un `.env` spécifique (secrets, mots de passe, URL frontend).
4. Adapter CORS pour le vrai domaine (remplacer `http://localhost:3000`).
5. Lancer `docker compose up -d --build`.
6. Exposer uniquement le frontend et/ou les APIs via un reverse proxy (Nginx, Caddy) et un firewall.
7. Lancer `seedAdmin.js` sur le serveur pour créer l’admin.

---



Pour la doc `pms-edit-booking` :

- Oui, il faut la versionner aussi si tu veux garder cette trace dans le repo.
- Ajoute simplement un fichier, par exemple `docs/EDIT_BOOKING.md`, avec le contenu que tu as déjà (en ajustant éventuellement les références aux fichiers et l’API `PUT /api/bookings/update/:id`).

Si tu veux, je peux te renvoyer ce texte formaté proprement pour `docs/EDIT_BOOKING.md` en enlevant les `[cite:x]`.