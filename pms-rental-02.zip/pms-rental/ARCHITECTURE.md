## `ARCHITECTURE.md` mis à jour

```md
# PMS Rental – Architecture

## Vue d’ensemble

Le projet est organisé en quatre services Docker :

- `frontend` : interface Nginx (HTML/JS statique) sur `http://localhost:3000`
- `backend` : API PMS en Go sur `http://localhost:8080`
- `auth-backend` : API auth en Node.js sur `http://localhost:8081`
- `db` : PostgreSQL 15 (`pms_db`)

Les scripts d’initialisation de la base sont dans `db/` :

- `01-init.sql` : schéma complet (tables, séquences, contraintes, indexes, triggers)
- `02-seed.sql` : données de test (propriété, rooms, channel direct, booking_links, bookings, calendar_blocks)

À la première initialisation d’un volume vide, Postgres exécute ces scripts dans l’ordre alphabétique.

## Répartition des responsabilités

### Backend PMS (`8080`, Go)

Responsable de toute la **logique métier** :

- `bookings` : création, lecture, mise à jour, suppression de réservations
- `calendar_blocks` : gestion des blocs de calendrier (fermetures, blocs OTA, etc.)
- calendrier unifié (`GET /api/calendar`) qui agrège `bookings` et `calendar_blocks`
- `pricing` : synchronisation et exposition des prix
- intégrations iCal (import ICS distants dans `calendar_blocks`)
- endpoints techniques de santé (`/health`, etc.)

Le backend PMS expose des routes comme :

- `GET /api/bookings`, `GET /api/bookings/:id`
- `POST /api/bookings/create`
- `PUT /api/bookings/update/:id`
- `DELETE /api/bookings/delete/:id`
- `POST /api/calendar-blocks`
- `GET /api/calendar-blocks/:id`
- `PUT /api/calendar-blocks/update/:id`
- `POST /api/calendar-blocks/sync-from-ical`
- `GET /api/calendar`
- `POST /api/pricing/sync`, `GET /api/pricing/current`

CORS est configuré pour autoriser le frontend (`http://localhost:3000`) avec credentials.

### Backend Auth (`8081`, Node.js)

Responsable de :

- gestion des utilisateurs (`users`),
- hashing des mots de passe (bcrypt),
- sessions (`user_sessions`),
- rôles (`role` sur `users`),
- endpoints d’authentification (login/logout, vérification de session),
- intégration Booking.com côté “calendar sync” :
  - `POST /api/integrations/booking/sync-calendar-v1` qui :
    - résout la liaison dans `booking_links` (via `booking_hotel_id`, `booking_room_id`),
    - récupère les données Booking (iCal + API si nécessaire),
    - met à jour `calendar_blocks`.

Le script `auth-backend/seedAdmin.js` :

- s’appuie sur `.env` (`ADMIN_EMAIL`, `ADMIN_PASSWORD`, `BCRYPT_ROUNDS`) pour créer ou mettre à jour l’admin,
- n’écrit que dans `users` (pas de seed SQL pour les utilisateurs).

Le frontend utilise `8081` pour vérifier la session et rediriger vers login si nécessaire.

### Base de données (`db`)

Base PostgreSQL `pms_db` avec les tables principales :

- `properties`
- `rooms`
- `channels`
- `booking_links`
- `bookings`
- `calendar_blocks`
- `pricing`
- `ical_imports`
- `users`
- `user_sessions`

Des indexes ciblent les accès fréquents :

- `idx_bookings_property`
- `idx_bookings_dates`
- `idx_calendar_blocks_property`
- `idx_calendar_blocks_property_date`
- `idx_calendar_blocks_property_room_date`
- `idx_booking_links_*`
- `idx_rooms_code`, `idx_rooms_external_id`

Un trigger `trg_booking_links_updated_at` met à jour `updated_at` sur `booking_links` via la fonction `set_updated_at()`.

## Contrat calendrier

`GET /api/calendar` (backend PMS) retourne un tableau homogène de lignes de calendrier pour affichage dans `frontend/calendar-view.js`.

Chaque ligne contient au minimum :

- `id` : identifiant interne (booking ou block)
- `entityType` : `booking` ou `block`
- `check_in`, `check_out` : plages de date
- `guest_name` : nom du client (si présent)
- `description` : note détaillée (si présente)
- `source` : `direct`, `booking`, etc.
- `status` : `confirmed`, `cancelled`, ou équivalent
- `room_code` : code de chambre (`raspberry`, `blueberry`, etc.)
- `units` : nombre d’unités (par défaut 1)
- `price` : montant total ou de référence

Les colonnes `guest_name` et `description` de `calendar_blocks` sont utilisées **en priorité** lorsque présentes ; `reason` reste un fallback historique pour des blocs anciens ou sans détail client.

## Module `edit-booking`

### Fichiers

- `frontend/edit-booking.html` : template de page, formulaire, `<select>` des chambres avec options colorées, inclusion des scripts (`auth.js`, `room_config.js`, `edit-booking.js`).
- `frontend/edit-booking.js` : logique de page :
  - lecture de `id` et `type` dans l’URL,
  - appel à `GET /api/bookings/:id`,
  - pré-remplissage du formulaire,
  - stockage de l’ID dans `data-booking-id`,
  - validation des champs (dates, prix, nom, chambre),
  - soumission via `PUT /api/bookings/update/:id`.
- `frontend/room_config.js` : configuration des chambres côté frontend (codes, labels, couleurs) pour centraliser la logique visuelle.
- éventuellement `frontend/auth.js` : initialisation de la page, vérification de session, redirection si non connecté.

### Flux

1. À `DOMContentLoaded`, la page :
   - vérifie la session (via `auth.js`),
   - lit `id` dans l’URL (`edit-booking.html?id=1&type=booking`),
   - appelle `loadBookingData(bookingId)`.

2. `loadBookingData` :
   - interroge `GET /api/bookings/:id` sur `8080`,
   - remplit `guest_name`, `description`, `check_in`, `check_out`, `price`, `status`, `source`, `units`, `room_code`,
   - stocke l’ID dans `editBookingForm.dataset.bookingId`.

3. À la soumission :
   - le code lit `event.currentTarget.dataset.bookingId`,
   - construit un payload JSON propre,
   - envoie `PUT /api/bookings/update/:id` sur `8080`,
   - gère les erreurs réseau/CORS et les messages de succès/erreur.

Le menu `roomCode` est maintenu avec options colorées en HTML, et la couleur du `<select>` peut être ajustée dynamiquement en fonction de la chambre choisie, en s’appuyant sur `ROOM_CONFIG`.

## Déploiement VPS

1. Copier le projet sur le VPS (`git clone` du repo ou transfert du dossier).
2. Installer Docker & Docker Compose.
3. Créer et remplir `.env` pour le VPS (DB, secrets, URL frontend, admin auth).
4. Adapter CORS (remplacer `http://localhost:3000` par le domaine réel).
5. Lancer `docker compose up -d --build`.
6. Exposer uniquement le frontend (et éventuellement un API gateway) derrière un reverse proxy (Nginx, Caddy).
7. Lancer `docker exec -it pms-auth-backend node seedAdmin.js` pour créer l’admin.
8. Mettre en place des sauvegardes régulières du volume Postgres et/ou des dumps `pg_dump`.

## Compte de développement

- utilisateur : `admin@admin`
- mot de passe : `admin`

À changer et gérer via `seedAdmin.js` et `.env` avant toute mise en production.
```

---