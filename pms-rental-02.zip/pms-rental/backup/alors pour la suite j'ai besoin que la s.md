alors pour la suite j'ai besoin que la section AJOUT D'UNE FUTURE UNITE PMS dans update.html

  // =========================
  // AJOUT D'UNE FUTURE UNITE PMS
  // =========================

  function addFutureUnitToPms() {
    const hotelId = document.getElementById('newHotelId').value.trim();
    const roomId = document.getElementById('newRoomId').value.trim();
    const roomName = document.getElementById('newRoomName').value.trim();
    const roomIcal = document.getElementById('newRoomIcal').value.trim();

    if (!hotelId || !roomId || !roomName) {
      showMessage('Veuillez remplir Booking Hotel ID, Booking Room ID et le nom de l’hébergement.', 'error');
      return;
    }

    showMessage(
      'Hébergement prêt à être ajouté au PMS : ' +
      roomName + ' (' + roomId + ') pour l’hôtel ' + hotelId +
      (roomIcal ? ' avec URL iCal renseignée.' : ' sans URL iCal pour le moment.'),
      'success'
    );
  }

ajoute :

une ligne dans 

--
-- Name: booking_links; Type: TABLE; Schema: public; Owner: pms_user
--

CREATE TABLE public.booking_links (
    id integer NOT NULL,
    property_id integer NOT NULL,
    room_id integer,
    booking_hotel_id character varying(100) NOT NULL,
    booking_room_id character varying(100) NOT NULL,
    booking_room_name character varying(255),
    booking_unit_type character varying(50),
    display_order integer DEFAULT 0,
    booking_ical_url text NOT NULL,
    booking_ical_export_url text,
    is_active boolean DEFAULT true NOT NULL,
    last_ical_sync_at timestamp without time zone,
    last_ical_sync_status character varying(50),
    last_ical_sync_error text,
    booking_rate_plan_id character varying(100),
    last_api_sync_at timestamp without time zone,
    last_api_sync_status character varying(50),
    last_api_sync_error text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

une option dans

<!-- =========================
         BLOC 1
         Choix de l’hébergement à synchroniser
         ========================= -->
    <div class="card">
      <h2>Choix de l’hébergement</h2>

      <div class="field-inline">
        <label for="roomSelect">Synchroniser :</label>
        <select id="roomSelect">
          <option value="all">Tous les hébergements</option>
          <option value="520741601">Raspberry Room (520741601)</option>
          <option value="520741602">Blueberry Room (520741602)</option>
          <option value="520741603">Maracuja Room (520741603)</option>
          <option value="520741604">Cloud to Chill Surf House (520741604)</option>
          <option value="520741605">Bed in Shared Female Room (520741605)</option>
        </select>
      </div>

      <p class="sync-description">
        Booking affiche bien “Tous les hébergements” ainsi que tes 5 unités séparées dans son calendrier.
      </p>
      <button type="button" id="purgeBookingsBtn" class="btn-add" style="background-color:#b91c1c; border-color:#7f1d1d;">
        Purger les réservations ical
      </button>
    </div>

    avec un nouveau champ a lui type <strong>Raspberry Room (520741601)</strong> dans le block 2

    <!-- =========================
         BLOC 2
         URLs iCal par hébergement
         Chaque unité a son propre champ
         ========================= -->
    <div class="card">
      <h2>URLs iCal Booking</h2>
      <p class="sync-description">
        Renseigne ici les URLs iCal dès que tu les récupères depuis Booking.
      </p>

      <div class="room-url-grid">
        <div class="room-url-item">
          <strong>Raspberry Room (520741601)</strong>
          <input type="text" id="ical_520741601" placeholder="https://ical.booking.com/v1/export?t=d5ff92f2-52dc-4701-91ab-73c95bacde32">
        </div>

        <div class="room-url-item">
          <strong>Blueberry Room (520741602)</strong>
          <input type="text" id="ical_520741602" placeholder="https://...">
        </div>

        <div class="room-url-item">
          <strong>Maracuja Room (520741603)</strong>
          <input type="text" id="ical_520741603" placeholder="https://...">
        </div>

        <div class="room-url-item">
          <strong>Cloud to Chill Surf House (520741604)</strong>
          <input type="text" id="ical_520741604" placeholder="https://...">
        </div>

        <div class="room-url-item">
          <strong>Bed in Shared Female Room (520741605)</strong>
          <input type="text" id="ical_520741605" placeholder="https://...">
        </div>
      </div>

      <div class="sync-actions">
        <button id="btn-sync-v1" class="btn-sync-v1">🔄 V1 - Sync calendrier (iCal)</button>
        <button class="btn-sync-v2" title="À venir">🚧 V2 - Sync avancée (API Booking) - bientôt</button>
      </div>

      <p class="small-note">
        V1 télécharge l'iCal Booking, le parse, et insère les blocs dans calendar_blocks via le backend Go.
      </p>
    </div>

    mais pas que, il faut aussi par la meme occassion quelle ajoute ou puisse utilise un ligne de la table room
--
-- Name: rooms; Type: TABLE; Schema: public; Owner: pms_user
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    external_id bigint NOT NULL,
    code character varying(50) NOT NULL,
    label character varying(255) NOT NULL,
    color character varying(7) NOT NULL,
    capacity integer NOT NULL
);

enfin de cree de nouveau hebergement dans mon PMS et de le lie a un nouvelle ical de booking, Alors il y a deja un debut coder dans update.html mais tout reste a faire c'est

    <!-- =========================
         BLOC 3
         Ajouter une future unité dans TON PMS
         Cela ne crée rien dans Booking.com
         ========================= -->
    <div class="card">
      <h2>Ajouter un hébergement au PMS</h2>

      <div class="field-inline">
        <label for="newHotelId">Booking Hotel ID :</label>
        <input type="text" id="newHotelId" value="5207416">
      </div>

      <div class="field-inline">
        <label for="newRoomId">Booking Room ID :</label>
        <input type="text" id="newRoomId" placeholder="Ex : 520741606">
      </div>

      <div class="field-inline">
        <label for="newRoomName">Nom de l’hébergement :</label>
        <input type="text" id="newRoomName" placeholder="Ex : Mango Room">
      </div>

      <div class="field-inline">
        <label for="newRoomIcal">URL iCal (optionnelle) :</label>
        <input type="text" id="newRoomIcal" placeholder="https://...">
      </div>

      <div class="sync-actions">
        <button id="btn-add-unit" class="btn-add-unit">➕ Ajouter au PMS</button>
      </div>

      <p class="small-note">
        Ce bouton prépare seulement ton PMS. L’ajout réel d’un hébergement côté Booking se fait dans l’extranet Booking.
      </p>
    </div>

    alors dis moi ou on commence veut tu que je t'upload le zip complet du programme