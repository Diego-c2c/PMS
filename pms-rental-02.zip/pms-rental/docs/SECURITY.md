# Security

## Secrets
- Ne jamais versionner les `.env`.
- Ne jamais committer de cookies, tokens, mots de passe ou clés API.
- Utiliser `.env.example` pour documenter la configuration attendue.

## Sessions
- Utiliser un `SESSION_SECRET` fort et unique.
- Sécuriser les cookies selon l'environnement.
- Ajouter `secure`, `httpOnly` et `sameSite` selon le contexte de déploiement.

## Rôles
- `user` : lecture seule.
- `manager` : création/modification.
- `admin` : administration complète.

## Publication GitHub
Avant push public :
- vérifier `git status` ;
- inspecter `.env` ;
- chercher les secrets dans le code ;
- nettoyer les captures et exports contenant des données personnelles.

## Recommandations
- Ajouter rate limiting sur auth.
- Ajouter validation stricte côté backend.
- Journaliser les opérations sensibles.
- Prévoir rotation des secrets.
