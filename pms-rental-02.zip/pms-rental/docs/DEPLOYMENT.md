# Déploiement VPS

## Variables à changer

- `POSTGRES_PASSWORD`
- `SESSION_SECRET`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

## Lancement

```bash
docker compose up -d --build
```

## Ports

- 3000 : frontend
- 8080 : PMS
- 8081 : auth
- 5432 : PostgreSQL

Sur VPS, éviter d'exposer 5432 directement sur Internet.

## Compte par défaut

Développement uniquement :

- utilisateur : `admin`
- mot de passe : `admin`

Changer ce compte avant production.
