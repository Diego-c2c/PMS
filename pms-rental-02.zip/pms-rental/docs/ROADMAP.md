# Roadmap

## Phase 1 - Socle PMS
- Authentification par session
- Rôles user / manager / admin
- Liste des réservations
- Vues calendrier
- Création et modification

## Phase 2 - Administration
- Gestion utilisateurs
- Protection des pages par rôle
- Harmonisation UI et auth.js

## Phase 3 - Synchronisation Booking.com
- Finaliser endpoint backend de sync
- Mapper formats PMS -> Booking
- Ajouter logs de sync
- Gérer erreurs, retries, statuts
- Tester sur un petit périmètre réel

## Phase 4 - Synchronisation Airbnb
- Définir connecteur séparé
- Répliquer le pattern Booking
- Journaliser les échanges
- Tester et sécuriser

## Phase 5 - Durcissement
- Tests backend
- Gestion centralisée config
- Monitoring et logs
- Déploiement
