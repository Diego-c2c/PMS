# Changelog

## Unreleased
- Documentation initiale du projet
- Clarification architecture
- Ajout des fichiers Git de base
- Préparation roadmap Booking puis Airbnb
