require('dotenv').config({ path: '../.env' });
const bcrypt = require('bcrypt');
const pool = require('./db');
const initAuthTables = require('./initAuthTables');

async function seedAdmin() {
  const email = process.env.ADMIN_EMAIL || 'admin@admin';
  const password = process.env.ADMIN_PASSWORD || 'admin';
  const rounds = Number(process.env.BCRYPT_ROUNDS || 12);

  await initAuthTables();

  const passwordHash = await bcrypt.hash(password, rounds);

  await pool.query(
    `INSERT INTO users (email, password_hash, role)
     VALUES ($1, $2, $3)
     ON CONFLICT (email)
     DO UPDATE SET
       password_hash = EXCLUDED.password_hash,
       role = EXCLUDED.role`,
    [email, passwordHash, 'admin']
  );

  console.log(`✅ Admin seedé ou mis à jour : ${email}`);
  process.exit(0);
}

seedAdmin().catch((err) => {
  console.error('❌ Erreur seed admin:', err);
  process.exit(1);
});