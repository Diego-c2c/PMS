function requireAuth(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }

  return res.status(401).json({ error: 'Non authentifié' });
}

const roleLevels = {
  user: 1,
  manager: 2,
  admin: 3
};

function requireRole(minRole) {
  return (req, res, next) => {
    if (!req.session || !req.session.user) {
      return res.status(401).json({ error: 'Non authentifié' });
    }

    const userRole = req.session.user.role;
    const userLevel = roleLevels[userRole] || 0;
    const requiredLevel = roleLevels[minRole] || 0;

    if (userLevel < requiredLevel) {
      return res.status(403).json({ error: `Accès refusé - rôle ${minRole} minimum requis` });
    }

    return next();
  };
}

module.exports = {
  requireAuth,
  requireReadOnly: requireRole('user'),
  requireManager: requireRole('manager'),
  requireAdmin: requireRole('admin')
};