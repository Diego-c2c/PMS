const pool = require('../db');

/*
 * roomsService.js
 * Liste toutes les rooms PMS existantes.
 * Utilisé par update.html pour remplir dynamiquement le select du bloc 3.
 */
async function listRooms() {
  const result = await pool.query(`
    SELECT
      id,
      code,
      label,
      color,
      capacity,
      external_id
    FROM public.rooms
    ORDER BY label ASC
  `);

  return result.rows;
}

module.exports = {
  listRooms
};