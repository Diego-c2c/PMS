// services/bookingCalendarService.js
// --------------------------------------------------
// Logique métier pour synchroniser un flux iCal Booking
// vers le PMS.
//
// V1 :
// - on lit booking_links pour retrouver property_id
// - on télécharge le flux iCal Booking d'une room
// - on parse les événements VEVENT
// - on transforme les événements en blocs calendrier
// - on envoie ces blocs au backend Go
// --------------------------------------------------

const ICAL = require('ical.js');

// IMPORTANT : adapte ce require à ton vrai fichier de connexion PostgreSQL.
// Il faut un objet qui expose db.query(...) ou pool.query(...)
// Exemple possible :
// const db = require('../config/db');
// const db = require('../database/db');
// const { pool: db } = require('../config/database');
const db = require('../db');

/**
 * resolveBookingLink
 *
 * Rôle :
 * - retrouver la liaison Booking -> PMS dans booking_links
 * - obtenir le property_id interne PMS
 * - récupérer aussi l'URL iCal stockée en base si besoin
 *
 * Entrées :
 * - bookingHotelId : ID propriété Booking (ex: 5207416)
 * - bookingRoomId  : ID room Booking (ex: 520741601)
 *
 * Sortie :
 * - la ligne booking_links correspondante
 */
async function resolveBookingLink(bookingHotelId, bookingRoomId) {
  const query = `
    SELECT
      property_id,
      room_id,
      booking_ical_url,
      booking_room_name
    FROM booking_links
    WHERE booking_hotel_id = $1
      AND booking_room_id = $2
      AND is_active = TRUE
    LIMIT 1
  `;

  const values = [bookingHotelId, bookingRoomId];
  const result = await db.query(query, values);

  if (!result.rows.length) {
    throw new Error(
      `Aucune liaison booking_links trouvée pour booking_hotel_id=${bookingHotelId}, booking_room_id=${bookingRoomId}`
    );
  }

  return result.rows[0];
}

/**
 * syncCalendarV1
 *
 * Rôle :
 * - résoudre property_id depuis booking_links
 * - télécharger le flux iCal Booking d'une room
 * - parser les événements VEVENT
 * - transformer les événements en blocs PMS
 * - envoyer ces blocs au backend Go
 *
 * Paramètres attendus :
 * - room_code : identifiant room utilisé côté PMS/front
 * - booking_room_id : identifiant room Booking
 * - booking_ical_url : URL iCal Booking (optionnelle si déjà en base)
 * - booking_hotel_id : identifiant hôtel Booking
 * - user : utilisateur connecté
 * - channel : source OTA (par défaut Booking)
 * - status_default : statut de secours
 *
 * IMPORTANT :
 * - on n'utilise plus property_id = 1 en dur
 * - property_id est résolu via booking_links
 */
  async function syncCalendarV1(params) {
    const {
      room_code,
      booking_room_id,
      booking_ical_url,
      booking_hotel_id,
      user,
      channel = 'Booking',
      status_default = 'undefine'
    } = params;

    if (!booking_hotel_id) {
      throw new Error('booking_hotel_id manquant.');
    }

    if (!booking_room_id) {
      throw new Error('booking_room_id manquant.');
    }

    if (!room_code) {
      throw new Error('room_code manquant.');
    }

  try {
    // ----------------------------------------
    // 1. Résoudre la liaison Booking -> PMS
    // ----------------------------------------
    const bookingLink = await resolveBookingLink(booking_hotel_id, booking_room_id);

    // property_id PMS interne récupéré depuis booking_links
    const resolvedPropertyId = bookingLink.property_id;

    // Si le front n'envoie pas l'URL iCal, on prend celle stockée en base
    const effectiveIcalUrl = booking_ical_url || bookingLink.booking_ical_url;

    console.log('🔎 booking_links trouvé', {
      booking_hotel_id,
      booking_room_id,
      property_id: resolvedPropertyId,
      room_id: bookingLink.room_id || null,
      booking_room_name: bookingLink.booking_room_name || null
    });

    if (!effectiveIcalUrl) {
      throw new Error(
        `Aucune URL iCal disponible pour booking_hotel_id=${booking_hotel_id}, booking_room_id=${booking_room_id}`
      );
    }

    console.log('📥 Sync V1 - Téléchargement iCal Booking...', effectiveIcalUrl);

    // ----------------------------------------
    // 2. Télécharger le flux iCal Booking
    // ----------------------------------------
    const response = await fetch(effectiveIcalUrl);
    if (!response.ok) {
      throw new Error(`Impossible de télécharger iCal: ${response.status}`);
    }

    const icalText = await response.text();

    // ----------------------------------------
    // 3. Parser le contenu iCal avec ical.js
    // ----------------------------------------
    const jcal = ICAL.parse(icalText);
    const calendar = new ICAL.Component(jcal);

    // ----------------------------------------
    // 4. Récupérer tous les VEVENT
    // ----------------------------------------
    const events = calendar.getAllSubcomponents('vevent');
    console.log(`📋 Trouvé ${events.length} événements dans iCal`);

    // ----------------------------------------
    // 5. Transformer les VEVENT en blocs PMS
    // ----------------------------------------
    const blocksToInsert = [];

    events.forEach((vEvent) => {
      const event = new ICAL.Event(vEvent);

      const checkIn = event.startDate.toJSDate();
      const checkOut = event.endDate.toJSDate();

      // Booking iCal utilise souvent SUMMARY pour dire :
      // "CLOSED - Not available"
      const summary = event.summary || 'CLOSED';
      const description = event.description || summary;

      // UID iCal = identifiant externe utile pour le futur
      const externalBookingId = event.uid || null;

      blocksToInsert.push({
        room_code,
        booking_room_id,
        booking_hotel_id,
        external_booking_id: externalBookingId,
        guest_name: '',
        check_in: checkIn.toISOString().split('T')[0],
        check_out: checkOut.toISOString().split('T')[0],
        description,
        source: 'booking',
        price: 0,
        units: 1,
        type: 'block'
      });
    });

    console.log('✅ Événements parsés:', blocksToInsert.length);

    // ----------------------------------------
    // 6. Envoyer les blocs au backend Go
    // ----------------------------------------
    let imported_count = 0;

    if (blocksToInsert.length > 0) {
      imported_count = await insertBookingsIntoDB(
        blocksToInsert,
        room_code,
        resolvedPropertyId,
        channel,
        status_default
      );
    }

    console.log('✅ Sync V1 terminée', {
      room_code,
      booking_room_id,
      booking_hotel_id,
      property_id: resolvedPropertyId,
      imported_count,
      actor: user?.email || 'unknown'
    });

    return {
      imported_count,
      exported_count: 0,
      synced_at: new Date().toISOString()
    };
  } catch (error) {
    console.error('❌ Erreur service sync V1:', error);
    throw error;
  }
}

/**
 * insertBookingsIntoDB
 *
 * Malgré son nom historique, cette fonction envoie maintenant
 * des événements iCal au backend Go pour les enregistrer
 * dans calendar_blocks.
 *
 * Paramètres :
 * - bookings : tableau d'événements transformés
 * - roomCode : room_code/booking_room_id
 * - propertyId : ID interne PMS
 * - channel : Booking
 * - statusDefault : undefine
 */
async function insertBookingsIntoDB(
  bookings,
  roomCode,
  propertyId,
  channel = 'Booking',
  statusDefault = 'undefine'
) {
  try {
    const payload = {
      room_code: roomCode,
      property_id: propertyId,
      channel,
      status_default: statusDefault,
      bookings: bookings.map((b) => ({
        check_in: b.check_in,
        check_out: b.check_out,
        description: b.description,
        source: b.source,
        guest_name: b.guest_name || '',
        price: b.price || 0,
        type: 'block',
        external_booking_id: b.external_booking_id || null
      }))
    };

    console.log('📤 Envoi à pms-backend:', JSON.stringify(payload, null, 2));

    const response = await fetch('http://pms-backend:8080/api/calendar-blocks/sync-from-ical', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const rawText = await response.text();

    let result;
    try {
      result = JSON.parse(rawText);
    } catch {
      throw new Error(`Réponse non JSON du backend sync-from-ical: ${rawText}`);
    }

    if (!response.ok) {
      throw new Error(result.error || result.message || 'Erreur insertion DB');
    }

    console.log('✅ Insertions réussies:', result.inserted_count);
    return result.inserted_count || bookings.length;
  } catch (error) {
    console.error('❌ Erreur insertion DB:', error);
    throw error;
  }
}

/**
 * saveIcalConfig
 *
 * Placeholder V2 :
 * Sauvegardera plus tard la config iCal en base.
 */
async function saveIcalConfig(room_code, booking_ical_url) {
  console.log('Config iCal sauvegardée:', { room_code, booking_ical_url });
  return { success: true };
}

/**
 * getIcalConfig
 *
 * Placeholder V2 :
 * Lira plus tard la config iCal depuis la base.
 */
async function getIcalConfig(room_code) {
  console.log('Config iCal récupérée pour:', room_code);
  return { booking_ical_url: '' };
}

module.exports = {
  syncCalendarV1,
  insertBookingsIntoDB,
  saveIcalConfig,
  getIcalConfig
};