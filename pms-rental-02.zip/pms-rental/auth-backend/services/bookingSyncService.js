async function syncPricesToBooking(payload, context = {}) {
  const { property_id, email, updates } = payload;
  const actor = context.user?.email || 'unknown';

  console.log('Booking sync start', {
    property_id,
    actor,
    updates_count: updates.length
  });

  // TODO:
  // 1. Auth Booking
  // 2. Mapper les updates au format Booking
  // 3. Envoyer les prix
  // 4. Logger les résultats

  return {
    property_id,
    actor,
    updates_count: updates.length,
    status: 'stub',
    synced_at: new Date().toISOString(),
    email_used: email
  };
}

// ============================================================
// AJOUT D'UN LIEN BOOKING -> PMS \\\\\\bookingSyncService.js
// ============================================================

// IMPORTANT :
// Garde ici TON import PostgreSQL actuel du projet.
// Exemple fréquent :
// const pool = require('../config/db');
//
// Si ton fichier utilise déjà "pool" ou "db", réutilise exactement
// le même nom pour rester compatible.
const pool = require('../db');

/**
 * Ajoute un lien booking_links.
 *
 * Cas 1 : mode = existing_room
 * - retrouve la room PMS existante via rooms.code
 * - insère la ligne booking_links
 *
 * Cas 2 : mode = new_room
 * - crée une nouvelle room dans rooms
 * - insère ensuite la ligne booking_links
 *
 * Règle métier importante :
 * booking_links.booking_room_name = room.label
 */
async function addBookingLink({
  booking_hotel_id,
  booking_room_id,
  room_code,
  booking_room_name,
  color,
  mode
}) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // ==========================================================
    // 1) Retrouver la propriété PMS via booking_hotel_id
    // ----------------------------------------------------------
    // On part de l’ID hôtel Booking saisi dans le formulaire
    // pour retrouver la propriété interne PMS.
    // ==========================================================
    const propertyRes = await client.query(
      `
      SELECT id, booking_property_id
      FROM public.properties
      WHERE booking_property_id = $1
      LIMIT 1
      `,
      [booking_hotel_id]
    );

    if (propertyRes.rows.length === 0) {
      throw new Error(
        `Aucune propriété PMS trouvée pour booking_hotel_id = ${booking_hotel_id}`
      );
    }

    const property = propertyRes.rows[0];

    let room;

    // ==========================================================
    // 2) Cas room existante
    // ==========================================================
    if (mode === 'existing_room') {
      const roomRes = await client.query(
        `
        SELECT id, code, label, color, capacity
        FROM public.rooms
        WHERE code = $1
        LIMIT 1
        `,
        [room_code]
      );

      if (roomRes.rows.length === 0) {
        throw new Error(`Aucune room existante trouvée pour code = ${room_code}`);
      }

      room = roomRes.rows[0];
    }

    // ==========================================================
    // 3) Cas nouvelle room
    // ----------------------------------------------------------
    // Ici on crée une nouvelle ligne dans rooms.
    //
    // Hypothèse :
    // - external_id doit être unique / renseigné
    // - color est récupérée du color picker
    // - capacity n'étant pas dans ton dernier formulaire métier,
    //   on met ici une valeur par défaut de 1
    //
    // Si tu veux une autre stratégie pour external_id/capacity,
    // on l’ajuste ensuite.
    // ==========================================================
    if (mode === 'new_room') {
      // external_id temporaire basé sur le timestamp
      // pour éviter un NULL si la colonne est NOT NULL
      const generatedExternalId = Date.now();

      const roomInsertRes = await client.query(
        `
        INSERT INTO public.rooms (
          external_id,
          code,
          label,
          color,
          capacity
        )
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id, code, label, color, capacity, external_id
        `,
        [
          generatedExternalId,
          room_code,
          booking_room_name,
          color || '#999999',
          1
        ]
      );

      room = roomInsertRes.rows[0];
    }

    // ==========================================================
    // 4) Sécurité métier
    // ----------------------------------------------------------
    // booking_room_name doit suivre room.label.
    // Même si le front envoie un nom, ici on verrouille la valeur
    // à celle de la room réellement utilisée ou créée.
    // ==========================================================
    const finalBookingRoomName = room.label;

    // ==========================================================
    // 5) INSERT dans booking_links
    // ----------------------------------------------------------
    // On crée la liaison entre :
    // - la propriété PMS
    // - la room PMS
    // - l'identité Booking Hotel / Booking Room
    //
    // booking_ical_url reste vide pour l’instant car il sera
    // renseigné plus tard dans le bloc 2.
    // ==========================================================
    const bookingLinkRes = await client.query(
      `
      INSERT INTO public.booking_links (
        property_id,
        room_id,
        booking_hotel_id,
        booking_room_id,
        booking_room_name,
        booking_unit_type,
        booking_ical_url,
        is_active
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
      `,
      [
        property.id,
        room.id,
        booking_hotel_id,
        booking_room_id,
        finalBookingRoomName,
        'room',
        '',
        true
      ]
    );

    await client.query('COMMIT');

    return {
      property,
      room,
      booking_link: bookingLinkRes.rows[0]
    };

  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Liste les liens Booking actifs stockés en base.
 *
 * Utilisation :
 * - update.html bloc 2
 * - génération dynamique des champs d’URL iCal
 *
 * On renvoie les rooms triées par booking_room_id
 * pour garder un affichage stable côté frontend.
 */
async function listBookingLinks() {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      SELECT
        id,
        property_id,
        room_id,
        booking_hotel_id,
        booking_room_id,
        booking_room_name,
        booking_ical_url,
        is_active,
        created_at,
        updated_at
      FROM public.booking_links
      WHERE is_active = TRUE
      ORDER BY booking_room_id ASC
      `
    );

    return result.rows;
  } finally {
    client.release();
  }
}

/**
 * Supprime un lien Booking dans public.booking_links
 * à partir de son id primaire.
 */
async function deleteBookingLink(linkId) {
  const client = await pool.connect();

  try {
    const result = await client.query(
      `
      DELETE FROM public.booking_links
      WHERE id = $1
      RETURNING *
      `,
      [linkId]
    );

    return result.rows[0] || null;
  } finally {
    client.release();
  }
}

module.exports = {
  syncPricesToBooking,
  addBookingLink,
  listBookingLinks,
  deleteBookingLink
};