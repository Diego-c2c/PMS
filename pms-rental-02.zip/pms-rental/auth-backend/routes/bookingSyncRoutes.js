const express = require('express');
const { requireManager } = require('../authMiddleware');
const { syncCalendarV1 } = require('../controllers/bookingCalendarController');

// Contrôleurs liés à la synchro Booking et à la gestion des liens booking_links
const {
  syncBookingPrices,
  addBookingLinkCtrl,
  getBookingLinksCtrl,
  deleteBookingLinkCtrl
} = require('../controllers/bookingSyncController');

const router = express.Router();

/*
  ============================================================
  ROUTES BOOKING -> PMS
  ============================================================

  Le préfixe /api/integrations/booking est déjà monté dans server.js.
  Donc ici on déclare uniquement les sous-routes relatives :
  - GET  /links
  - POST /add-link
  - POST /sync-prices
  - POST /sync-calendar-v1
*/

/**
 * Liste les hébergements Booking déjà liés au PMS.
 * Utilisé par update.html pour générer dynamiquement le bloc 2 (URLs iCal).
 */
router.get('/links', requireManager, getBookingLinksCtrl);

/**
 * Ajoute un lien booking_links entre une room Booking et une room PMS.
 * Gère :
 * - existing_room : utilise une room PMS existante
 * - new_room      : crée une nouvelle room PMS avant le lien
 */
router.post('/add-link', requireManager, addBookingLinkCtrl);

/**
 * Route de synchronisation des prix PMS -> Booking.
 * Actuellement branchée sur un service de synchro/stub.
 */
router.post('/sync-prices', requireManager, syncBookingPrices);


/**
 * Route de suppression d'un hebergement dans le Bloc2 
 */
router.delete('/links/:id', requireManager, deleteBookingLinkCtrl);

/**
 * Route V1 de synchronisation calendrier via iCal Booking.
 * Le service télécharge le flux iCal, parse les VEVENT
 * puis envoie les blocs au backend calendrier.
 */
router.post('/sync-calendar-v1', requireManager, syncCalendarV1);

module.exports = router;