/**
 * roomsRoutes.js
 */
const express = require('express');
const { requireManager } = require('../authMiddleware');
const { getRoomsCtrl } = require('../controllers/roomsController');

const router = express.Router();

/**
 * Liste des rooms PMS existantes.
 */
router.get('/', requireManager, getRoomsCtrl);

module.exports = router;