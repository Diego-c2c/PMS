// routes/calendarBlocksRoutes.js
const express = require('express');
const { requireManager } = require('../authMiddleware');
const pool = require('../db');

const router = express.Router();

// Récupérer un bloc par ID
router.get('/:id', requireManager, async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      'SELECT * FROM calendar_blocks WHERE id = $1',
      [id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Bloc calendrier introuvable' });
    }

    return res.json(result.rows[0]);
  } catch (err) {
    console.error('Erreur GET calendar_block:', err);
    return res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Mettre à jour un bloc par ID
router.put('/update/:id', requireManager, async (req, res) => {
  const { id } = req.params;
  const {
    guest_name,
    description,
    check_in,
    check_out,
    price,
    source,
    status,
    room_code,
    units
  } = req.body;

  try {
    const result = await pool.query(
      `UPDATE calendar_blocks
       SET guest_name = $1,
           description = $2,
           date_from = $3,
           date_to = $4,
           price = $5,
           source = $6,
           status = $7,
           room_code = $8,
           units = $9
       WHERE id = $10
       RETURNING *`,
      [
        guest_name || null,
        description || null,
        check_in,
        check_out,
        price || 0,
        source || 'booking',
        status || 'confirmed',
        room_code,
        units || 1,
        id
      ]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Bloc calendrier introuvable' });
    }

    return res.json(result.rows[0]);
  } catch (err) {
    console.error('Erreur UPDATE calendar_block:', err);
    return res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;