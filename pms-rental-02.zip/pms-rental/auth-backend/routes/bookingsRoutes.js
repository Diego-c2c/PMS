const express = require('express');
const router = express.Router();

const pool = require('../db');
const { requireManager } = require('../authMiddleware');
router.delete('/purge', requireManager, async (req, res) => {
  console.log('✅ DELETE /api/bookings/purge appelée');
  try {
    const result = await pool.query('DELETE FROM calendar_blocks');
    return res.json({
      success: true,
      message: 'Toutes les réservations ical ont été supprimées.',
      deletedCount: result.rowCount
    });
  } catch (error) {
    console.error('❌ Erreur purge bookings :', error);
    return res.status(500).json({
      success: false,
      message: 'Erreur serveur lors de la purge des réservations.'
    });
  }
});
/**
 * =========================================================
 * ROUTES BOOKINGS
 * =========================================================
 *
 * Ce fichier regroupe les routes liées aux réservations.
 * On peut y ajouter plus tard :
 * - purge totale
 * - suppression d'une réservation
 * - suppression par période
 * - re-sync iCal
 * - etc.
 */


/**
 * =========================================================
 * DELETE /api/bookings/purge
 * =========================================================
 *
 * Rôle :
 * - supprime toutes les lignes de la table bookings
 *
 * Accès :
 * - manager et admin uniquement
 *
 * Important :
 * - la requête SQL correcte est :
 *     DELETE FROM bookings;
 * - ce n'est PAS :
 *     DELETE * FROM bookings;
 */
router.delete('/purge', requireManager, async (req, res) => {
  try {
    const result = await pool.query('DELETE FROM bookings');

    return res.json({
      success: true,
      message: 'Toutes les réservations ont été supprimées.',
      deletedCount: result.rowCount
    });
  } catch (error) {
    console.error('❌ Erreur purge bookings :', error);

    return res.status(500).json({
      success: false,
      message: 'Erreur serveur lors de la purge des réservations.'
    });
  }
});

module.exports = router;