/**
 * roomsController.js
 */

const { listRooms } = require('../services/roomsService');

/**
 * Renvoie la liste des rooms PMS.
 */
async function getRoomsCtrl(req, res) {
  try {
    const rooms = await listRooms();

    return res.json({
      success: true,
      rooms
    });
  } catch (error) {
    console.error('Erreur getRoomsCtrl:', error);

    return res.status(500).json({
      success: false,
      message: error.message || 'Erreur serveur getRoomsCtrl'
    });
  }
}

module.exports = {
  getRoomsCtrl
};