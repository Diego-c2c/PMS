// controllers/bookingCalendarController.js
const { syncCalendarV1 } = require('../services/bookingCalendarService');

async function syncCalendarV1Ctrl(req, res) {
  console.log('🔵 [SYNC-V1] Requête reçue');
  console.log('🔵 [SYNC-V1] Body:', JSON.stringify(req.body, null, 2));

  try {
    const {
      room_code,
      booking_room_id,
      booking_ical_url,
      booking_hotel_id
    } = req.body || {};

    console.log('🔵 [SYNC-V1] Paramètres:', {
      room_code,
      booking_room_id,
      booking_ical_url,
      booking_hotel_id
    });

    if (!room_code || !booking_room_id || !booking_hotel_id) {
      return res.status(400).json({
        success: false,
        message: 'room_code, booking_room_id et booking_hotel_id sont requis'
      });
    }

    const user = req.session?.user || {};
    console.log('🔵 [SYNC-V1] User:', user);

    const result = await syncCalendarV1({
      room_code,
      booking_room_id,
      booking_ical_url,
      booking_hotel_id,
      user,
      channel: 'Booking',
      status_default: 'undefine'
    });

    console.log('🟢 [SYNC-V1] Résultat service:', result);

    return res.json({
      success: true,
      message: 'Sync calendrier V1 exécutée',
      imported_count: result.imported_count || 0,
      exported_count: result.exported_count || 0,
      synced_at: result.synced_at || null
    });
  } catch (error) {
    console.error('❌ [SYNC-V1] Erreur:', error.message);
    console.error('❌ [SYNC-V1] Stack:', error.stack);

    return res.status(500).json({
      success: false,
      message: error.message || 'Erreur interne sync calendrier V1'
    });
  }
}

module.exports = {
  syncCalendarV1: syncCalendarV1Ctrl
};