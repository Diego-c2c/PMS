// controllers/bookingSyncController.js
// --------------------------------------------------
// Contrôleurs Express pour les fonctionnalités Booking :
// - synchronisation des prix
// - ajout de liens booking_links
// - lecture des liens booking_links pour le frontend
// --------------------------------------------------

const {
  syncPricesToBooking,
  addBookingLink,
  listBookingLinks,
  deleteBookingLink
} = require('../services/bookingSyncService');

/**
 * Contrôleur :
 * reçoit les demandes de synchro prix envoyées par le frontend
 * puis délègue la logique au service métier.
 */
async function syncBookingPrices(req, res) {
  try {
    const payload = req.body || {};

    const result = await syncPricesToBooking(payload, {
      user: req.session?.user
    });

    return res.json({
      success: true,
      message: 'Synchronisation Booking lancée',
      result
    });
  } catch (error) {
    console.error('Erreur sync Booking:', error);

    return res.status(500).json({
      success: false,
      message: error.message || 'Erreur interne de synchronisation Booking'
    });
  }
}

/**
 * Contrôleur :
 * reçoit les données du formulaire bloc 3 de update.html
 * puis délègue toute la logique SQL au service addBookingLink().
 *
 * Cas métier gérés :
 * - existing_room : la room PMS existe déjà
 * - new_room      : il faut créer la room PMS avant de créer booking_links
 */
async function addBookingLinkCtrl(req, res) {
  try {
    const {
      booking_hotel_id,
      booking_room_id,
      room_code,
      booking_room_name,
      color,
      mode
    } = req.body || {};

    // Validation minimale avant appel du service
    if (!booking_hotel_id) {
      return res.status(400).json({ message: 'booking_hotel_id manquant.' });
    }

    if (!booking_room_id) {
      return res.status(400).json({ message: 'booking_room_id manquant.' });
    }

    if (!room_code) {
      return res.status(400).json({ message: 'room_code manquant.' });
    }

    if (!booking_room_name) {
      return res.status(400).json({ message: 'booking_room_name manquant.' });
    }

    if (!mode || !['existing_room', 'new_room'].includes(mode)) {
      return res.status(400).json({ message: 'mode invalide.' });
    }

    const result = await addBookingLink({
      booking_hotel_id,
      booking_room_id,
      room_code,
      booking_room_name,
      color,
      mode
    });

    return res.status(201).json({
      success: true,
      message: 'Lien Booking ajouté avec succès.',
      data: result
    });
  } catch (error) {
    console.error('Erreur addBookingLinkCtrl:', error);

    return res.status(500).json({
      success: false,
      message: error.message || 'Erreur serveur addBookingLinkCtrl'
    });
  }
}

/**
 * Contrôleur :
 * renvoie la liste des liens booking_links actifs.
 *
 * Utilisé par update.html pour construire dynamiquement
 * le bloc 2 "URLs iCal Booking".
 */
async function getBookingLinksCtrl(req, res) {
  try {
    const rows = await listBookingLinks();

    return res.json({
      success: true,
      data: rows
    });
  } catch (error) {
    console.error('Erreur getBookingLinksCtrl:', error);

    return res.status(500).json({
      success: false,
      message: error.message || 'Erreur serveur getBookingLinksCtrl'
    });
  }
}

/**
 * Supprime un booking_link à partir de son id.
 */
async function deleteBookingLinkCtrl(req, res) {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).json({
        success: false,
        message: 'id manquant.'
      });
    }

    const deleted = await deleteBookingLink(id);

    if (!deleted) {
      return res.status(404).json({
        success: false,
        message: 'Lien Booking introuvable.'
      });
    }

    return res.json({
      success: true,
      message: 'Lien Booking supprimé avec succès.',
      data: deleted
    });
  } catch (error) {
    console.error('Erreur deleteBookingLinkCtrl:', error);

    return res.status(500).json({
      success: false,
      message: error.message || 'Erreur serveur deleteBookingLinkCtrl'
    });
  }
}

module.exports = {
  syncBookingPrices,
  addBookingLinkCtrl,
  getBookingLinksCtrl,
  deleteBookingLinkCtrl
};