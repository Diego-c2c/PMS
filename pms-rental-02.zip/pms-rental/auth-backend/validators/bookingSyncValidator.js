function validateBookingSyncPayload(body) {
  const errors = [];

  if (!body || typeof body !== 'object') {
    return { valid: false, errors: ['Body JSON manquant ou invalide'], data: null };
  }

  const property_id = String(body.property_id || '').trim();
  const email = String(body.email || '').trim();
  const password = String(body.password || '');
  const updates = Array.isArray(body.updates) ? body.updates : [];

  if (!property_id) errors.push('property_id requis');
  if (!email) errors.push('email requis');
  if (!password) errors.push('password requis');
  if (!updates.length) errors.push('updates doit contenir au moins une entrée');

  const normalizedUpdates = updates.map((item, index) => {
    const date_from = String(item.date_from || '').trim();
    const date_to = String(item.date_to || '').trim();
    const price = Number(item.price);

    if (!date_from) errors.push(`updates[${index}].date_from requis`);
    if (!date_to) errors.push(`updates[${index}].date_to requis`);
    if (!Number.isFinite(price) || price <= 0) {
      errors.push(`updates[${index}].price doit être > 0`);
    }

    if (date_from && date_to && new Date(date_from) >= new Date(date_to)) {
      errors.push(`updates[${index}] date_to doit être après date_from`);
    }

    return { date_from, date_to, price };
  });

  return {
    valid: errors.length === 0,
    errors,
    data: {
      property_id,
      email,
      password,
      updates: normalizedUpdates
    }
  };
}

module.exports = {
  validateBookingSyncPayload
};