// Charge les variables d'environnement (PORT, SESSION_SECRET, etc.)
require('dotenv').config({ path: '../.env' });

const express = require('express');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const bcrypt = require('bcrypt');
const cors = require('cors');
const path = require('path');
const bookingSyncRoutes = require('./routes/bookingSyncRoutes');
const calendarBlocksRoutes = require('./routes/calendarBlocksRoutes');
const roomsRoutes = require('./routes/roomsRoutes');

// pour toutes les routes liées aux réservations
const bookingsRoutes = require('./routes/bookingsRoutes');

// Connexion PostgreSQL
const pool = require('./db');

// Création des tables auth si besoin
const initAuthTables = require('./initAuthTables');

// Middlewares d'authentification / rôles
const {
  requireAuth,
  requireReadOnly,
  requireManager,
  requireAdmin
} = require('./authMiddleware');

const app = express();
const PORT = Number(process.env.PORT || 8080);
const isProd = process.env.NODE_ENV === 'production';
const FRONTEND_ORIGIN = 'http://localhost:3000';

// Si tu es derrière un proxy (nginx, etc.)
app.set('trust proxy', 1);

// CORS pour autoriser le frontend à appeler l'API avec cookies
app.use(cors({
  origin: FRONTEND_ORIGIN,
  credentials: true
}));

app.options('*', cors({
  origin: FRONTEND_ORIGIN,
  credentials: true
}));

// Parser JSON
app.use(express.json());

// Sessions stockées en base (table user_sessions)
app.use(session({
  store: new pgSession({
    pool,
    tableName: 'user_sessions'
  }),
  name: process.env.SESSION_NAME || 'pms.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProd,       // true en prod avec https
    sameSite: 'lax',
    maxAge: 1000 * 60 * 60 * 24 * 7 // 7 jours
  }
}));



// Servir les fichiers statiques du frontend (index.html, login.html, etc.)
app.use(express.static(path.join(__dirname, '../frontend')));

// les routes définies dans bookingsRoutes.js
app.use('/api/integrations/booking', bookingSyncRoutes);
app.use('/api/bookings', bookingsRoutes);
app.use('/api/calendar-blocks', calendarBlocksRoutes);
app.use('/api/rooms', roomsRoutes);

// Route racine : redirige vers /app ou /login
app.get('/', (req, res) => {
  if (req.session.user) {
    return res.redirect('/app');
  }
  return res.redirect('/login');
});

// Page login
app.get('/login', (req, res) => {
  if (req.session.user) {
    return res.redirect('/app');
  }
  return res.sendFile(path.join(__dirname, '../frontend/login.html'));
});

// Page app principale (protégée)
app.get('/app', requireAuth, (req, res) => {
  return res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Retourne l'utilisateur courant (utilisé par le frontend pour savoir si connecté + rôle)
app.get('/api/auth/me', (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ authenticated: false });
  }

  return res.json({
    authenticated: true,
    user: req.session.user // { id, email, role }
  });
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email et mot de passe requis' });
    }

    const result = await pool.query(
      'SELECT id, email, password_hash, role FROM users WHERE email = $1',
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Identifiants invalides' });
    }

    const user = result.rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);

    if (!ok) {
      return res.status(401).json({ error: 'Identifiants invalides' });
    }

    // On stocke les infos utiles dans la session
    req.session.user = {
      id: user.id,
      email: user.email,
      role: user.role
    };

    return res.json({
      success: true,
      user: req.session.user
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Logout
app.post('/api/auth/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Erreur logout' });
    }

    res.clearCookie(process.env.SESSION_NAME || 'pms.sid');
    return res.json({ success: true });
  });
});

/* ========= ZONE ROLES / ADMIN ========= */

// Admin : changer le rôle d’un utilisateur
app.put('/api/admin/users/:id/role', requireAdmin, async (req, res) => {
  const userId = req.params.id;
  const { role } = req.body; // 'user' | 'manager' | 'admin'

  if (!['user', 'manager', 'admin'].includes(role)) {
    return res.status(400).json({ error: 'Rôle invalide' });
  }

  try {
    const result = await pool.query(
      'UPDATE users SET role = $1 WHERE id = $2 RETURNING id, email, role',
      [role, userId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Utilisateur introuvable' });
    }

    res.json({ user: result.rows[0] });
  } catch (err) {
    console.error('Erreur update role:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Lecture seule : accessible à user, manager, admin
app.get('/api/user/profile', requireReadOnly, (req, res) => {
  return res.json({
    message: 'Lecture autorisée',
    role: req.session.user.role,
    user: req.session.user
  });
});

// Manager ou admin : exemple de route protégée manager+
app.get('/api/manager/test', requireManager, (req, res) => {
  return res.json({
    message: 'Accès manager autorisé',
    role: req.session.user.role
  });
});

// Admin uniquement : liste des utilisateurs pour la page admin-users.html
app.get('/api/admin/users', requireAdmin, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, email, role, created_at FROM users ORDER BY id ASC'
    );
    res.json({ users: result.rows });
  } catch (err) {
    console.error('Erreur list users:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Admin : créer un utilisateur
app.post('/api/admin/users', requireAdmin, async (req, res) => {
  const { email, password, role } = req.body;

  if (!email || !password || !role) {
    return res.status(400).json({ error: 'Email, mot de passe et rôle requis' });
  }

  if (!['user', 'manager', 'admin'].includes(role)) {
    return res.status(400).json({ error: 'Rôle invalide' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Mot de passe trop court (minimum 6 caractères)' });
  }

  try {
    const existing = await pool.query(
      'SELECT id FROM users WHERE email = $1',
      [email]
    );

    if (existing.rowCount > 0) {
      return res.status(409).json({ error: 'Cet email existe déjà' });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const result = await pool.query(
      `INSERT INTO users (email, password_hash, role)
       VALUES ($1, $2, $3)
       RETURNING id, email, role`,
      [email, passwordHash, role]
    );

    return res.status(201).json({ user: result.rows[0] });
  } catch (err) {
    console.error('Erreur create user:', err);
    return res.status(500).json({ error: 'Erreur serveur' });
  }
});


// Admin : supprimer un utilisateur (sauf admin)
app.delete('/api/admin/users/:id', requireAdmin, async (req, res) => {
  const userId = req.params.id;

  try {
    const existing = await pool.query(
      'SELECT id, email, role FROM users WHERE id = $1',
      [userId]
    );

    if (existing.rowCount === 0) {
      return res.status(404).json({ error: 'Utilisateur introuvable' });
    }

    const userToDelete = existing.rows[0];

    if (userToDelete.role === 'admin') {
      return res.status(403).json({ error: 'Suppression d’un admin interdite' });
    }

    await pool.query('DELETE FROM users WHERE id = $1', [userId]);

    return res.json({
      success: true,
      deletedUser: {
        id: userToDelete.id,
        email: userToDelete.email,
        role: userToDelete.role
      }
    });
  } catch (err) {
    console.error('Erreur delete user:', err);
    return res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Admin : changer le mot de passe d'un utilisateur
app.put('/api/admin/users/:id/password', requireAdmin, async (req, res) => {
  const userId = req.params.id;
  const { password } = req.body;

  if (!password || password.length < 6) {
    return res.status(400).json({ error: 'Mot de passe invalide (minimum 6 caractères)' });
  }

  try {
    const existing = await pool.query(
      'SELECT id, email, role FROM users WHERE id = $1',
      [userId]
    );

    if (existing.rowCount === 0) {
      return res.status(404).json({ error: 'Utilisateur introuvable' });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    await pool.query(
      'UPDATE users SET password_hash = $1 WHERE id = $2',
      [passwordHash, userId]
    );

    return res.json({
      success: true,
      user: {
        id: existing.rows[0].id,
        email: existing.rows[0].email,
        role: existing.rows[0].role
      }
    });
  } catch (err) {
    console.error('Erreur change password:', err);
    return res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Route test générique protégée (auth simple)
app.get('/api/protected', requireAuth, (req, res) => {
  return res.json({
    ok: true,
    user: req.session.user
  });
});

/* ========= DEMARRAGE DU SERVEUR ========= */

initAuthTables()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Auth backend lancé sur http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Erreur init:', err);
    process.exit(1);
  });