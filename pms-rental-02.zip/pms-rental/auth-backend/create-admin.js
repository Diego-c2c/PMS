﻿const bcrypt = require("bcrypt");
const { Pool } = require("pg");

(async () => {
  const pool = new Pool({
    host: "db",
    port: 5432,
    user: "pms_user",
    password: "pms_password",
    database: "pms_db"
  });

  const email = "admin@admin";
  const passwordHash = await bcrypt.hash("admin", 12);

  await pool.query(
    "INSERT INTO users (email, password_hash, role) VALUES ($1, $2, 'admin') " +
    "ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, role = 'admin'",
    [email, passwordHash]
  );

  console.log("admin created/updated:", email);
  await pool.end();
  process.exit(0);
})().catch(err => {
  console.error(err);
  process.exit(1);
});
