# PMS – Property Management System
## Version 1.1 (Mars 2026)

## ✅ Status: PHASE 1 COMPLETE, LOCAL TESTING

### Qu'est-ce que c'est?
Système centralisé pour gérer les réservations Airbnb + Booking en un seul endroit.

### Features V1.1 (complètes)
- ✅ Calendrier unifié (Airbnb + Booking)
- ✅ Parser iCal automatique
- ✅ Scheduler (import toutes les heures)
- ✅ API REST Go
- ✅ Frontend HTML/JS
- ✅ Docker Compose (local)

### Fonctionnalités manquantes (V2)
- [ ] UI: ajouter/supprimer réservations
- [ ] UI: bloquer des dates
- [ ] Gestion des prix dynamiques
- [ ] Automation Extranet (Playwright)
- [ ] Déploiement VPS

---

## 🚀 Comment lancer

### Prérequis
- Docker Desktop installé
- Go 1.23 (optionnel, juste pour local dev)
- Git

### Lancer en local
```bash
cd pms-rental
docker-compose up --build
