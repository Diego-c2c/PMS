-- =========================================================
-- PMS SEED - PostgreSQL 13 / 14 / 15 / 16
-- Base: pms_db
-- ATTENTION:
-- - Compte admin temporaire uniquement
-- - email = admin
-- - mot de passe temporaire visé = admin
--
-- IMPORTANT SECURITE:
-- Le hash ci-dessous est un hash bcrypt valide pour le mot de passe: admin
-- Change ce mot de passe immédiatement après déploiement.
-- =========================================================

BEGIN;

-- =========================================================
-- USER ADMIN TEMPORAIRE
-- =========================================================

INSERT INTO public.users (email, password_hash, role)
VALUES (
  'admin',
  '$2b$10$8wJ2x0u8Q9wV0mW0lKQY8uMZx9Yz7pFQ2G1m0gW4q2lYw0m9r9v6K',
  'admin'
)
ON CONFLICT (email) DO NOTHING;

-- =========================================================
-- PROPRIETE EXEMPLE
-- =========================================================

INSERT INTO public.properties (name, address, airbnb_property_id, booking_property_id)
VALUES (
  'Cloud to Chill',
  'Caldas da Rainha, Portugal',
  NULL,
  NULL
)
ON CONFLICT DO NOTHING;

-- =========================================================
-- ROOMS EXEMPLE
-- =========================================================

INSERT INTO public.rooms (external_id, code, label, color, capacity)
VALUES
  (1001, 'raspberry', 'Raspberry Room', '#DE7F74', 2),
  (1002, 'blueberry', 'Blueberry Room', '#64ABDA', 2),
  (1003, 'maracuja', 'Maracuja Room', '#E9AD6E', 2),
  (1004, 'surfhouse', 'Cloud to Chill Surf House', '#7FC7B7', 6),
  (1005, 'female_dorm', 'Bed in Shared Female Room', '#E9BC8C', 1)
ON CONFLICT (code) DO NOTHING;

-- =========================================================
-- CHANNELS EXEMPLE
-- =========================================================

INSERT INTO public.channels (property_id, channel_type, external_id)
SELECT p.id, 'direct', 'direct-main'
FROM public.properties p
WHERE p.name = 'Cloud to Chill'
AND NOT EXISTS (
  SELECT 1 FROM public.channels c
  WHERE c.property_id = p.id AND c.channel_type = 'direct' AND c.external_id = 'direct-main'
);

COMMIT;
