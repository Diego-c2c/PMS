http://localhost:8081/api/integrations/booking/sync-calendar-v1

DELETE FROM calendar_blocks
WHERE property_id = 5207416;

pms_db=# \dt
              List of relations
 Schema |      Name       | Type  |  Owner
--------+-----------------+-------+----------
 public | booking_links   | table | pms_user
 public | bookings        | table | pms_user
 public | calendar_blocks | table | pms_user // table des imports dans calendar-view
 public | channels        | table | pms_user
 public | ical_imports    | table | pms_user // import Ical
 public | pricing         | table | pms_user
 public | properties      | table | pms_user
 public | rooms           | table | pms_user
 public | user_sessions   | table | pms_user
 public | users           | table | pms_user
(10 rows)

pms_db=# \d booking_links
                                               Table "public.booking_links"
         Column          |            Type             | Collation | Nullable |                  Default
-------------------------+-----------------------------+-----------+----------+-------------------------------------------
 id                      | integer                     |           | not null | nextval('booking_links_id_seq'::regclass)
 property_id             | integer                     |           | not null |
 room_id                 | integer                     |           |          |
 booking_hotel_id        | character varying(100)      |           | not null |
 booking_room_id         | character varying(100)      |           | not null |
 booking_room_name       | character varying(255)      |           |          |
 booking_unit_type       | character varying(50)       |           |          |
 display_order           | integer                     |           |          | 0
 booking_ical_url        | text                        |           | not null |
 booking_ical_export_url | text                        |           |          |
 is_active               | boolean                     |           | not null | true
 last_ical_sync_at       | timestamp without time zone |           |          |
 last_ical_sync_status   | character varying(50)       |           |          |
 last_ical_sync_error    | text                        |           |          |
 booking_rate_plan_id    | character varying(100)      |           |          |
 last_api_sync_at        | timestamp without time zone |           |          |
 last_api_sync_status    | character varying(50)       |           |          |
 last_api_sync_error     | text                        |           |          |
 metadata                | jsonb                       |           |          |
 created_at              | timestamp without time zone |           | not null | CURRENT_TIMESTAMP
 updated_at              | timestamp without time zone |           | not null | CURRENT_TIMESTAMP
Indexes:
    "booking_links_pkey" PRIMARY KEY, btree (id)
    "idx_booking_links_active" btree (is_active)
    "idx_booking_links_booking_hotel_id" btree (booking_hotel_id)
    "idx_booking_links_property_active" btree (property_id, is_active)
    "idx_booking_links_property_id" btree (property_id)
    "idx_booking_links_room_id" btree (room_id)
    "uq_booking_links_hotel_room" UNIQUE CONSTRAINT, btree (booking_hotel_id, booking_room_id)
    "uq_booking_links_room" UNIQUE CONSTRAINT, btree (booking_room_id)
Foreign-key constraints:
    "booking_links_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
Triggers:
    trg_booking_links_updated_at BEFORE UPDATE ON booking_links FOR EACH ROW EXECUTE FUNCTION set_updated_at()

pms_db=# \d bookings
                                             Table "public.bookings"
       Column        |            Type             | Collation | Nullable |               Default
---------------------+-----------------------------+-----------+----------+--------------------------------------
 id                  | integer                     |           | not null | nextval('bookings_id_seq'::regclass)
 property_id         | integer                     |           | not null |
 channel_id          | integer                     |           |          |
 external_booking_id | character varying(100)      |           |          |
 guest_name          | character varying(255)      |           |          |
 check_in            | date                        |           | not null |
 check_out           | date                        |           | not null |
 price               | numeric(10,2)               |           |          |
 status              | character varying(50)       |           |          |
 source              | character varying(50)       |           |          |
 last_synced         | timestamp without time zone |           |          |
 created_at          | timestamp without time zone |           |          | CURRENT_TIMESTAMP
 room_code           | character varying(50)       |           |          |
 units               | integer                     |           | not null | 1
 description         | character varying(300)      |           |          |
Indexes:
    "bookings_pkey" PRIMARY KEY, btree (id)
    "idx_bookings_dates" btree (check_in, check_out)
    "idx_bookings_property" btree (property_id)
Foreign-key constraints:
    "bookings_channel_id_fkey" FOREIGN KEY (channel_id) REFERENCES channels(id)
    "bookings_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)

pms_db=# \d calendar_blocks
                                         Table "public.calendar_blocks"
   Column    |            Type             | Collation | Nullable |                   Default
-------------+-----------------------------+-----------+----------+---------------------------------------------
 id          | integer                     |           | not null | nextval('calendar_blocks_id_seq'::regclass)
 property_id | integer                     |           | not null |
 date_from   | date                        |           | not null |
 date_to     | date                        |           | not null |
 block_type  | character varying(50)       |           |          |
 reason      | text                        |           |          |
 created_at  | timestamp without time zone |           |          | CURRENT_TIMESTAMP
 room_code   | character varying(50)       |           |          |
Indexes:
    "calendar_blocks_pkey" PRIMARY KEY, btree (id)
    "idx_calendar_blocks_property" btree (property_id)
    "idx_calendar_blocks_property_date" btree (property_id, date_from, date_to)
    "idx_calendar_blocks_property_room_date" btree (property_id, room_code, date_from, date_to)
Foreign-key constraints:
    "calendar_blocks_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)

pms_db=# \d channels
                                         Table "public.channels"
    Column    |            Type             | Collation | Nullable |               Default
--------------+-----------------------------+-----------+----------+--------------------------------------
 id           | integer                     |           | not null | nextval('channels_id_seq'::regclass)
 property_id  | integer                     |           | not null |
 channel_type | character varying(50)       |           |          |
 external_id  | character varying(100)      |           |          |
 created_at   | timestamp without time zone |           |          | CURRENT_TIMESTAMP
Indexes:
    "channels_pkey" PRIMARY KEY, btree (id)
Foreign-key constraints:
    "channels_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)
Referenced by:
    TABLE "bookings" CONSTRAINT "bookings_channel_id_fkey" FOREIGN KEY (channel_id) REFERENCES channels(id)
    TABLE "ical_imports" CONSTRAINT "ical_imports_channel_id_fkey" FOREIGN KEY (channel_id) REFERENCES channels(id)

pms_db=# \d ical_imports
                                          Table "public.ical_imports"
    Column     |            Type             | Collation | Nullable |                 Default
---------------+-----------------------------+-----------+----------+------------------------------------------
 id            | integer                     |           | not null | nextval('ical_imports_id_seq'::regclass)
 property_id   | integer                     |           | not null |
 channel_id    | integer                     |           |          |
 ical_url      | character varying(500)      |           |          |
 last_fetched  | timestamp without time zone |           |          |
 last_modified | timestamp without time zone |           |          |
 etag          | character varying(256)      |           |          |
 created_at    | timestamp without time zone |           |          | CURRENT_TIMESTAMP
Indexes:
    "ical_imports_pkey" PRIMARY KEY, btree (id)
    "idx_ical_imports_property" btree (property_id)
Foreign-key constraints:
    "ical_imports_channel_id_fkey" FOREIGN KEY (channel_id) REFERENCES channels(id)
    "ical_imports_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)

pms_db=# \d pricing
                                         Table "public.pricing"
    Column    |            Type             | Collation | Nullable |               Default
--------------+-----------------------------+-----------+----------+-------------------------------------
 id           | integer                     |           | not null | nextval('pricing_id_seq'::regclass)
 property_id  | integer                     |           | not null |
 date         | date                        |           | not null |
 price        | numeric(10,2)               |           |          |
 rule_applied | character varying(100)      |           |          |
 created_at   | timestamp without time zone |           |          | CURRENT_TIMESTAMP
Indexes:
    "pricing_pkey" PRIMARY KEY, btree (id)
    "idx_pricing_property_date" btree (property_id, date)
    "pricing_property_id_date_key" UNIQUE CONSTRAINT, btree (property_id, date)
Foreign-key constraints:
    "pricing_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)

pms_db=# \d properties
                                             Table "public.properties"
       Column        |            Type             | Collation | Nullable |                Default
---------------------+-----------------------------+-----------+----------+----------------------------------------
 id                  | integer                     |           | not null | nextval('properties_id_seq'::regclass)
 name                | character varying(255)      |           | not null |
 address             | text                        |           |          |
 airbnb_property_id  | character varying(100)      |           |          |
 booking_property_id | character varying(100)      |           |          |
 created_at          | timestamp without time zone |           |          | CURRENT_TIMESTAMP
Indexes:
    "properties_pkey" PRIMARY KEY, btree (id)
Referenced by:
    TABLE "booking_links" CONSTRAINT "booking_links_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
    TABLE "bookings" CONSTRAINT "bookings_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)
    TABLE "calendar_blocks" CONSTRAINT "calendar_blocks_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)
    TABLE "channels" CONSTRAINT "channels_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)
    TABLE "ical_imports" CONSTRAINT "ical_imports_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)
    TABLE "pricing" CONSTRAINT "pricing_property_id_fkey" FOREIGN KEY (property_id) REFERENCES properties(id)

pms_db=# \d rooms
                                      Table "public.rooms"
   Column    |          Type          | Collation | Nullable |              Default
-------------+------------------------+-----------+----------+-----------------------------------
 id          | integer                |           | not null | nextval('rooms_id_seq'::regclass)
 external_id | bigint                 |           | not null |
 code        | character varying(50)  |           | not null |
 label       | character varying(255) |           | not null |
 color       | character varying(7)   |           | not null |
 capacity    | integer                |           | not null |
Indexes:
    "rooms_pkey" PRIMARY KEY, btree (id)
    "idx_rooms_code" UNIQUE, btree (code)
    "idx_rooms_external_id" UNIQUE, btree (external_id)

pms_db=# \d user_sessions
                       Table "public.user_sessions"
 Column |              Type              | Collation | Nullable | Default
--------+--------------------------------+-----------+----------+---------
 sid    | character varying              |           | not null |
 sess   | json                           |           | not null |
 expire | timestamp(6) without time zone |           | not null |
Indexes:
    "user_sessions_pkey" PRIMARY KEY, btree (sid)
    "idx_user_sessions_expire" btree (expire)

pms_db=# \d users
                                          Table "public.users"
    Column     |            Type             | Collation | Nullable |              Default
---------------+-----------------------------+-----------+----------+-----------------------------------
 id            | integer                     |           | not null | nextval('users_id_seq'::regclass)
 email         | character varying(255)      |           | not null |
 password_hash | text                        |           | not null |
 role          | character varying(50)       |           | not null | 'admin'::character varying
 created_at    | timestamp without time zone |           | not null | now()
Indexes:
    "users_pkey" PRIMARY KEY, btree (id)
    "users_email_key" UNIQUE CONSTRAINT, btree (email)

pms_db=#


SELECT * FROM calendar_blocks ORDER BY id LIMIT 50;
DELETE FROM calendar_blocks WHERE property_id = 1 RETURNING id, ical_url;
DELETE * FROM bookings;

\d booking_links

\d bookings

\d calendar_blocks

\d channels

\d ical_imports

\d pricing

\d properties

\d rooms

\d user_sessions

\d users