package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"pms-backend/handlers"
	"pms-backend/services"
	"sort"
	"strconv"
	"strings"
	"time"

	_ "github.com/lib/pq"
)

// Connexion DB globale utilisée par certains handlers simples
var db *sql.DB

// Booking = structure simple exposée côté /api/calendar
type Booking struct {
	CheckIn     string `json:"check_in"`
	CheckOut    string `json:"check_out"`
	GuestName   string `json:"guest"`
	Description string `json:"description"`
	Source      string `json:"source"`
	Status      string `json:"status"`
}

// CalendarEvent = format unifié renvoyé à calendar-view.js
type CalendarEvent struct {
	ID          int     `json:"id"`
	CheckIn     string  `json:"check_in"`
	CheckOut    string  `json:"check_out"`
	Guest       string  `json:"guest"`
	GuestName   string  `json:"guest_name"`
	Description string  `json:"description"`
	Source      string  `json:"source"`
	Status      string  `json:"status"`
	RoomCode    string  `json:"room_code"`
	Units       int     `json:"units"`
	Price       float64 `json:"price"`
	EventType   string  `json:"event_type"`
	EntityType  string  `json:"entityType"`
}

type CalendarBlockPayload struct {
	GuestName   string  `json:"guest_name"`
	Description string  `json:"description"`
	CheckIn     string  `json:"check_in"`
	CheckOut    string  `json:"check_out"`
	Price       float64 `json:"price"`
	Units       int     `json:"units"`
	Source      string  `json:"source"`
	Status      string  `json:"status"`
	RoomCode    string  `json:"room_code"`
}

// Interval représente un intervalle de dates [Start, End) en Go
type Interval struct {
	Start time.Time
	End   time.Time
}

// computeFreeRanges prend une période iCal (baseStart, baseEnd)
// et une liste de bookings réels existants (blocks) qui CHEVAUCHENT déjà cette période,
// et renvoie une liste d'intervalles restants qui NE sont couverts par AUCUN booking réel.
//
// Exemple : base = [10, 25)
//
//	bookings existants : [10,17) et [20,22)
//	free = [17,20) et [22,25)
func computeFreeRanges(baseStart, baseEnd time.Time, blocks []Interval) []Interval {
	// Si aucun booking réel, la totalité de la période iCal est libre
	if len(blocks) == 0 {
		return []Interval{{Start: baseStart, End: baseEnd}}
	}

	// Trier les blocks existants par date de début (important pour l'algo)
	sort.Slice(blocks, func(i, j int) bool {
		return blocks[i].Start.Before(blocks[j].Start)
	})

	free := []Interval{}
	current := baseStart

	for _, b := range blocks {
		// Si ce booking réel est complètement avant la période actuelle, on ignore
		if !b.End.After(current) {
			continue
		}

		// Si ce booking réel commence après "current", alors la zone [current, b.Start)
		// représente un trou libre à bloquer techniquement.
		if b.Start.After(current) {
			// Le trou ne doit pas dépasser baseEnd
			gapEnd := b.Start
			if gapEnd.After(baseEnd) {
				gapEnd = baseEnd
			}
			// Si le trou est encore dans la période de base
			if gapEnd.After(current) {
				free = append(free, Interval{Start: current, End: gapEnd})
			}
		}

		// Avancer "current" au max entre sa valeur actuelle et b.End
		if b.End.After(current) {
			current = b.End
		}

		// Si on a déjà dépassé la fin de la période iCal, on sort
		if !current.Before(baseEnd) {
			break
		}
	}

	// À la fin, s'il reste un bout [current, baseEnd) non couvert, on l'ajoute
	if current.Before(baseEnd) {
		free = append(free, Interval{Start: current, End: baseEnd})
	}

	return free
}

// init initialise la connexion PostgreSQL au démarrage
func init() {
	var err error

	dsn := fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		os.Getenv("DB_HOST"),
		os.Getenv("DB_PORT"),
		os.Getenv("DB_USER"),
		os.Getenv("DB_PASSWORD"),
		os.Getenv("DB_NAME"),
	)

	db, err = sql.Open("postgres", dsn)
	if err != nil {
		log.Fatal("DB connection failed:", err)
	}

	if err := db.Ping(); err != nil {
		log.Fatal("DB ping failed:", err)
	}

	log.Println("✓ Connected to PostgreSQL")
}

// Middleware CORS simple

func corsMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		origin := r.Header.Get("Origin")

		if origin == "http://localhost:3000" {
			w.Header().Set("Access-Control-Allow-Origin", origin)
			w.Header().Set("Access-Control-Allow-Credentials", "true")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
			w.Header().Set("Vary", "Origin")
		}

		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}

		next(w, r)
	}
}

func main() {
	defer db.Close()

	// Scheduler iCal existant
	scheduler := services.NewICalScheduler(db)
	if err := scheduler.Start(); err != nil {
		log.Printf("Warning: could not start scheduler: %v\n", err)
	}
	defer scheduler.Stop()

	// Service métier principal
	bookingSvc := services.NewBookingService(db)

	// ============================================
	// HEALTH CHECK
	// ============================================
	http.HandleFunc("/health", corsMiddleware(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		fmt.Fprintf(w, `{"status":"ok"}`)
	}))

	// ============================================
	// IMPORT ICAL HISTORIQUE
	// ============================================
	http.HandleFunc("/api/ical/import", corsMiddleware(handlers.HandleICalImport(db)))

	// ============================================
	// BOOKINGS CRUD
	// ============================================
	http.HandleFunc("/api/bookings", corsMiddleware(handlers.HandleGetBookings(bookingSvc)))
	http.HandleFunc("/api/bookings/create", corsMiddleware(handlers.HandleCreateBooking(bookingSvc)))
	http.HandleFunc("/api/bookings/update/", corsMiddleware(handlers.HandleUpdateBooking(bookingSvc)))
	http.HandleFunc("/api/bookings/delete/", corsMiddleware(handlers.HandleDeleteBooking(bookingSvc)))
	http.HandleFunc("/api/bookings/", corsMiddleware(handlers.HandleGetBooking(bookingSvc)))

	// ============================================
	// CALENDAR BLOCKS - CREATE MANUEL
	// ============================================
	http.HandleFunc("/api/calendar-blocks", corsMiddleware(handlers.HandleCreateBlock(bookingSvc)))

	// ============================================
	// SYNC FROM ICAL (V1)
	// Reçoit les événements parsés par Node.js
	// et les écrit dans calendar_blocks.
	//
	// POST /api/calendar-blocks/sync-from-ical
	//
	// Body attendu :
	// {
	//   "room_code": "520741601",
	//   "property_id": 1,
	//   "channel": "Booking",
	//   "status_default": "undefine",
	//   "bookings": [
	//     {
	//       "check_in": "2026-04-03",
	//       "check_out": "2026-04-16",
	//       "description": "CLOSED - Not available",
	//       "source": "booking",
	//       "guest_name": "",
	//       "price": 0,
	//       "type": "block"
	//     }
	//   ]
	// }
	// ============================================
	http.HandleFunc("/api/calendar-blocks/sync-from-ical", corsMiddleware(func(w http.ResponseWriter, r *http.Request) {
		// --------------------------------------------------
		// 0) Autoriser uniquement la méthode POST
		// --------------------------------------------------
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		// --------------------------------------------------
		// 1) Structures attendues dans le JSON reçu
		// --------------------------------------------------
		type SyncEvent struct {
			CheckIn     string `json:"check_in"`
			CheckOut    string `json:"check_out"`
			Description string `json:"description"`
			Source      string `json:"source"`
			GuestName   string `json:"guest_name"`
			Price       int    `json:"price"`
			Type        string `json:"type"`
		}

		type SyncRequest struct {
			RoomCode      string      `json:"room_code"`
			PropertyID    int         `json:"property_id"`
			Channel       string      `json:"channel"`
			StatusDefault string      `json:"status_default"`
			Bookings      []SyncEvent `json:"bookings"`
		}

		// --------------------------------------------------
		// 2) Lire le body JSON
		// --------------------------------------------------
		var req SyncRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "Invalid JSON body",
			})
			return
		}

		// --------------------------------------------------
		// 3) Vérifications de base
		// --------------------------------------------------
		if req.PropertyID == 0 || len(req.Bookings) == 0 {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "property_id et bookings sont requis",
			})
			return
		}

		if req.RoomCode == "" {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "room_code est requis",
			})
			return
		}

		// --------------------------------------------------
		// 4) Supprimer les anciens blocks iCal de cette room
		// avant de réimporter proprement
		// --------------------------------------------------
		_, err := db.Exec(`
        DELETE FROM calendar_blocks
        WHERE property_id = $1
          AND room_code = $2
    `, req.PropertyID, req.RoomCode)
		if err != nil {
			log.Printf("Erreur suppression calendar_blocks room=%s property=%d: %v\n", req.RoomCode, req.PropertyID, err)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "Erreur suppression anciens blocs",
			})
			return
		}

		// Supprimer aussi les anciens bookings techniques iCal de cette room
		_, err = db.Exec(`
			DELETE FROM bookings
			WHERE property_id = $1
			AND room_code = $2
			AND source = 'Icalbook'
		`, req.PropertyID, req.RoomCode)
		if err != nil {
			log.Printf("Erreur suppression bookings techniques room=%s property=%d: %v\n", req.RoomCode, req.PropertyID, err)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]interface{}{
				"success": false,
				"error":   "Erreur suppression anciens bookings techniques",
			})
			return
		}

		// --------------------------------------------------
		// 5) Compteurs
		// insertedCount = nb de blocks insérés dans calendar_blocks
		// insertedBookingsCount = nb de lignes créées dans bookings
		// --------------------------------------------------
		insertedCount := 0
		insertedBookingsCount := 0

		// --------------------------------------------------
		// 6) Parcourir chaque événement iCal reçu
		// --------------------------------------------------
		for _, b := range req.Bookings {
			// On ne traite que les éléments de type "block"
			if b.Type != "block" {
				continue
			}

			// --------------------------------------------------
			// 6.1) Parser les dates
			// --------------------------------------------------
			checkIn, err := time.Parse("2006-01-02", b.CheckIn)
			if err != nil {
				log.Printf("check_in invalide: %s — %v\n", b.CheckIn, err)
				continue
			}

			checkOut, err := time.Parse("2006-01-02", b.CheckOut)
			if err != nil {
				log.Printf("check_out invalide: %s — %v\n", b.CheckOut, err)
				continue
			}

			// La date de sortie doit être strictement après la date d’entrée
			if !checkOut.After(checkIn) {
				log.Printf("Période invalide room=%s: %s -> %s\n", req.RoomCode, b.CheckIn, b.CheckOut)
				continue
			}

			// --------------------------------------------------
			// 6.2) Préparer le block à insérer
			// --------------------------------------------------
			blockType := "closed"

			reason := b.Description
			if reason == "" {
				reason = "Import iCal"
			}

			// --------------------------------------------------
			// 6.3) Insérer la période dans calendar_blocks
			// --------------------------------------------------
			_, err = db.Exec(`
            INSERT INTO calendar_blocks (
                property_id,
                room_code,
                date_from,
                date_to,
                block_type,
                reason
            )
            VALUES ($1, $2, $3, $4, $5, $6)
        `,
				req.PropertyID,
				req.RoomCode,
				checkIn,
				checkOut,
				blockType,
				reason,
			)
			if err != nil {
				log.Printf("Erreur insertion calendar_blocks room=%s property=%d: %v\n", req.RoomCode, req.PropertyID, err)
				continue
			}

			log.Printf("Block inséré: room=%s %s -> %s (%s) property=%d\n", req.RoomCode, b.CheckIn, b.CheckOut, reason, req.PropertyID)
			insertedCount++

			// --------------------------------------------------
			// --------------------------------------------------
			// 6.4) Récupérer tous les bookings RÉELS qui
			// chevauchent cette période pour cette room.
			// On exclut les sources iCal (booking_ical, airbnb_ical, etc.)
			// pour ne travailler qu'avec les réservations "réelles".
			// --------------------------------------------------
			rows, err := db.Query(`
				SELECT check_in, check_out
				FROM bookings
				WHERE property_id = $1
				AND room_code = $2
				AND (check_in, check_out) OVERLAPS ($3::date, $4::date)
				AND COALESCE(source, '') NOT IN ('booking_ical', 'airbnb_ical', 'ical_import', 'Icalbook')
			`, req.PropertyID, req.RoomCode, checkIn, checkOut)
			if err != nil {
				log.Printf("Erreur récupération bookings existants room=%s property=%d: %v\n",
					req.RoomCode, req.PropertyID, err)
				continue
			}

			existing := []Interval{}
			for rows.Next() {
				var bi, bo time.Time
				if err := rows.Scan(&bi, &bo); err != nil {
					log.Printf("Erreur scan bookings existants room=%s property=%d: %v\n",
						req.RoomCode, req.PropertyID, err)
					continue
				}
				existing = append(existing, Interval{Start: bi, End: bo})
			}
			if err := rows.Err(); err != nil {
				log.Printf("Erreur rows bookings existants room=%s property=%d: %v\n",
					req.RoomCode, req.PropertyID, err)
				continue
			}
			defer rows.Close()

			// --------------------------------------------------
			// 6.5) Calculer les sous-intervalles de la période iCal
			// qui ne sont couverts par AUCUN booking réel.
			// --------------------------------------------------
			freeRanges := computeFreeRanges(checkIn, checkOut, existing)

			// S'il n'y a aucun trou, rien à insérer dans bookings.
			if len(freeRanges) == 0 {
				log.Printf("Aucun tronçon libre à bloquer dans bookings pour room=%s property=%d %s->%s\n",
					req.RoomCode,
					req.PropertyID,
					b.CheckIn,
					b.CheckOut,
				)
				continue
			}

			// --------------------------------------------------
			// 6.6) Pour chaque tronçon libre, créer un booking
			// technique dans la table bookings.
			// --------------------------------------------------
			for _, fr := range freeRanges {
				externalBookingID := fmt.Sprintf(
					"ical-%d-%s-%s-%s",
					req.PropertyID,
					req.RoomCode,
					fr.Start.Format("20060102"),
					fr.End.Format("20060102"),
				)

				guestName := b.GuestName
				if guestName == "" {
					guestName = "iCal import"
				}
				// si je veux recuperé la source au lieu de forcer
				source := "Icalbook" //b.Source
				//if source == "" {
				//	source = "booking_ical"
				//}

				description := b.Description
				if description == "" {
					description = "Import iCal"
				}

				_, err = db.Exec(`
					INSERT INTO bookings (
						property_id,
						external_booking_id,
						guest_name,
						check_in,
						check_out,
						price,
						status,
						source,
						last_synced,
						room_code,
						units,
						description
					)
					VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), $9, $10, $11)
				`,
					req.PropertyID,
					externalBookingID,
					guestName,
					fr.Start,
					fr.End,
					b.Price,
					"blocked",
					source,
					req.RoomCode,
					1,
					description,
				)
				if err != nil {
					log.Printf("ERROR insertion bookings FAILED room=%s property=%d %s->%s external_booking_id=%s err=%v\n",
						req.RoomCode,
						req.PropertyID,
						fr.Start.Format("2006-01-02"),
						fr.End.Format("2006-01-02"),
						externalBookingID,
						err,
					)
					continue
				}

				log.Printf("Booking technique iCal inséré: room=%s property=%d %s->%s external_booking_id=%s\n",
					req.RoomCode,
					req.PropertyID,
					fr.Start.Format("2006-01-02"),
					fr.End.Format("2006-01-02"),
					externalBookingID,
				)
				insertedBookingsCount++
			}
		}

		// --------------------------------------------------
		// 7) Réponse JSON finale
		// --------------------------------------------------
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success":                 true,
			"inserted_count":          insertedCount,
			"inserted_bookings_count": insertedBookingsCount,
			"property_id":             req.PropertyID,
			"channel":                 req.Channel,
			"room_code":               req.RoomCode,
		})
	}))

	// ============================================
	// PRICING
	// ============================================
	http.HandleFunc("/api/pricing/sync", corsMiddleware(handlers.HandleSyncPrices(bookingSvc)))
	http.HandleFunc("/api/pricing/current", corsMiddleware(handlers.HandleGetPrices(bookingSvc)))

	// ============================================
	// CALENDRIER UNIFIÉ
	// Renvoie bookings + calendar_blocks
	// dans un seul tableau JSON compatible avec calendar-view.js
	// ============================================
	http.HandleFunc("/api/calendar", corsMiddleware(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		propertyID := 1
		events := make([]CalendarEvent, 0)

		// 1. Charger les réservations
		bookingRows, err := db.Query(`
			SELECT id, check_in, check_out, guest_name, description, source, status, room_code, units
			FROM bookings
			WHERE property_id = $1
			ORDER BY check_in
		`, propertyID)
		if err != nil {
			http.Error(w, "Query bookings error: "+err.Error(), http.StatusInternalServerError)
			return
		}
		defer bookingRows.Close()

		for bookingRows.Next() {
			var ev CalendarEvent
			var checkIn, checkOut time.Time

			if err := bookingRows.Scan(
				&ev.ID,
				&checkIn,
				&checkOut,
				&ev.Guest,
				&ev.Description,
				&ev.Source,
				&ev.Status,
				&ev.RoomCode,
				&ev.Units,
			); err != nil {
				continue
			}

			ev.CheckIn = checkIn.Format("2006-01-02")
			ev.CheckOut = checkOut.Format("2006-01-02")
			ev.GuestName = ev.Guest
			ev.EventType = "booking"
			ev.EntityType = "booking"

			events = append(events, ev)
		}

		// 2. Charger les blocs calendrier
		blockRows, err := db.Query(`
			SELECT id, room_code, date_from, date_to, block_type, reason,
			       guest_name, description,
			       COALESCE(price, 0) AS price,
			       COALESCE(units, 1) AS units,
			       COALESCE(source, 'booking') AS source,
			       COALESCE(status, block_type) AS status
			FROM calendar_blocks
			WHERE property_id = $1
			ORDER BY date_from
		`, propertyID)
		if err != nil {
			http.Error(w, "Query blocks error: "+err.Error(), http.StatusInternalServerError)
			return
		}
		defer blockRows.Close()

		for blockRows.Next() {
			var ev CalendarEvent
			var dateFrom, dateTo time.Time
			var blockType, reason string
			var roomCode, guestName, description, source, status sql.NullString
			var price float64
			var units int

			if err := blockRows.Scan(
				&ev.ID,
				&roomCode,
				&dateFrom,
				&dateTo,
				&blockType,
				&reason,
				&guestName,
				&description,
				&price,
				&units,
				&source,
				&status,
			); err != nil {
				continue
			}

			ev.CheckIn = dateFrom.Format("2006-01-02")
			ev.CheckOut = dateTo.Format("2006-01-02")
			if roomCode.Valid {
				ev.RoomCode = roomCode.String
			} else {
				ev.RoomCode = ""
			}
			ev.GuestName = "Imported iCal"
			if guestName.Valid && strings.TrimSpace(guestName.String) != "" {
				ev.GuestName = guestName.String
			} else if strings.TrimSpace(reason) != "" {
				ev.GuestName = reason
			}
			ev.Guest = ev.GuestName
			if description.Valid && strings.TrimSpace(description.String) != "" {
				ev.Description = description.String
			} else {
				ev.Description = reason
			}
			ev.Source = "booking"
			if source.Valid && strings.TrimSpace(source.String) != "" {
				ev.Source = source.String
			}
			ev.Status = blockType
			if status.Valid && strings.TrimSpace(status.String) != "" {
				ev.Status = status.String
			}
			ev.Units = units
			ev.Price = price
			ev.EventType = "calendar_block"
			ev.EntityType = "calendar_block"

			events = append(events, ev)
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(events)
	}))

	// ============================================
	// CALENDAR BLOCKS - PMS API
	// ============================================
	http.HandleFunc("/api/calendar-blocks/", corsMiddleware(func(w http.ResponseWriter, r *http.Request) {
		path := strings.Trim(strings.TrimPrefix(r.URL.Path, "/api/calendar-blocks/"), "/")
		if path == "" {
			http.Error(w, "Missing calendar block id", http.StatusBadRequest)
			return
		}

		if strings.HasPrefix(path, "update/") {
			if r.Method != http.MethodPut {
				http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
				return
			}
			id, err := strconv.Atoi(strings.Trim(strings.TrimPrefix(path, "update/"), "/"))
			if err != nil {
				http.Error(w, "Invalid id", http.StatusBadRequest)
				return
			}
			var payload CalendarBlockPayload
			if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
				http.Error(w, "Invalid request body", http.StatusBadRequest)
				return
			}
			checkIn, err := time.Parse("2006-01-02", payload.CheckIn)
			if err != nil {
				http.Error(w, "Invalid check_in date", http.StatusBadRequest)
				return
			}
			checkOut, err := time.Parse("2006-01-02", payload.CheckOut)
			if err != nil {
				http.Error(w, "Invalid check_out date", http.StatusBadRequest)
				return
			}
			if !checkOut.After(checkIn) {
				http.Error(w, "check_out must be after check_in", http.StatusBadRequest)
				return
			}
			units := payload.Units
			if units <= 0 {
				units = 1
			}
			source := strings.TrimSpace(payload.Source)
			if source == "" {
				source = "booking"
			}
			status := strings.TrimSpace(payload.Status)
			if status == "" {
				status = "confirmed"
			}
			result, err := db.Exec(`
				UPDATE calendar_blocks
				SET guest_name = $1,
					description = $2,
					date_from = $3,
					date_to = $4,
					price = $5,
					units = $6,
					source = $7,
					status = $8,
					room_code = $9
				WHERE id = $10
			`, payload.GuestName, payload.Description, checkIn, checkOut, payload.Price, units, source, status, payload.RoomCode, id)
			if err != nil {
				http.Error(w, "Update block error: "+err.Error(), http.StatusInternalServerError)
				return
			}
			rows, _ := result.RowsAffected()
			if rows == 0 {
				http.Error(w, "Calendar block not found", http.StatusNotFound)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]any{"success": true, "id": id})
			return
		}

		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
		id, err := strconv.Atoi(path)
		if err != nil {
			http.Error(w, "Invalid id", http.StatusBadRequest)
			return
		}
		var response struct {
			ID          int     `json:"id"`
			GuestName   string  `json:"guest_name"`
			Description string  `json:"description"`
			Reason      string  `json:"reason"`
			DateFrom    string  `json:"date_from"`
			DateTo      string  `json:"date_to"`
			Price       float64 `json:"price"`
			Units       int     `json:"units"`
			Source      string  `json:"source"`
			Status      string  `json:"status"`
			RoomCode    string  `json:"room_code"`
			EntityType  string  `json:"entityType"`
		}
		var dateFrom, dateTo time.Time
		var guestName, description, source, status, roomCode sql.NullString
		var price float64
		var units int
		err = db.QueryRow(`
			SELECT id,
			       COALESCE(guest_name, reason, 'Imported iCal') AS guest_name,
			       COALESCE(description, reason, '') AS description,
			       COALESCE(reason, '') AS reason,
			       date_from,
			       date_to,
			       COALESCE(price, 0) AS price,
			       COALESCE(units, 1) AS units,
			       COALESCE(source, 'booking') AS source,
			       COALESCE(status, block_type) AS status,
			       room_code
			FROM calendar_blocks
			WHERE id = $1
		`, id).Scan(&response.ID, &guestName, &description, &response.Reason, &dateFrom, &dateTo, &price, &units, &source, &status, &roomCode)
		if err != nil {
			if err == sql.ErrNoRows {
				http.Error(w, "Calendar block not found", http.StatusNotFound)
				return
			}
			http.Error(w, "Query block error: "+err.Error(), http.StatusInternalServerError)
			return
		}
		response.GuestName = guestName.String
		response.Description = description.String
		response.DateFrom = dateFrom.Format("2006-01-02")
		response.DateTo = dateTo.Format("2006-01-02")
		response.Price = price
		response.Units = units
		response.Source = source.String
		response.Status = status.String
		response.RoomCode = roomCode.String
		response.EntityType = "calendar_block"
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(response)
	}))

	// ============================================
	// PORT
	// ============================================
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("🚀 API running on :%s\n", port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}
