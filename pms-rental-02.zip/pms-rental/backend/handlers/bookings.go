package handlers

import (
	"encoding/json"
	"net/http"
	"pms-backend/services"
	"strconv"
	"strings"
	"time"
)

// CreateBookingReq - Créer une nouvelle réservation
type CreateBookingReq struct {
	PropertyID  int     `json:"property_id"`
	ChannelID   int     `json:"channel_id"`
	GuestName   string  `json:"guest_name"`
	Description string  `json:"description"`
	CheckIn     string  `json:"check_in"`
	CheckOut    string  `json:"check_out"`
	Price       float64 `json:"price"`
	Source      string  `json:"source"`
	RoomCode    string  `json:"room_code"`
	Units       int     `json:"units"`
}

// UpdateBookingReq - Modifier une réservation
type UpdateBookingReq struct {
	PropertyID  int     `json:"property_id"`
	ChannelID   int     `json:"channel_id"`
	GuestName   string  `json:"guest_name"`
	Description string  `json:"description"`
	CheckIn     string  `json:"check_in"`
	CheckOut    string  `json:"check_out"`
	Price       float64 `json:"price"`
	Source      string  `json:"source"`
	Status      string  `json:"status"`
	RoomCode    string  `json:"room_code"`
	Units       int     `json:"units"`
}

// CreateBlockReq - Créer un bloc non-disponible
type CreateBlockReq struct {
	PropertyID int    `json:"property_id"`
	DateFrom   string `json:"date_from"`
	DateTo     string `json:"date_to"`
	BlockType  string `json:"block_type"`
	Reason     string `json:"reason"`
}

// HandleCreateBooking - POST /api/bookings/create
func HandleCreateBooking(bookingSvc *services.BookingService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		var req CreateBookingReq
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request body", http.StatusBadRequest)
			return
		}

		checkIn, err := time.Parse("2006-01-02", req.CheckIn)
		if err != nil {
			http.Error(w, "Invalid check_in format (use YYYY-MM-DD)", http.StatusBadRequest)
			return
		}

		checkOut, err := time.Parse("2006-01-02", req.CheckOut)
		if err != nil {
			http.Error(w, "Invalid check_out format (use YYYY-MM-DD)", http.StatusBadRequest)
			return
		}

		id, err := bookingSvc.CreateBooking(
			req.PropertyID,
			req.ChannelID,
			req.GuestName,
			req.Description,
			checkIn,
			checkOut,
			req.Price,
			req.Source,
			req.RoomCode,
			req.Units,
		)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": true,
			"id":      id,
		})
	}
}

// HandleGetBookings - GET /api/bookings
func HandleGetBookings(bookingSvc *services.BookingService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		propertyID := 1
		bookings, err := bookingSvc.GetBookings(propertyID)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(bookings)
	}
}

// HandleGetBooking - GET /api/bookings/{id}
func HandleGetBooking(bookingSvc *services.BookingService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		// Extraire l'ID du path: /api/bookings/{id}
		parts := strings.Split(r.URL.Path, "/")
		if len(parts) < 4 || parts[3] == "" {
			http.Error(w, "Missing booking ID", http.StatusBadRequest)
			return
		}

		idStr := parts[3]
		bookingID, err := strconv.Atoi(idStr)
		if err != nil {
			http.Error(w, "Invalid booking ID", http.StatusBadRequest)
			return
		}

		booking, err := bookingSvc.GetBooking(bookingID)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(booking)
	}
}

// HandleUpdateBooking - PUT /api/bookings/update/{id}
func HandleUpdateBooking(bookingSvc *services.BookingService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPut {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		// Extraire l'ID: /api/bookings/update/{id}
		parts := strings.Split(r.URL.Path, "/")
		if len(parts) < 5 || parts[4] == "" {
			http.Error(w, "Missing booking ID", http.StatusBadRequest)
			return
		}

		idStr := parts[4]
		bookingID, err := strconv.Atoi(idStr)
		if err != nil {
			http.Error(w, "Invalid booking ID", http.StatusBadRequest)
			return
		}

		var req UpdateBookingReq
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request body", http.StatusBadRequest)
			return
		}

		checkIn, err := time.Parse("2006-01-02", req.CheckIn)
		if err != nil {
			http.Error(w, "Invalid check_in format", http.StatusBadRequest)
			return
		}

		checkOut, err := time.Parse("2006-01-02", req.CheckOut)
		if err != nil {
			http.Error(w, "Invalid check_out format", http.StatusBadRequest)
			return
		}

		if err := bookingSvc.UpdateBooking(
			bookingID,
			req.GuestName,
			req.Description,
			checkIn,
			checkOut,
			req.Price,
			req.Status,
			req.RoomCode,
			req.Units,
		); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": true,
			"id":      bookingID,
		})
	}
}

// HandleDeleteBooking - DELETE /api/bookings/delete/{id}
func HandleDeleteBooking(bookingSvc *services.BookingService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodDelete {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		// Extraire l'ID: /api/bookings/delete/{id}
		parts := strings.Split(r.URL.Path, "/")
		if len(parts) < 5 || parts[4] == "" {
			http.Error(w, "Missing booking ID", http.StatusBadRequest)
			return
		}

		idStr := parts[4]
		bookingID, err := strconv.Atoi(idStr)
		if err != nil {
			http.Error(w, "Invalid booking ID", http.StatusBadRequest)
			return
		}

		if err := bookingSvc.DeleteBooking(bookingID); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": true,
		})
	}
}

// HandleCreateBlock - POST /api/calendar-blocks
func HandleCreateBlock(bookingSvc *services.BookingService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		var req CreateBlockReq
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request body", http.StatusBadRequest)
			return
		}

		dateFrom, err := time.Parse("2006-01-02", req.DateFrom)
		if err != nil {
			http.Error(w, "Invalid date_from format", http.StatusBadRequest)
			return
		}

		dateTo, err := time.Parse("2006-01-02", req.DateTo)
		if err != nil {
			http.Error(w, "Invalid date_to format", http.StatusBadRequest)
			return
		}

		id, err := bookingSvc.CreateCalendarBlock(req.PropertyID, dateFrom, dateTo, req.BlockType, req.Reason)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success": true,
			"id":      id,
		})
	}
}

// ============================================
// PRICING HANDLERS (Phase 3.2)
// ============================================

func HandleSyncPrices(bookingSvc *services.BookingService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		type SyncRequest struct {
			Email      string                   `json:"email"`
			Password   string                   `json:"password"`
			PropertyID string                   `json:"property_id"`
			Updates    []services.PricingUpdate `json:"updates"`
		}

		var req SyncRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request body", http.StatusBadRequest)
			return
		}

		if req.Email == "" || req.Password == "" {
			http.Error(w, "Email et password requis", http.StatusBadRequest)
			return
		}

		if len(req.Updates) == 0 {
			http.Error(w, "Au moins un tarif requis", http.StatusBadRequest)
			return
		}

		syncService := services.NewBookingSyncService(req.Email, req.Password, req.PropertyID)

		if err := syncService.SyncPrices(req.Updates); err != nil {
			http.Error(w, "Erreur synchronisation: "+err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"success":       true,
			"message":       "Synchronisation Booking complétée",
			"updated_count": len(req.Updates),
		})
	}
}

func HandleGetPrices(bookingSvc *services.BookingService) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		email := r.URL.Query().Get("email")
		password := r.URL.Query().Get("password")
		propertyID := r.URL.Query().Get("property_id")

		if email == "" || password == "" {
			http.Error(w, "Email et password requis", http.StatusBadRequest)
			return
		}

		syncService := services.NewBookingSyncService(email, password, propertyID)

		prices, err := syncService.FetchCurrentPrices()
		if err != nil {
			http.Error(w, "Erreur récupération tarifs: "+err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(prices)
	}
}
