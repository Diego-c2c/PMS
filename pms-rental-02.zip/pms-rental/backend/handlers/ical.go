package handlers

import (
	"database/sql"
	"encoding/json"
	"net/http"
	"pms-backend/services"
	"time"
)

type ImportICal struct {
	URL        string `json:"url"`
	PropertyID int    `json:"property_id"`
	ChannelID  int    `json:"channel_id"`
	Source     string `json:"source"` // 'airbnb' ou 'booking'
}

type ImportResult struct {
	Success       bool   `json:"success"`
	Message       string `json:"message"`
	BookingsAdded int    `json:"bookings_added"`
}

// HandleICalImport traite l'import d'un flux iCal
func HandleICalImport(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		// Lire le corps de la requête
		var req ImportICal
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "Invalid request", http.StatusBadRequest)
			return
		}

		// Télécharger le flux iCal
		content, err := services.DownloadICalFromURL(req.URL)
		if err != nil {
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(ImportResult{
				Success: false,
				Message: "Failed to download iCal: " + err.Error(),
			})
			return
		}

		// Parser le flux
		events, err := services.ParseICal(content)
		if err != nil {
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(ImportResult{
				Success: false,
				Message: "Failed to parse iCal: " + err.Error(),
			})
			return
		}

		// Insérer les réservations dans la DB
		added := 0
		for _, event := range events {
			booking := services.ICalEventToBooking(event, req.PropertyID, req.ChannelID, req.Source)

			// Vérifier si la réservation existe déjà (par external_booking_id)
			var exists int
			err := db.QueryRow(
				"SELECT COUNT(*) FROM bookings WHERE external_booking_id = $1",
				booking.ExternalBookingID,
			).Scan(&exists)

			if err == nil && exists == 0 {
				// Insérer la nouvelle réservation
				_, err := db.Exec(`
					INSERT INTO bookings (property_id, channel_id, external_booking_id, guest_name, check_in, check_out, price, status, source, last_synced)
					VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
				`,
					booking.PropertyID,
					booking.ChannelID,
					booking.ExternalBookingID,
					booking.GuestName,
					booking.CheckIn,
					booking.CheckOut,
					booking.Price,
					booking.Status,
					booking.Source,
					time.Now(),
				)
				if err == nil {
					added++
				}
			}
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(ImportResult{
			Success:       true,
			Message:       "Import completed",
			BookingsAdded: added,
		})
	}
}
