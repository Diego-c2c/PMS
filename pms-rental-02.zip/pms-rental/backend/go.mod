module pms-backend

go 1.23

require (
	github.com/lib/pq v1.10.9
	github.com/robfig/cron/v3 v3.0.0
)
