package services

import (
	"database/sql"
	"fmt"
	"log"
	"time"

	"github.com/robfig/cron/v3"
)

type ICalScheduler struct {
	db          *sql.DB
	cron        *cron.Cron
	icalImports []ICalImportConfig
}

type ICalImportConfig struct {
	ID         int
	URL        string
	PropertyID int
	ChannelID  int
	Source     string // 'airbnb' ou 'booking'
}

// NewICalScheduler crée un nouveau scheduler
func NewICalScheduler(db *sql.DB) *ICalScheduler {
	return &ICalScheduler{
		db:   db,
		cron: cron.New(),
	}
}

// LoadImportConfigs charge les configurations d'import depuis la DB
func (s *ICalScheduler) LoadImportConfigs() error {
	rows, err := s.db.Query(`
		SELECT id, ical_url, property_id, channel_id, '' as source
		FROM ical_imports
		WHERE ical_url IS NOT NULL
	`)
	if err != nil {
		return err
	}
	defer rows.Close()

	s.icalImports = []ICalImportConfig{}
	for rows.Next() {
		var cfg ICalImportConfig
		if err := rows.Scan(&cfg.ID, &cfg.URL, &cfg.PropertyID, &cfg.ChannelID, &cfg.Source); err != nil {
			continue
		}
		s.icalImports = append(s.icalImports, cfg)
	}

	log.Printf("Loaded %d iCal import configs\n", len(s.icalImports))
	return rows.Err()
}

// processImport traite un import iCal
func (s *ICalScheduler) processImport(cfg ICalImportConfig) {
	log.Printf("Processing import from %s (URL: %s)\n", cfg.Source, cfg.URL)

	// Télécharger le flux
	content, err := DownloadICalFromURL(cfg.URL)
	if err != nil {
		log.Printf("Error downloading iCal from %s: %v\n", cfg.Source, err)
		return
	}

	// Parser
	events, err := ParseICal(content)
	if err != nil {
		log.Printf("Error parsing iCal from %s: %v\n", cfg.Source, err)
		return
	}

	// Insérer les événements
	added := 0
	updated := 0
	for _, event := range events {
		booking := ICalEventToBooking(event, cfg.PropertyID, cfg.ChannelID, cfg.Source)

		// Vérifier si existe
		var exists int
		s.db.QueryRow(
			"SELECT COUNT(*) FROM bookings WHERE external_booking_id = $1",
			booking.ExternalBookingID,
		).Scan(&exists)

		if exists == 0 {
			// Insérer
			_, err := s.db.Exec(`
				INSERT INTO bookings (property_id, channel_id, external_booking_id, guest_name, check_in, check_out, price, status, source, last_synced)
				VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
			`,
				booking.PropertyID,
				booking.ChannelID,
				booking.ExternalBookingID,
				booking.GuestName,
				booking.CheckIn,
				booking.CheckOut,
				booking.Price,
				booking.Status,
				booking.Source,
				time.Now(),
			)
			if err == nil {
				added++
			}
		} else {
			// Mettre à jour
			_, err := s.db.Exec(`
				UPDATE bookings 
				SET guest_name = $1, check_in = $2, check_out = $3, status = $4, last_synced = $5
				WHERE external_booking_id = $6
			`,
				booking.GuestName,
				booking.CheckIn,
				booking.CheckOut,
				booking.Status,
				time.Now(),
				booking.ExternalBookingID,
			)
			if err == nil {
				updated++
			}
		}
	}

	log.Printf("Import from %s completed: %d added, %d updated\n", cfg.Source, added, updated)
}

// Start démarre le scheduler
func (s *ICalScheduler) Start() error {
	// Charger les configs
	if err := s.LoadImportConfigs(); err != nil {
		return fmt.Errorf("failed to load configs: %w", err)
	}

	if len(s.icalImports) == 0 {
		log.Println("No iCal imports configured")
		return nil
	}

	// Ajouter une tâche qui s'exécute toutes les heures
	_, err := s.cron.AddFunc("0 * * * *", func() {
		log.Println("Running iCal import scheduler...")
		for _, cfg := range s.icalImports {
			s.processImport(cfg)
		}
	})
	if err != nil {
		return fmt.Errorf("failed to add cron job: %w", err)
	}

	// Démarrer le cron
	s.cron.Start()
	log.Println("iCal scheduler started (runs every hour)")

	return nil
}

// Stop arrête le scheduler
func (s *ICalScheduler) Stop() {
	s.cron.Stop()
	log.Println("iCal scheduler stopped")
}
