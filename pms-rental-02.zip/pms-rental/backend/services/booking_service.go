package services

import (
	"database/sql"
	"fmt"
	"time"
)

type BookingService struct {
	db *sql.DB
}

func NewBookingService(db *sql.DB) *BookingService {
	return &BookingService{db: db}
}

// CreateBooking crée une nouvelle réservation
func (s *BookingService) CreateBooking(
	propertyID int,
	channelID int,
	guestName string,
	description string,
	checkIn, checkOut time.Time,
	price float64,
	source string,
	roomCode string,
	units int,
) (int, error) {
	var id int
	err := s.db.QueryRow(`
        INSERT INTO bookings
            (property_id, channel_id, guest_name,  description, check_in, check_out, price, status, source, room_code, units, last_synced)
        VALUES
            ($1,         $2,        $3,         $4,       $5,       $6,    $7,     $8,     $9,        $10,   $11, $12)
        RETURNING id
    `, propertyID, channelID, guestName, description, checkIn, checkOut, price, "confirmed", source, roomCode, units, time.Now()).Scan(&id)

	if err != nil {
		return 0, fmt.Errorf("failed to create booking: %w", err)
	}
	return id, nil
}

// GetBookings récupère toutes les réservations
func (s *BookingService) GetBookings(propertyID int) ([]map[string]interface{}, error) {
	rows, err := s.db.Query(`
        SELECT id, guest_name, description, check_in, check_out,
               price, status, source, room_code, units
        FROM bookings
        WHERE property_id = $1
        ORDER BY check_in
    `, propertyID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	bookings := make([]map[string]interface{}, 0)
	for rows.Next() {
		var id int
		var guestName, status, source, roomCode string
		var description string
		var checkIn, checkOut time.Time
		var price float64
		var units int

		if err := rows.Scan(
			&id,
			&guestName,
			&description,
			&checkIn,
			&checkOut,
			&price,
			&status,
			&source,
			&roomCode,
			&units,
		); err != nil {
			continue
		}

		booking := map[string]interface{}{
			"id":          id,
			"guest":       guestName,
			"check_in":    checkIn,
			"check_out":   checkOut,
			"price":       price,
			"status":      status,
			"source":      source,
			"room_code":   roomCode,
			"units":       units,
			"description": description, // ← clé utilisée par le JS
		}
		bookings = append(bookings, booking)
	}

	return bookings, rows.Err()
}

// GetBooking récupère UNE SEULE réservation par son ID

func (s *BookingService) GetBooking(bookingID int) (map[string]interface{}, error) {
	var id int
	var guestName sql.NullString
	var status sql.NullString
	var source sql.NullString
	var roomCode sql.NullString
	var description sql.NullString
	var checkIn, checkOut time.Time
	var price sql.NullFloat64
	var units sql.NullInt64

	err := s.db.QueryRow(`
        SELECT id, guest_name, description, check_in, check_out, price, status, source, room_code, units
        FROM bookings
        WHERE id = $1
    `, bookingID).Scan(
		&id,
		&guestName,
		&description,
		&checkIn,
		&checkOut,
		&price,
		&status,
		&source,
		&roomCode,
		&units,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("booking not found")
		}
		return nil, fmt.Errorf("failed to get booking: %w", err)
	}

	booking := map[string]interface{}{
		"id":          id,
		"guest":       "",
		"guest_name":  "",
		"description": "",
		"check_in":    checkIn.Format("2006-01-02"),
		"check_out":   checkOut.Format("2006-01-02"),
		"price":       nil,
		"status":      "",
		"source":      "",
		"room_code":   "",
		"units":       1,
	}

	if guestName.Valid {
		booking["guest"] = guestName.String
		booking["guest_name"] = guestName.String
	}

	if description.Valid {
		booking["description"] = description.String
	}

	if price.Valid {
		booking["price"] = price.Float64
	}

	if status.Valid {
		booking["status"] = status.String
	}

	if source.Valid {
		booking["source"] = source.String
	}

	if roomCode.Valid {
		booking["room_code"] = roomCode.String
	}

	if units.Valid {
		booking["units"] = units.Int64
	}

	return booking, nil
}

// UpdateBooking met à jour une réservation
func (s *BookingService) UpdateBooking(
	bookingID int,
	guestName string,
	description string,
	checkIn, checkOut time.Time,
	price float64,
	status string,
	roomCode string,
	units int,
) error {
	_, err := s.db.Exec(`
        UPDATE bookings
        SET guest_name = $1,
			description = $2,
            check_in   = $3,
            check_out  = $4,
            price      = $5,
            status     = $6,
            room_code  = $7,
            units      = $8,
            last_synced = $9
        WHERE id = $10
    `, guestName, description, checkIn, checkOut, price, status, roomCode, units, time.Now(), bookingID)

	if err != nil {
		return fmt.Errorf("failed to update booking: %w", err)
	}
	return nil
}

// DeleteBooking supprime une réservation
func (s *BookingService) DeleteBooking(bookingID int) error {
	result, err := s.db.Exec("DELETE FROM bookings WHERE id = $1", bookingID)
	if err != nil {
		return fmt.Errorf("failed to delete booking: %w", err)
	}

	rows, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rows == 0 {
		return fmt.Errorf("booking not found")
	}

	return nil
}

// CreateCalendarBlock crée un bloc non-disponible
func (s *BookingService) CreateCalendarBlock(propertyID int, dateFrom, dateTo time.Time, blockType, reason string) (int, error) {
	var id int
	err := s.db.QueryRow(`
        INSERT INTO calendar_blocks (property_id, date_from, date_to, block_type, reason)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id
    `, propertyID, dateFrom, dateTo, blockType, reason).Scan(&id)

	if err != nil {
		return 0, fmt.Errorf("failed to create block: %w", err)
	}
	return id, nil
}

// GetCalendarBlocks récupère tous les blocs
func (s *BookingService) GetCalendarBlocks(propertyID int) ([]map[string]interface{}, error) {
	rows, err := s.db.Query(`
        SELECT id, date_from, date_to, block_type, reason
        FROM calendar_blocks
        WHERE property_id = $1
        ORDER BY date_from
    `, propertyID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var blocks []map[string]interface{}
	for rows.Next() {
		var id int
		var blockType, reason string
		var dateFrom, dateTo time.Time

		if err := rows.Scan(&id, &dateFrom, &dateTo, &blockType, &reason); err != nil {
			continue
		}

		block := map[string]interface{}{
			"id":         id,
			"date_from":  dateFrom,
			"date_to":    dateTo,
			"block_type": blockType,
			"reason":     reason,
		}
		blocks = append(blocks, block)
	}

	return blocks, rows.Err()
}

// DeleteCalendarBlock supprime un bloc
func (s *BookingService) DeleteCalendarBlock(blockID int) error {
	result, err := s.db.Exec("DELETE FROM calendar_blocks WHERE id = $1", blockID)
	if err != nil {
		return fmt.Errorf("failed to delete block: %w", err)
	}

	rows, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rows == 0 {
		return fmt.Errorf("block not found")
	}

	return nil
}
