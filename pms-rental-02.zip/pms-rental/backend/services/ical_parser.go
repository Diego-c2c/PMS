package services

import (
	"bufio"
	"fmt"
	"strings"
	"time"
)

type ICalEvent struct {
	Summary     string
	UID         string
	StartDate   time.Time
	EndDate     time.Time
	Description string
}

// ParseICal lit un fichier iCal et extrait les événements
func ParseICal(content string) ([]ICalEvent, error) {
	var events []ICalEvent
	var currentEvent ICalEvent
	inEvent := false

	scanner := bufio.NewScanner(strings.NewReader(content))
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())

		if line == "BEGIN:VEVENT" {
			inEvent = true
			currentEvent = ICalEvent{}
			continue
		}

		if line == "END:VEVENT" {
			inEvent = false
			events = append(events, currentEvent)
			continue
		}

		if !inEvent {
			continue
		}

		// Parse SUMMARY
		if strings.HasPrefix(line, "SUMMARY:") {
			currentEvent.Summary = strings.TrimPrefix(line, "SUMMARY:")
		}

		// Parse UID
		if strings.HasPrefix(line, "UID:") {
			currentEvent.UID = strings.TrimPrefix(line, "UID:")
		}

		// Parse DESCRIPTION
		if strings.HasPrefix(line, "DESCRIPTION:") {
			currentEvent.Description = strings.TrimPrefix(line, "DESCRIPTION:")
		}

		// Parse DTSTART (date de début)
		if strings.HasPrefix(line, "DTSTART") {
			dateStr := extractDateValue(line)
			if t, err := parseICalDate(dateStr); err == nil {
				currentEvent.StartDate = t
			}
		}

		// Parse DTEND (date de fin)
		if strings.HasPrefix(line, "DTEND") {
			dateStr := extractDateValue(line)
			if t, err := parseICalDate(dateStr); err == nil {
				currentEvent.EndDate = t
			}
		}
	}

	return events, scanner.Err()
}

// extractDateValue extrait la valeur après le ":" dans une ligne DTSTART/DTEND
func extractDateValue(line string) string {
	parts := strings.Split(line, ":")
	if len(parts) > 1 {
		return parts[len(parts)-1]
	}
	return ""
}

// parseICalDate parse les formats de date iCal (YYYYMMDD ou YYYYMMDDTHHMMSSZ)
func parseICalDate(dateStr string) (time.Time, error) {
	dateStr = strings.TrimSpace(dateStr)

	// Format: 20260315 (date seule)
	if len(dateStr) == 8 {
		return time.Parse("20060102", dateStr)
	}

	// Format: 20260315T000000Z (datetime)
	if len(dateStr) == 16 && strings.HasSuffix(dateStr, "Z") {
		return time.Parse("20060102T150405Z", dateStr)
	}

	// Format: 20260315T000000 (datetime sans Z)
	if len(dateStr) == 15 {
		return time.Parse("20060102T150405", dateStr)
	}

	return time.Time{}, fmt.Errorf("unknown date format: %s", dateStr)
}

// EventToBooking convertit un événement iCal en réservation
type BookingData struct {
	PropertyID        int
	ChannelID         int
	ExternalBookingID string
	GuestName         string
	CheckIn           time.Time
	CheckOut          time.Time
	Price             float64
	Status            string
	Source            string
}

func ICalEventToBooking(event ICalEvent, propertyID int, channelID int, source string) BookingData {
	return BookingData{
		PropertyID:        propertyID,
		ChannelID:         channelID,
		ExternalBookingID: event.UID,
		GuestName:         event.Summary,
		CheckIn:           event.StartDate,
		CheckOut:          event.EndDate,
		Price:             0.0, // À récupérer depuis Airbnb/Booking API plus tard
		Status:            "confirmed",
		Source:            source,
	}
}
