package services

import (
	"database/sql" // ← AJOUTER
	"fmt"
	"log" // ← AJOUTER
	"time"
)

/**
 * =========================================
 * PRICING_RULES.GO - MOTEUR DE PRICING
 * =========================================
 *
 * DESCRIPTION:
 * Calcule les prix dynamiques en fonction de:
 * - La période (haute/basse saison)
 * - L'occupation
 * - Les règles définies
 *
 * PHASE: 3.2 (Automation des prix)
 */

// PricingRule - Structure d'une règle de pricing
type PricingRule struct {
	ID            int       `json:"id"`
	PropertyID    int       `json:"property_id"`
	Name          string    `json:"name"` // "Basse saison", "WE", etc.
	StartDate     time.Time `json:"start_date"`
	EndDate       time.Time `json:"end_date"`
	PriceModifier float64   `json:"price_modifier"` // 0.9 = -10%, 1.2 = +20%
	MinDays       int       `json:"min_days"`       // Minimum de jours
	IsActive      bool      `json:"is_active"`
}

// PricingService - Service pour gérer les prix
type PricingService struct {
	db *sql.DB
}

// NewPricingService - Crée une nouvelle instance
func NewPricingService(db *sql.DB) *PricingService {
	return &PricingService{db: db}
}

/**
 * CalculatePrice - Calcule le prix dynamique pour une période
 *
 * @param {int} propertyID - ID de la propriété
 * @param {time.Time} checkIn - Date d'arrivée
 * @param {time.Time} checkOut - Date de départ
 * @param {float64} basePrice - Prix de base par nuit
 * @return {float64} - Prix calculé total
 *
 * LOGIQUE:
 * 1. Récupérer les règles actives pour la période
 * 2. Pour chaque nuit, appliquer la règle applicable
 * 3. Additionner le total
 */
func (s *PricingService) CalculatePrice(propertyID int, checkIn, checkOut time.Time, basePrice float64) (float64, error) {
	// Nombre de nuits
	nights := int(checkOut.Sub(checkIn).Hours() / 24)

	if nights <= 0 {
		return 0, fmt.Errorf("nombre de nuits invalide")
	}

	totalPrice := 0.0
	currentDate := checkIn

	// Parcourir chaque nuit et appliquer la règle
	for i := 0; i < nights; i++ {
		// Récupérer la règle applicable ce jour
		modifier := s.GetRuleModifier(propertyID, currentDate)

		// Appliquer le modifier
		nightPrice := basePrice * modifier
		totalPrice += nightPrice

		// Passer au jour suivant
		currentDate = currentDate.AddDate(0, 0, 1)
	}

	log.Printf("💰 Prix calculé: %.2f pour %d nuits\n", totalPrice, nights)
	return totalPrice, nil
}

/**
 * GetRuleModifier - Récupère le modifier (multiplicateur) pour une date
 *
 * @param {int} propertyID
 * @param {time.Time} date - Date vérifiée
 * @return {float64} - Multiplicateur de prix (1.0 = pas de modification)
 *
 * RÈGLES PAR DÉFAUT:
 * - Haute saison (Juillet/Août): +20% (1.2)
 * - Week-end (Ven/Sam): +15% (1.15)
 * - Basse saison (Hiver): -10% (0.9)
 * - Normal: 1.0
 */
func (s *PricingService) GetRuleModifier(propertyID int, date time.Time) float64 {
	// TODO: Récupérer depuis la DB
	// Pour l'instant, règles en dur

	month := date.Month()
	weekday := date.Weekday()

	// Haute saison: Juillet, Août
	if month == time.July || month == time.August {
		return 1.2 // +20%
	}

	// Week-end: Vendredi (5) et Samedi (6)
	if weekday == time.Friday || weekday == time.Saturday {
		return 1.15 // +15%
	}

	// Basse saison: Novembre à Mars
	if month >= time.November || month <= time.March {
		return 0.9 // -10%
	}

	// Normalement
	return 1.0
}

/**
 * CreateRule - Crée une nouvelle règle de pricing
 */
func (s *PricingService) CreateRule(rule PricingRule) (int, error) {
	var id int
	err := s.db.QueryRow(`
		INSERT INTO pricing_rules (property_id, name, start_date, end_date, price_modifier, min_days, is_active)
		VALUES ($1, $2, $3, $4, $5, $6, $7)
		RETURNING id
	`, rule.PropertyID, rule.Name, rule.StartDate, rule.EndDate, rule.PriceModifier, rule.MinDays, rule.IsActive).Scan(&id)

	if err != nil {
		return 0, fmt.Errorf("failed to create rule: %w", err)
	}
	return id, nil
}

/**
 * GetRules - Récupère toutes les règles d'une propriété
 */
func (s *PricingService) GetRules(propertyID int) ([]PricingRule, error) {
	rows, err := s.db.Query(`
		SELECT id, property_id, name, start_date, end_date, price_modifier, min_days, is_active
		FROM pricing_rules
		WHERE property_id = $1 AND is_active = true
		ORDER BY start_date
	`, propertyID)

	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var rules []PricingRule
	for rows.Next() {
		var r PricingRule
		if err := rows.Scan(&r.ID, &r.PropertyID, &r.Name, &r.StartDate, &r.EndDate, &r.PriceModifier, &r.MinDays, &r.IsActive); err != nil {
			continue
		}
		rules = append(rules, r)
	}

	return rules, rows.Err()
}
