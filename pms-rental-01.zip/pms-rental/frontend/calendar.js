/**
 * =========================================
 * CALENDAR.JS - GESTION DU CALENDRIER PMS
 * =========================================
 *
 * Ce fichier gère :
 * - le chargement des réservations depuis l'API
 * - l'affichage du tableau du calendrier
 * - la suppression d'une réservation
 * - l'application du thème (clair / sombre / océan)
 * - le mode lecture seule pour les utilisateurs "user"
 */


/* =========================
   CONFIGURATION DES COULEURS
   ========================= */
const ROOM_COLORS = {
  raspberry:   { bg: '#DE7F74', text: '#b30059', label: 'Raspberry Room 2' },
  blueberry:   { bg: '#64ABDA', text: '#006699', label: 'Blueberry Room 1' },
  maracuja:    { bg: '#E9AD6E', text: '#856404', label: 'Maracuja Room 3' },
  surfhouse:   { bg: '#7FC7B7', text: '#495057', label: 'House' },
  female_dorm: { bg: '#e9bc8c', text: '#8a6d3b', label: 'Bed in a Dorm' }
};


/* =========================
   MAPPING NOM ROOM → CLÉ COURTE
   =========================
   Le backend envoie maintenant room_code = "Raspberry Room" (nom complet).
   Cette fonction fait le mapping vers la clé courte utilisée par ROOM_COLORS.
*/
function getRoomKeyFromRoomCode(roomCode) {
  if (!roomCode) return null;

  const lower = roomCode.toLowerCase();

  if (lower.includes('raspberry')) return 'raspberry';
  if (lower.includes('blueberry')) return 'blueberry';
  if (lower.includes('maracuja')) return 'maracuja';
  if (lower.includes('surf') || lower.includes('cloud')) return 'surfhouse';
  if (lower.includes('female') || lower.includes('dorm')) return 'female_dorm';

  return null;
}


/* =========================
   VARIABLES GLOBALES
   ========================= */
let currentUser = null;
let calendarRefreshInterval = null;


/* =========================
   FONCTIONS UTILITAIRES
   ========================= */


/**
 * Échappe une chaîne pour éviter l'injection HTML
 */
function escapeHTML(value) {
  if (value === null || value === undefined) return '';
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}


/**
 * Formate une date en français
 */
function formatDateFR(dateValue) {
  if (!dateValue) return '';
  const date = new Date(dateValue);

  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return date.toLocaleDateString('fr-FR');
}


/**
 * Retourne le libellé de la source avec icône
 */
function formatSourceLabel(source) {
  if (source === 'booking') return '🏨 Booking';
  if (source === 'airbnb') return '🏠 Airbnb';
  return '📞 Direct';
}


/**
 * Construit le style de cellule selon la chambre
 * CORRECTION : utilise le mapping room_code → clé courte
 */
function buildRoomStyle(roomCode) {
  const roomKey = getRoomKeyFromRoomCode(roomCode);
  const roomInfo = roomKey ? ROOM_COLORS[roomKey] : null;

  if (!roomInfo) return '';

  return `style="background-color:${roomInfo.bg};color:${roomInfo.text};border-radius:4px;padding:2px 4px;"`;
}


/**
 * Construit le libellé de l'hébergement
 * CORRECTION : utilise le mapping room_code → clé courte
 */
function buildRoomLabel(roomCode, units) {
  const roomKey = getRoomKeyFromRoomCode(roomCode);
  const roomInfo = roomKey ? ROOM_COLORS[roomKey] : null;

  if (!roomInfo) return roomCode || '';

  const unitsSuffix = Number(units) > 1 ? ` x${Number(units)}` : '';
  return `${roomInfo.label}${unitsSuffix}`;
}


/**
 * Vérifie si l'utilisateur courant est en lecture seule
 */
function isReadOnlyUser() {
  return currentUser && currentUser.role === 'user';
}


/* =========================
   CHARGEMENT DU CALENDRIER
   ========================= */


/**
 * Charge les réservations depuis l'API
 * et construit le tableau HTML
 */
async function loadCalendar() {
  try {
    const apiUrl = 'http://localhost:8080/api/bookings';
    console.log('📡 Récupération des réservations :', apiUrl);

    const response = await fetch(apiUrl);

    if (!response.ok) {
      throw new Error(`Erreur API (${response.status})`);
    }

    const bookings = await response.json();

    let html = `
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Client</th>
            <th>Hébergement</th>
            <th>Arrivée</th>
            <th>Départ</th>
            <th>Prix</th>
            <th>Statut</th>
            <th>Source</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
    `;

    if (bookings && bookings.length > 0) {
      bookings.forEach((b) => {
        const bookingId = b.id || b.booking_id;
        const roomCode = b.room_code || '';
        const roomStyle = buildRoomStyle(roomCode);
        const roomLabel = buildRoomLabel(roomCode, b.units);

        const checkInDate = formatDateFR(b.check_in);
        const checkOutDate = formatDateFR(b.check_out);

        const guest = escapeHTML(b.guest || '');
        const price = escapeHTML(b.price ?? '');
        const status = escapeHTML(b.status || '');
        const source = escapeHTML(b.source || '');
        const sourceLabel = formatSourceLabel(b.source);

        const readOnly = isReadOnlyUser();

        const editButton = readOnly
          ? `
            <button
              class="btn-edit"
              type="button"
              disabled
              title="Modification non autorisée pour ce rôle">
              ✏️ Modifier
            </button>
          `
          : `
            <a
              href="edit-booking.html?id=${encodeURIComponent(bookingId)}"
              class="btn-edit"
              title="Modifier cette réservation">
              ✏️ Modifier
            </a>
          `;

        const deleteButton = readOnly
          ? `
            <button
              class="btn-delete"
              type="button"
              disabled
              title="Suppression non autorisée pour ce rôle">
              🗑️ Supprimer
            </button>
          `
          : `
            <button
              class="btn-delete"
              type="button"
              onclick="deleteBooking(${Number(bookingId)})"
              title="Supprimer cette réservation">
              🗑️ Supprimer
            </button>
          `;

        html += `
          <tr>
            <td ${roomStyle}>${escapeHTML(bookingId)}</td>
            <td ${roomStyle}><strong>${guest}</strong></td>
            <td ${roomStyle}>${escapeHTML(roomLabel)}</td>
            <td ${roomStyle}>${escapeHTML(checkInDate)}</td>
            <td ${roomStyle}>${escapeHTML(checkOutDate)}</td>
            <td ${roomStyle}>${price}€</td>
            <td ${roomStyle}>
              <span class="status-badge status-${status.toLowerCase()}">
                ${status}
              </span>
            </td>
            <td ${roomStyle}>
              <span class="badge badge-${source.toLowerCase()}">
                ${escapeHTML(sourceLabel)}
              </span>
            </td>
            <td class="actions" ${roomStyle}>
              <div class="actions-inner">
                ${editButton}
                ${deleteButton}
              </div>
            </td>
          </tr>
        `;
      });
    } else {
      html += `
        <tr>
          <td colspan="9" style="text-align:center;padding:40px;">
            📭 Aucune réservation pour le moment
          </td>
        </tr>
      `;
    }

    html += `
        </tbody>
      </table>
    `;

    const calendarEl = document.getElementById('calendar');
    if (calendarEl) {
      calendarEl.innerHTML = html;
    }
  } catch (error) {
    console.error('❌ Erreur lors du chargement :', error);

    const calendarEl = document.getElementById('calendar');
    if (calendarEl) {
      calendarEl.innerHTML = `
        <div style="
          background-color: #f8d7da;
          color: #721c24;
          padding: 20px;
          border-radius: 8px;
          border-left: 4px solid #dc3545;
          margin-top: 20px;
        ">
          <strong>⚠️ Erreur :</strong> ${escapeHTML(error.message)}
        </div>
      `;
    }
  }
}


/* =========================
   SUPPRESSION D'UNE RESERVATION
   ========================= */


/**
 * Supprime une réservation après confirmation
 * Interdit l'action si l'utilisateur est en lecture seule
 */
async function deleteBooking(bookingId) {
  if (isReadOnlyUser()) {
    alert('⛔ Vous êtes en lecture seule. Suppression non autorisée.');
    return;
  }

  const confirmed = confirm(
    '⚠️ Êtes-vous sûr de vouloir supprimer cette réservation ?\nCette action est irréversible.'
  );

  if (!confirmed) {
    console.log('Suppression annulée');
    return;
  }

  try {
    console.log('🗑️ Suppression de la réservation :', bookingId);

    const response = await fetch(`http://localhost:8080/api/bookings/delete/${bookingId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' }
    });

    const result = await response.json();

    if (response.ok && result.success) {
      alert('✅ Réservation supprimée avec succès !');
      await loadCalendar();
    } else {
      alert(`❌ Erreur : ${result.message || 'Impossible de supprimer la réservation'}`);
    }
  } catch (error) {
    alert(`❌ Erreur réseau : ${error.message}`);
    console.error('Erreur lors de la suppression :', error);
  }
}


/* =========================
   GESTION DES THEMES
   ========================= */


/**
 * Applique un thème à la page
 */
function applyTheme(theme) {
  document.body.classList.remove('theme-dark', 'theme-ocean');

  if (theme === 'dark') {
    document.body.classList.add('theme-dark');
  }

  if (theme === 'ocean') {
    document.body.classList.add('theme-ocean');
  }

  localStorage.setItem('pms-theme', theme);
}


/* =========================
   INITIALISATION
   ========================= */


document.addEventListener('DOMContentLoaded', async () => {
  // Chargement du thème sauvegardé
  const savedTheme = localStorage.getItem('pms-theme') || 'light';
  applyTheme(savedTheme);

  const themeSelect = document.getElementById('theme-select');
  if (themeSelect) {
    themeSelect.value = savedTheme;
    themeSelect.addEventListener('change', () => {
      applyTheme(themeSelect.value);
    });
  }

  // Récupération du user connecté depuis auth.js si disponible
  if (typeof getCurrentUser === 'function') {
    currentUser = await getCurrentUser();
  }

  // Chargement initial du calendrier
  await loadCalendar();

  // Rafraîchissement automatique toutes les 30 secondes
  if (calendarRefreshInterval) {
    clearInterval(calendarRefreshInterval);
  }

  calendarRefreshInterval = setInterval(loadCalendar, 30000);
});