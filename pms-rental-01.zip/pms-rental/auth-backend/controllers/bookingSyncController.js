// controllers/bookingSyncController.js
// Contrôleur Express pour la synchronisation des prix vers Booking.com

// On importe le service métier qui fera la logique réelle de synchronisation
const { syncPricesToBooking } = require('../services/bookingSyncService');

// Fonction appelée quand le frontend envoie un POST sur
// /api/integrations/booking/sync-prices
async function syncBookingPrices(req, res) {
  try {
    // On récupère le body JSON envoyé par le frontend
    // Exemple attendu :
    // {
    //   property_id: "1234567",
    //   updates: [
    //     { date_from: "2026-04-10", date_to: "2026-04-12", price: 120 }
    //   ]
    // }
    const payload = req.body || {};

    // On appelle le service de synchronisation
    // On passe aussi le user connecté, récupéré depuis la session Express
    const result = await syncPricesToBooking(payload, {
      user: req.session?.user
    });

    // Réponse OK renvoyée au frontend
    return res.json({
      success: true,
      message: 'Synchronisation Booking lancée',
      result
    });
  } catch (error) {
    // Log serveur utile pour debug
    console.error('Erreur sync Booking:', error);

    // Réponse erreur propre pour le frontend
    return res.status(500).json({
      success: false,
      message: error.message || 'Erreur interne de synchronisation Booking'
    });
  }
}

// On exporte la fonction pour l’utiliser dans les routes
module.exports = {
  syncBookingPrices
};