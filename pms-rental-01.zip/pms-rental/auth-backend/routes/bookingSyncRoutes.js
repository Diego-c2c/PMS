const express = require('express');
const { requireManager } = require('../authMiddleware');
const { syncBookingPrices } = require('../controllers/bookingSyncController');
const { syncCalendarV1 } = require('../controllers/bookingCalendarController');

const router = express.Router();

router.post('/sync-prices', requireManager, syncBookingPrices);
router.post('/sync-calendar-v1', requireManager, syncCalendarV1);

module.exports = router;