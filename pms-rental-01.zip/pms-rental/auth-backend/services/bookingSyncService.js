async function syncPricesToBooking(payload, context = {}) {
  const { property_id, email, updates } = payload;
  const actor = context.user?.email || 'unknown';

  console.log('Booking sync start', {
    property_id,
    actor,
    updates_count: updates.length
  });

  // TODO:
  // 1. Auth Booking
  // 2. Mapper les updates au format Booking
  // 3. Envoyer les prix
  // 4. Logger les résultats

  return {
    property_id,
    actor,
    updates_count: updates.length,
    status: 'stub',
    synced_at: new Date().toISOString(),
    email_used: email
  };
}

module.exports = {
  syncPricesToBooking
};